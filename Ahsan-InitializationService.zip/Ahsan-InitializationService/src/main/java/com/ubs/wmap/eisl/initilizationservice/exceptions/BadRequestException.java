package com.ubs.wmap.eisl.initilizationservice.exceptions;

public class BadRequestException extends Exception{
	
	private static final long serialVersionUID = -2154287827168582345L;

	public BadRequestException(String message) {
		super(message);
	}

}
