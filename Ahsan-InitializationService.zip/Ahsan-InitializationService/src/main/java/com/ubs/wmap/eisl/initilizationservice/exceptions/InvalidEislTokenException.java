package com.ubs.wmap.eisl.initilizationservice.exceptions;

public class InvalidEislTokenException extends RuntimeException {

	private static final long serialVersionUID = -7408420202454263359L;

	public InvalidEislTokenException(String message) {
		super(message);
	}

}
