package com.ubs.wmap.eisl.dataregistryservice.controller;
import com.ubs.wmap.eisl.dataregistryservice.exception.InvalidEISLTokenException;
import com.ubs.wmap.eisl.housekeeping.TokenService;
import com.ubs.wmap.eisl.housekeeping.component.exceptions.TokenExpireException;
import com.ubs.wmap.eisl.housekeeping.component.exceptions.TokenUnwrapException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import com.ubs.wmap.eisl.dataregistryservice.exception.DataReferenceException;
import com.ubs.wmap.eisl.dataregistryservice.exception.DataReferenceNotFoundException;
import com.ubs.wmap.eisl.dataregistryservice.exception.DataRegistryBadRequestException;
import com.ubs.wmap.eisl.dataregistryservice.service.DataReferenceService;
import com.ubs.wmap.eisl.dataregistryservice.vo.DataReferenceRequest;
import com.ubs.wmap.eisl.dataregistryservice.vo.DataReferenceResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import javax.validation.constraints.NotBlank;
import java.util.Map;

@RestController
@Slf4j
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DataServiceRegistryController {

	private final DataReferenceService dataReferenceService;
	
	@Value("${app.message.DATA_REFERENCE_NOT_FOUND_MSG}")
	private String DATA_REFERENCE_NOT_FOUND_MSG;
	
	@Value("${app.message.INTERNAL_SERVER_ERROR_MSG}")
	private String INTERNAL_SERVER_ERROR_MSG;
	
	@Value("${app.message.DATA_SERVICE_ID_EMPTY}")
	private String DATA_SERVICE_ID_EMPTY;

	@Value("${app.message.EISL_INVALID_TOKEN_MSG}")
	private String EISL_INVALID_TOKEN_MSG;

	@Value("${app.custom.eisl_attribute_name}")
	private String eislClaimsAttribute;

	private final TokenService tokenService;
	
	@GetMapping("/data/{dataServiceId}")
	public ResponseEntity<DataReferenceResponse> getDataReferenceDetails(@PathVariable String dataServiceId,
	        @NotBlank  @RequestParam("token") String token)
            throws DataReferenceException, DataRegistryBadRequestException, InvalidEISLTokenException {
		log.debug("Controller : Entering getDataReferenceDetails. dataServiceId:{}", dataServiceId);

		if (StringUtils.isEmpty(dataServiceId)) {
			throw new DataRegistryBadRequestException(DATA_SERVICE_ID_EMPTY);
		}

		if (!servicePreconditions(token).containsKey(eislClaimsAttribute)) {
			throw new InvalidEISLTokenException(EISL_INVALID_TOKEN_MSG);
		}

		DataReferenceResponse dataReference = null;
		try {
			DataReferenceRequest request = new DataReferenceRequest();
			request.setDataServiceId(dataServiceId);
			dataReference = dataReferenceService.getDataReference(request);
			if (null == dataReference) {
				log.debug("Controller: Exiting getDataReferenceDetails");
				throw new DataReferenceNotFoundException(DATA_REFERENCE_NOT_FOUND_MSG);
			}
		} catch (DataReferenceException ex) {
			log.debug("Controller: Exiting getDataReferenceDetails");
			throw new DataReferenceException(INTERNAL_SERVER_ERROR_MSG);
		}
		log.debug("Controller: Exiting getDataReferenceDetails");
		return ResponseEntity.status(200).body(dataReference);
	}
	
	@PostMapping("/data")
	public ResponseEntity<DataReferenceResponse> postDataReference(
			@RequestBody DataReferenceRequest dataReferencerequest, @RequestParam("token") String token)
            throws DataReferenceException, DataRegistryBadRequestException, InvalidEISLTokenException {
		log.debug("Controller : Entering postdatareferencemethod. Token = {}", token);
        DataReferenceResponse persistDataReference = null;

		if (!servicePreconditions(token).containsKey(eislClaimsAttribute)) {
			throw new InvalidEISLTokenException(EISL_INVALID_TOKEN_MSG);
		}

		try {
			persistDataReference = dataReferenceService.saveDataReference(dataReferencerequest);
		} catch (DataReferenceException e) {
			log.error(e.getMessage(), e);
			log.debug("Controller : Exiting postdatareferencemethod");
			throw new DataReferenceException(INTERNAL_SERVER_ERROR_MSG);
		}
		log.debug("Controller : Exiting postdatareferencemethod");
		return new ResponseEntity<DataReferenceResponse>(persistDataReference, HttpStatus.OK);
	}


	public Map<String, Object> servicePreconditions(String eislToken) throws InvalidEISLTokenException, DataReferenceException {
		Map<String, Object> eislClaims;
		try {
			eislClaims = tokenService.init(eislToken);
		} catch (TokenExpireException | TokenUnwrapException ex) {
			throw new InvalidEISLTokenException(EISL_INVALID_TOKEN_MSG);
		} catch (RuntimeException rx) {
			log.error(rx.getMessage());
			throw new DataReferenceException(INTERNAL_SERVER_ERROR_MSG);
		}

		return  eislClaims;
	}
}
