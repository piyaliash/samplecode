package com.ubs.wmap.eisl.dataregistryservice.exception;

public class DataRegistryBadRequestException extends Exception {

	private static final long serialVersionUID = 6583675662971902101L;
	public DataRegistryBadRequestException(String message) {
		super(message);
	}
	public DataRegistryBadRequestException(Throwable cause) {
		super(cause);
	}
	public DataRegistryBadRequestException(String message, Throwable cause) {
		super(message, cause);
	}
	@Override
	public String getMessage() {
		return super.getMessage();
	}
}
