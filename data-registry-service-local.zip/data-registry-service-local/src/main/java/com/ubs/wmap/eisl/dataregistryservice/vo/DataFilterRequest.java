package com.ubs.wmap.eisl.dataregistryservice.vo;

import java.io.Serializable;
import lombok.Data;


@Data
public class DataFilterRequest implements Serializable{
	
	private static final long serialVersionUID = -3472612466681432828L;
	
	private Integer filterId;
	private String name;
	private String options;
}
