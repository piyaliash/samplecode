package com.ubs.wmap.eisl.dataregistryservice.vo;

import java.io.Serializable;
import lombok.Data;

@Data
public class DataAccessModelRequest implements Serializable{

	private static final long serialVersionUID = 6311498647654593189L;
	private Integer dataAccessModelId;
	private String modelName;
}
