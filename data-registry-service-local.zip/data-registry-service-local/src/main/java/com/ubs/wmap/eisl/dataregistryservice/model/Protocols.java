package com.ubs.wmap.eisl.dataregistryservice.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(name = "PROTOCOLS")
public class Protocols implements Serializable{

	private static final long serialVersionUID = -1582174404891460920L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "Protocols_id")
	private Integer ProtocolsId;
	
	@Column(name = "Name")
	private String name;
	
	@Column(name = "Details")
	private String details;
	
	@EqualsAndHashCode.Exclude
	@ManyToOne
	@JoinColumn(name="Data_reference_id", nullable=false)
	private DataReference dataReference;
	
}
