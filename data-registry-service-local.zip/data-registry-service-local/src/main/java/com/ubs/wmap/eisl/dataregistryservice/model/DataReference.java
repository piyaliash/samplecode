package com.ubs.wmap.eisl.dataregistryservice.model;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(name = "DATA_REFERENCE")
public class DataReference implements Serializable{

	private static final long serialVersionUID = 8682370259634234471L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "Data_reference_id")
	private Integer dataReferenceId;
	
	@Column(name = "Data_service_id")
	private String dataServiceId;
	
	@EqualsAndHashCode.Exclude
	@OneToMany(mappedBy="dataReference", cascade=CascadeType.ALL)
	private Set<Protocols> protocols;
	
	@EqualsAndHashCode.Exclude
	@OneToMany(mappedBy="dataReference", cascade=CascadeType.ALL)
	private Set<DataAccessModel> dataModel;
	
	@EqualsAndHashCode.Exclude
	@OneToOne(mappedBy = "dataReference", cascade = CascadeType.ALL,
            fetch = FetchType.LAZY, optional = false)
	private DataFilter dataFilter;
}
