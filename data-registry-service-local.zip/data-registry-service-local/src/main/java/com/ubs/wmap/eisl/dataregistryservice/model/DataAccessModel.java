package com.ubs.wmap.eisl.dataregistryservice.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(name = "DATA_ACCESS_MODEL")
public class DataAccessModel implements Serializable{
	
	private static final long serialVersionUID = 5276957714020566373L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "Data_access_model_id")
	private Integer dataAccessModelId;
	
	@Column(name = "Model_name")
	private String modelName;
	
	@EqualsAndHashCode.Exclude
	@ManyToOne
	@JoinColumn(name="Data_reference_id", nullable=false)
	private DataReference dataReference;
}
