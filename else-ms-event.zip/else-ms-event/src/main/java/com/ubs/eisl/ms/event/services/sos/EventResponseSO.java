package com.ubs.eisl.ms.event.services.sos;

import java.io.Serializable;
import java.sql.Timestamp;

public class EventResponseSO implements Serializable{
	
	private static final long serialVersionUID = 7273465233846581680L;
	
	private String serviceId;
	private String serviceName;
	private String eventTopic;
	private Integer dataServiceId;
	private Integer exceptionServiceId;
	private String createdBy;
	private String lastUpdatedBy;
	private Timestamp createdDate;
	private Timestamp lastUpdatedDate;
	
	private Long eventServiceId;
	public Long getEventServiceId() {
		return eventServiceId;
	}
	public void setEventServiceId(Long eventServiceId) {
		this.eventServiceId = eventServiceId;
	}
	public String getServiceId() {
		return serviceId;
	}
	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}
	public String getServiceName() {
		return serviceName;
	}
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
	public String getEventTopic() {
		return eventTopic;
	}
	public void setEventTopic(String eventTopic) {
		this.eventTopic = eventTopic;
	}
	public Integer getDataServiceId() {
		return dataServiceId;
	}
	public void setDataServiceId(Integer dataServiceId) {
		this.dataServiceId = dataServiceId;
	}
	public Integer getExceptionServiceId() {
		return exceptionServiceId;
	}
	public void setExceptionServiceId(Integer exceptionServiceId) {
		this.exceptionServiceId = exceptionServiceId;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}
	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}
	public Timestamp getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public Timestamp getLastUpdatedDate() {
		return lastUpdatedDate;
	}
	public void setLastUpdatedDate(Timestamp lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	 @Override
    public String toString() {
        return new StringBuilder("serviceId:").append(serviceId)
            .append(",serviceName:").append(serviceName)
            .append(",eventTopic:").append(eventTopic)
            .append(",dataServiceId:").append(dataServiceId)
            .append(",exceptionServiceId:").append(exceptionServiceId)
            .append(",createdBy:").append(createdBy)
            .append(",lastUpdatedBy:").append(lastUpdatedBy)
            .append(",createdDate:").append(createdDate)
            .append(",lastUpdatedDate:").append(lastUpdatedDate).toString();
    }

}
