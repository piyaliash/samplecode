package com.ubs.eisl.ms.event.exception;

public class EventException extends Exception  {
	
	private static final long serialVersionUID = 8089713711480335861L;

	
	public static final String DEFAULT_ERROR_CODE = "-1";

	private final String errorCode;

	
	public EventException(){
		errorCode = DEFAULT_ERROR_CODE;
	}

	public EventException(Throwable cause) {
		super( cause);
		errorCode = DEFAULT_ERROR_CODE;
	}

	
	public String getErrorCode() {
		return errorCode;
	}	
	

}
