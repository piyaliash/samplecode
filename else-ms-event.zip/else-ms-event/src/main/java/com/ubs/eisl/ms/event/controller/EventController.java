package com.ubs.eisl.ms.event.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ubs.eisl.ms.event.controller.delegates.EventDelegate;
import com.ubs.eisl.ms.event.exception.EventException;
import com.ubs.eisl.ms.event.services.sos.EventRequestSO;
import com.ubs.eisl.ms.event.services.sos.EventResponseSO;

@RestController
public class EventController extends BaseController{
	
	@Autowired
	private EventDelegate eventDelegate;
	
	@RequestMapping(value = "/event/{serviceId}", method = RequestMethod.GET)
	public ResponseEntity<EventResponseSO> getEventDetails(@PathVariable("serviceId") String serviceId){
		EventResponseSO eventResponseSO=null;
		 
		 try {
			 eventResponseSO=eventDelegate.getEventDetails(constructEvenRequestSO(serviceId));
			
		} catch (EventException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		 return  ResponseEntity.ok(eventResponseSO);
	}
	
	private EventRequestSO constructEvenRequestSO(String serviceId) {
		
		EventRequestSO eventRequestSO=new EventRequestSO();
		eventRequestSO.setServiceId(serviceId);
		return eventRequestSO;
	}

}
