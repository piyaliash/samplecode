package com.ubs.eisl.ms.event.services.impl;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ubs.eisl.ms.event.domain.Events;
import com.ubs.eisl.ms.event.exception.EventException;
import com.ubs.eisl.ms.event.repository.EventRepository;
import com.ubs.eisl.ms.event.services.EventService;
import com.ubs.eisl.ms.event.services.sos.EventRequestSO;
import com.ubs.eisl.ms.event.services.sos.EventResponseSO;

@Service
public class EventServiceImpl implements EventService{

	@Autowired
	private EventRepository eventRepository;
	
	@Override
	public EventResponseSO getEventDetails(EventRequestSO eventRequestSO) throws EventException{
		EventResponseSO eventResponseSO=null;
		
		Events events=eventRepository.findByServiceId(eventRequestSO.getServiceId());
		
		if(events!=null) {
			eventResponseSO=constructEventResponseSO(events);
		}
		
		return eventResponseSO;
	}
	
	private EventResponseSO constructEventResponseSO(Events events) {
		EventResponseSO eventResponseSO=new EventResponseSO();
		BeanUtils.copyProperties(events, eventResponseSO);
		return eventResponseSO;
	}

}
