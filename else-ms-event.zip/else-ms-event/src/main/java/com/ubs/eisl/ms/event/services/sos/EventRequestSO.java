package com.ubs.eisl.ms.event.services.sos;

import java.io.Serializable;

public class EventRequestSO implements Serializable{
	
	private static final long serialVersionUID = -998787659770475488L;
	
	private String serviceId;

	public String getServiceId() {
		return serviceId;
	}

	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}


	 @Override
    public String toString() {
        return new StringBuilder("serviceId:").append(serviceId).toString();
             
    }
	
}
