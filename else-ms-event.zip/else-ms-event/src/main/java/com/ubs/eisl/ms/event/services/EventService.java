package com.ubs.eisl.ms.event.services;

import com.ubs.eisl.ms.event.exception.EventException;
import com.ubs.eisl.ms.event.services.sos.EventRequestSO;
import com.ubs.eisl.ms.event.services.sos.EventResponseSO;

public interface EventService {
	
	EventResponseSO getEventDetails(EventRequestSO eventRequestSO) throws EventException;

}
