package com.ubs.eisl.ms.event.controller;

public abstract class BaseController {

}
