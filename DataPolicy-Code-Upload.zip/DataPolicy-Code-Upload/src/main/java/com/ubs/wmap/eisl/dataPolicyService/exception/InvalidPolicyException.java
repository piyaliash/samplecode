package com.ubs.wmap.eisl.dataPolicyService.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value= HttpStatus.INTERNAL_SERVER_ERROR)
public class InvalidPolicyException extends Exception{

    public InvalidPolicyException(String message) {
        super(message);
    }
}