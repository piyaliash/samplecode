
package com.ubs.wmap.eisl.dataPolicyService.controller;

import com.ubs.wmap.eisl.dataPolicyService.exception.DataPolicyBadRequestException;
import com.ubs.wmap.eisl.dataPolicyService.exception.InvalidEISLTokenException;
import com.ubs.wmap.eisl.dataPolicyService.exception.InvalidPolicyException;
import com.ubs.wmap.eisl.dataPolicyService.exception.PolicyNotFoundException;
import com.ubs.wmap.eisl.dataPolicyService.model.DataPolicy;
import java.util.List;
import java.util.Map;

import com.ubs.wmap.eisl.dataPolicyService.service.DataPolicyService;
import com.ubs.wmap.eisl.housekeeping.TokenService;
import com.ubs.wmap.eisl.housekeeping.component.exceptions.TokenExpireException;
import com.ubs.wmap.eisl.housekeeping.component.exceptions.TokenUnwrapException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.constraints.NotBlank;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;


@RestController
@Slf4j
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DataPolicyRestController {
    
 private final DataPolicyService dataPolicyService;


 @Value("${app.message.INTERNAL_SERVER_ERROR_MSG}")
 private String INTERNAL_SERVER_ERROR_MSG;

 @Value("${app.message.EISL_INVALID_TOKEN_MSG}")
 private String EISL_INVALID_TOKEN_MSG;

 @Value("${app.custom.eisl_attribute_name}")
 private String eislClaimsAttribute;

 @Value("${app.message.DATA_POLICY_ID_EMPTY}")
 private String DATA_POLICY_ID_EMPTY;


 private final TokenService tokenService;
 
 @GetMapping("/datapolicies/fetchAll")
 public List<DataPolicy> getPolicies(@NotBlank @RequestParam("token") final String eislToken) throws DataPolicyBadRequestException, InvalidEISLTokenException, PolicyNotFoundException, InvalidPolicyException {

  if (!servicePreconditions(eislToken).containsKey(eislClaimsAttribute)) {
   throw new InvalidEISLTokenException(EISL_INVALID_TOKEN_MSG);
  }

  List<DataPolicy> employees = dataPolicyService.loadAll();
  return employees;
 }
  
 @GetMapping("/datapolicies/{policyId}")
 public DataPolicy getPolicy(@NotBlank @RequestParam("token") final String eislToken,
         @PathVariable(name="policyId") Long policyId) throws DataPolicyBadRequestException, InvalidEISLTokenException, PolicyNotFoundException, InvalidPolicyException {

   if (StringUtils.isEmpty(policyId)) {
    throw new DataPolicyBadRequestException(DATA_POLICY_ID_EMPTY);
   }

   if (!servicePreconditions(eislToken).containsKey(eislClaimsAttribute)) {
    throw new InvalidEISLTokenException(EISL_INVALID_TOKEN_MSG);
   }

    return dataPolicyService.getDataPolicy(policyId);
 }
 
  /*@GetMapping("/datapolicies")
 public DataPolicy getPolicyBasedOnApplicationId(@NotBlank @RequestParam("token") final String eislToken,
         @RequestParam(value="modelname", required = false) final String modelName,
         @RequestParam(value="applicationid", required = false) final Long applicationId) throws BadRequestException, InvalidEISLTokenException {

   if (!servicePreconditions(eislToken).containsKey(eislClaimsAttribute)) {
    throw new InvalidEISLTokenException(EISL_INVALID_TOKEN_MSG);
   }

  return dataPolicyService.getDataPolicy(applicationId);
 }*/



  public Map<String, Object> servicePreconditions(String eislToken) throws InvalidEISLTokenException, DataPolicyBadRequestException {
   Map<String, Object> eislClaims;
   try {
    eislClaims = tokenService.init(eislToken);
   } catch (TokenExpireException | TokenUnwrapException ex) {
    throw new InvalidEISLTokenException(EISL_INVALID_TOKEN_MSG);
   } catch (RuntimeException rx) {
    log.error(rx.getMessage());
    throw new DataPolicyBadRequestException(INTERNAL_SERVER_ERROR_MSG);
   }

   return  eislClaims;
  }
 }
    
