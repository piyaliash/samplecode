package com.ubs.wmap.eisl.dataPolicyService.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value= HttpStatus.BAD_REQUEST)
public class DataPolicyBadRequestException  extends Exception{
    private static final long serialVersionUID = 6583675662971902101L;
    public DataPolicyBadRequestException(String message) {
        super(message);
    }
    public DataPolicyBadRequestException(Throwable cause) {
        super(cause);
    }
    public DataPolicyBadRequestException(String message, Throwable cause) {
        super(message, cause);
    }
    @Override
    public String getMessage() {
        return super.getMessage();
    }

}
