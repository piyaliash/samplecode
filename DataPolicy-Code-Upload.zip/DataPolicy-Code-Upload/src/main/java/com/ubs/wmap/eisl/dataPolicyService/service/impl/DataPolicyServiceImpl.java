
package com.ubs.wmap.eisl.dataPolicyService.service.impl;

import com.ubs.wmap.eisl.dataPolicyService.exception.InvalidPolicyException;
import com.ubs.wmap.eisl.dataPolicyService.exception.PolicyNotFoundException;
import com.ubs.wmap.eisl.dataPolicyService.model.DataPolicy;
import com.ubs.wmap.eisl.dataPolicyService.repository.DataPolicyRepository;
import com.ubs.wmap.eisl.dataPolicyService.service.DataPolicyService;
import java.util.List;
import java.util.Optional;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;


@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@Service
@Slf4j
public class DataPolicyServiceImpl implements DataPolicyService {

 @Value("${app.message.DATA_POLICY_NOT_FOUND}")
 private String DATA_POLICY_NOT_FOUND;

 @Value("${app.message.INTERNAL_SERVER_ERROR_MSG}")
 private String INTERNAL_SERVER_ERROR_MSG;


 private final DataPolicyRepository dataPolicyRepository;

  
 public List<DataPolicy> loadAll() throws PolicyNotFoundException, InvalidPolicyException {
  try {
   List<DataPolicy> dataPolicies=dataPolicyRepository.findAll();
   return dataPolicies;
  }catch (Exception ex){
   log.error("Controller: Exiting getDataReferenceDetails {}", ex.getMessage());
   throw new InvalidPolicyException(INTERNAL_SERVER_ERROR_MSG);
  }
 }
  
 public DataPolicy getDataPolicy(Long policyId) throws PolicyNotFoundException {
  try {
   Optional<DataPolicy> policy = dataPolicyRepository.findById(policyId);
   return policy.get();
  }catch (Exception ex){
   log.error("Controller: Exiting getDataReferenceDetails {}", ex.getMessage());
   throw new PolicyNotFoundException(DATA_POLICY_NOT_FOUND);
  }
 }

 /*public DataPolicy getDataPolicyByApplicationId(Long applicationId) {
  Optional<DataPolicy> policy = dataPolicyRepository.findById(applicationId);
  return policy.get();
 }*/

}
