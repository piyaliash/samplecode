package com.ubs.wmap.eisl.dataPolicyService.repository;

import com.ubs.wmap.eisl.dataPolicyService.model.DataPolicy;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DataPolicyRepository extends JpaRepository<DataPolicy,Long> {

	
}
