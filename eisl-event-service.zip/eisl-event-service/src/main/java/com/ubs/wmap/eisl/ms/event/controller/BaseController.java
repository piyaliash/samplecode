package com.ubs.wmap.eisl.ms.event.controller;

public abstract class BaseController {

}
