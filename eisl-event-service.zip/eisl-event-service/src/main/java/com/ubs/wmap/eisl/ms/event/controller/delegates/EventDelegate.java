package com.ubs.wmap.eisl.ms.event.controller.delegates;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ubs.wmap.eisl.ms.event.exception.EventException;
import com.ubs.wmap.eisl.ms.event.services.EventService;
import com.ubs.wmap.eisl.ms.event.services.sos.EventRequestSO;
import com.ubs.wmap.eisl.ms.event.services.sos.EventResponseSO;

@Component
public class EventDelegate {
	
	
	@Autowired
	private EventService eventService;
	
	public EventResponseSO getEventDetails(EventRequestSO eventRequestSO) throws EventException{
		 return eventService.getEventDetails(eventRequestSO);
	}

}
