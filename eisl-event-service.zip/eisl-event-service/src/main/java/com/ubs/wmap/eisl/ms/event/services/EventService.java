package com.ubs.wmap.eisl.ms.event.services;

import com.ubs.wmap.eisl.ms.event.exception.EventException;
import com.ubs.wmap.eisl.ms.event.services.sos.EventRequestSO;
import com.ubs.wmap.eisl.ms.event.services.sos.EventResponseSO;
/**
 * Get event details 
 * @author SMAREDDY
 *
 */
public interface EventService {
	/**
	 * Get event details based on serviceId
	 * @param eventRequestSO
	 * @return EventResponseSO
	 * @throws EventException
	 */
	EventResponseSO getEventDetails(EventRequestSO eventRequestSO) throws EventException;

}
