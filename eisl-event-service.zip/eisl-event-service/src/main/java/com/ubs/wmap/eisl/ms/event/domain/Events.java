package com.ubs.wmap.eisl.ms.event.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.sql.Timestamp;

@Entity
@Table(name = "EVENTS")
public class Events implements Serializable  {

	private static final long serialVersionUID = -2960973719692214842L;

	@Id
	@GeneratedValue
	@Column(name = "EVENT_SERVICE_ID")
	private Long eventServiceId;

	@Column(name = "SERVICE_ID")
	private String serviceId;
	
	@Column(name = "SERVICE_NAME")
	private String serviceName;
	
	@Column(name = "EVENT_TOPIC")
	private String eventTopic;
	
	@Column(name = "DATA_SERVICE_ID")
	private Integer dataServiceId;
	
	@Column(name = "EXCEPTION_SERVICE_ID")
	private Integer exceptionServiceId;
	
	@Column(name = "CREATED_BY")
	private String createdBy;
	
	@Column(name = "LAST_UPDATED_BY")
	private String lastUpdatedBy;
	
	@Column(name = "CREATION_DATE")
	private Timestamp createdDate;
	
	@Column(name = "LAST_UPDATED_DATE")
	private Timestamp lastUpdatedDate;

	public Long getEventServiceId() {
		return eventServiceId;
	}

	public void setEventServiceId(Long eventServiceId) {
		this.eventServiceId = eventServiceId;
	}

	public String getServiceId() {
		return serviceId;
	}

	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public String getEventTopic() {
		return eventTopic;
	}

	public void setEventTopic(String eventTopic) {
		this.eventTopic = eventTopic;
	}

	public Integer getDataServiceId() {
		return dataServiceId;
	}

	public void setDataServiceId(Integer dataServiceId) {
		this.dataServiceId = dataServiceId;
	}

	public Integer getExceptionServiceId() {
		return exceptionServiceId;
	}

	public void setExceptionServiceId(Integer exceptionServiceId) {
		this.exceptionServiceId = exceptionServiceId;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public Timestamp getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Timestamp lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}
	

}
