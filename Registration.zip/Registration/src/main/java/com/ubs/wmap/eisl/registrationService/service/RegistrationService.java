package com.ubs.wmap.eisl.registrationService.service;

import javax.validation.constraints.NotBlank;

import com.ubs.wmap.eisl.registrationService.exception.DataNotFoundException;
import com.ubs.wmap.eisl.registrationService.exception.EsilTokenNotValidException;
import com.ubs.wmap.eisl.registrationService.exception.InvalidDataException;
import com.ubs.wmap.eisl.registrationService.model.PayloadSO;
import com.ubs.wmap.eisl.registrationService.model.RegistrationSO;
import com.ubs.wmap.eisl.registrationService.model.ResponseSO;


public interface RegistrationService {

	ResponseSO getRegistration(@NotBlank String eislToken) throws InvalidDataException, DataNotFoundException, EsilTokenNotValidException;
	RegistrationSO putRegistration(@NotBlank String eislToken, PayloadSO payload) throws InvalidDataException, DataNotFoundException, EsilTokenNotValidException;
	RegistrationSO postRegistration(@NotBlank String eislToken, PayloadSO payload) throws InvalidDataException, DataNotFoundException, EsilTokenNotValidException;
	ResponseSO deleteRegistration( String baseUrl,String eislToken);
}
