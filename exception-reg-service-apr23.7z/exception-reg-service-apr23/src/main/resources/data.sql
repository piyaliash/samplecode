insert into EXCEPTION_DATA
(EXCEPTION_DATA_ID, STACK_TRACE, META_DATA,
CREATED_BY, LAST_UPDATED_BY, CREATION_DATE, LAST_UPDATED_DATE)
values (1,'exception details-service exception1', 'metadata1','user', null, sysdate, null);

insert into EXCEPTION_DATA
(EXCEPTION_DATA_ID, STACK_TRACE, META_DATA,
CREATED_BY, LAST_UPDATED_BY, CREATION_DATE, LAST_UPDATED_DATE)
values (2,'exception details-service exception2', 'metadata2','user', null, sysdate, null);



insert into EXCEPTION_REFERENCE (EXCEPTION_REF_ID,EXCEPTION_SERVICE_ID, EXCEPTION_TOPIC, CATEGORY, SEVERITY,
CREATED_BY, LAST_UPDATED_BY, CREATION_DATE, LAST_UPDATED_DATE)
values (998, 1, 'ExceptionTopic-1','CATEGORY-1', 'SEVERITY-1', 'user1', null, sysdate, null);

insert into EXCEPTION_REFERENCE (EXCEPTION_REF_ID, EXCEPTION_SERVICE_ID, EXCEPTION_TOPIC, CATEGORY, SEVERITY,
CREATED_BY, LAST_UPDATED_BY, CREATION_DATE, LAST_UPDATED_DATE)
values (999, 2,'ExceptionTopic-2','CATEGORY-2', 'SEVERITY-2', 'user2', null, sysdate, null);






