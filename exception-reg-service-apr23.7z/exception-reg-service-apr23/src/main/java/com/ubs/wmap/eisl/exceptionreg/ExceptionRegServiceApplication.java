package com.ubs.wmap.eisl.exceptionreg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Import;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

import com.ubs.wmap.eisl.housekeeping.TokenServiceConfiguration;

@SpringBootApplication
@Import(TokenServiceConfiguration.class)
@EnableJpaAuditing
public class ExceptionRegServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExceptionRegServiceApplication.class, args);
	}

}
