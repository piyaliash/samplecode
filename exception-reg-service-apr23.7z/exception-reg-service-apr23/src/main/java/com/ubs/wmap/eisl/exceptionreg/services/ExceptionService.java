package com.ubs.wmap.eisl.exceptionreg.services;

import com.ubs.wmap.eisl.exceptionreg.exception.ExceptionRegException;
import com.ubs.wmap.eisl.exceptionreg.services.sos.ExceptionPostRequestSO;
import com.ubs.wmap.eisl.exceptionreg.services.sos.ExceptionRequestSO;
import com.ubs.wmap.eisl.exceptionreg.services.sos.ExceptionResponseSO;
/**
 * Exception service to get exception and add exception details
 * 
 * @author SMAREDDY
 *
 */
public interface ExceptionService {
	
	/**
	 * Get Exception details
	 * @param exceptionRequestSO
	 * @return ExceptionResponseSO
	 * @throws ExceptionRegException
	 */
	ExceptionResponseSO getExceptionDetails(ExceptionRequestSO exceptionRequestSO) throws ExceptionRegException;
	
	/**
	 * Save Exception details
	 * @param exceptionPostRequestSO
	 * @return ExceptionResponseSO
	 * @throws ExceptionRegException
	 */
	ExceptionResponseSO saveExceptionDetails(ExceptionPostRequestSO exceptionPostRequestSO) throws ExceptionRegException;

	
	

}
