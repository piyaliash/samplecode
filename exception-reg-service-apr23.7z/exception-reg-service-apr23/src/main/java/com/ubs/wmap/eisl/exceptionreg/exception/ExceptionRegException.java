package com.ubs.wmap.eisl.exceptionreg.exception;

public class ExceptionRegException extends RuntimeException  {
	
	private static final long serialVersionUID = 8089713711480335861L;

	public ExceptionRegException(String message) {
		super(message);
	}
}
