package com.ubs.wmap.eisl.exceptionreg.services.sos;

import java.io.Serializable;
import java.util.Date;

import lombok.Data;

@Data
public class ExceptionResponseSO implements Serializable {

	private static final long serialVersionUID = 7273465233846581680L;

	private Long exceptionRefId;
	private Integer exceptionServiceId;
	private String exceptionDataRefId;
	private String category;
	private String exceptionTopic;
	private String createdBy;
	private String lastUpdatedBy;
	private Date createdDate;
	private Date lastUpdatedDate;
	
	private ExceptionDataResponseSO exceptionDataResponseSO;

}
