package com.ubs.wmap.eisl.registrationService.registrationservice.model;

import lombok.Data;

@Data
public class EventsDetailsModel {

    private String serviceName;
    private long serviceId;
    private String eventTopic;
    private long dataServiceId;
    private long exceptionServiceId;
}
