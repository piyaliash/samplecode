package com.ubs.wmap.eisl.registrationService.registrationservice.model;

import lombok.Data;

@Data
public class ExceptionReferenceModel {

    private long exceptionServiceId;
    private String exceptionDatarEference;
    private String exceptionTopic;
    private String category;
    private int severity;
}
