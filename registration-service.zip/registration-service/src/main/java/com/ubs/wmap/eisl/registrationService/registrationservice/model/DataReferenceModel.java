package com.ubs.wmap.eisl.registrationService.registrationservice.model;

import lombok.Data;

@Data
public class DataReferenceModel {

    private long dataServiceId;
    private String dataIngestionTopic;
    private String dataOutReference;
}
