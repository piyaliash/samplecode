package com.ubs.wmap.eisl.registrationService.registrationservice.controller;


import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.NotBlank;
import java.util.HashMap;

@RestController
@RequestMapping(value = "/eisl/registration/v1", produces = "application/json")
public class RegistrationServiceController {

    @GetMapping("/registrations")
    public ResponseEntity<Object> getRegistry(@NotBlank @RequestHeader(name = "BasicToken") final String basicToken,
                                           @NotBlank @RequestParam final String eislToken,@NotBlank @RequestParam final String userId, @NotBlank @RequestParam final String serviceId) {


        return ResponseEntity.ok()
                .body(new HashMap<>());
    }

    @PostMapping("/registrations")
    public ResponseEntity<Object> addRegistry(@NotBlank @RequestHeader(name = "BasicToken") final String basicToken,
                                              @NotBlank @RequestParam final String eislToken,@NotBlank @RequestParam final String userId, @NotBlank @RequestParam final String serviceId) {


        return ResponseEntity.ok()
                .body(new HashMap<>());
    }

    @PutMapping("/registrations")
    public ResponseEntity<Object> updateRegistry(@NotBlank @RequestHeader(name = "BasicToken") final String basicToken,
                                              @NotBlank @RequestParam final String eislToken,@NotBlank @RequestParam final String userId, @NotBlank @RequestParam final String serviceId) {


        return ResponseEntity.ok()
                .body(new HashMap<>());
    }

    @DeleteMapping("/registrations")
    public ResponseEntity<Object> deleteRegistry(@NotBlank @RequestHeader(name = "BasicToken") final String basicToken,
                                                 @NotBlank @RequestParam final String eislToken,@NotBlank @RequestParam final String userId, @NotBlank @RequestParam final String serviceId) {


        return ResponseEntity.ok()
                .body(new HashMap<>());
    }
}
