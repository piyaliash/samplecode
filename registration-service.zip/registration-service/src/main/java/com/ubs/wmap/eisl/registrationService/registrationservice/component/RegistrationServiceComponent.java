package com.ubs.wmap.eisl.registrationService.registrationservice.component;

import java.util.HashMap;
import java.util.Map;

public class RegistrationServiceComponent {


}
