package com.ubs.wmap.eisl.registrationService.registrationservice.service;

import java.util.HashMap;
import java.util.Map;

public class RegistrationService {

    public Map<String, Object> validateToken(String basicToken, String eislToken, Map<String,String> claims) {
        Map<String, Object> eislClaims = new HashMap<>();
        try {
            //kString toen = initializeHouseKeepingLibrary.init(basicToken, eislToken, claimstest);


        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return eislClaims;
    }

    public Map<String, Object> getRegistryDetails(String basicToken, String eislToken, String userId, String serviceId, String role) {
        Map<String, Object> registryInformation = new HashMap<>();
        try {
            //kString toen = initializeHouseKeepingLibrary.init(basicToken, eislToken, claimstest);


        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return registryInformation;
    }

    public Map<String, Object> getEventModelDetails(String basicToken, String eislToken, String serviceId) {
        Map<String, Object> eventDetails = new HashMap<>();
        try {
            //kString toen = initializeHouseKeepingLibrary.init(basicToken, eislToken, claimstest);


        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return eventDetails;
    }

    public Map<String, Object> geteventsDataInformation(String basicToken, String eislToken, String dataReferenceId) {
        Map<String, Object> eventDataDetails = new HashMap<>();
        try {
            //kString toen = initializeHouseKeepingLibrary.init(basicToken, eislToken, claimstest);


        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return eventDataDetails;
    }

    public Map<String, Object> getExceptionDetails(String basicToken, String eislToken, String exceptionRefereceId) {
        Map<String, Object> exceptionDataDetails = new HashMap<>();
        try {
            //kString toen = initializeHouseKeepingLibrary.init(basicToken, eislToken, claimstest);


        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return exceptionDataDetails;
    }

    public Map<String, Object> buildRegistration(){
        Map<String, Object> registrationDetails = new HashMap<>();

        return registrationDetails;
    }

    public Map<String, Object> createRegistry(){
        Map<String, Object> registrationDetails = new HashMap<>();

        return registrationDetails;
    }
}
