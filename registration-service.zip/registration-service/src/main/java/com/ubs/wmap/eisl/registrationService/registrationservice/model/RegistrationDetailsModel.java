package com.ubs.wmap.eisl.registrationService.registrationservice.model;

import lombok.Data;

@Data
public class RegistrationDetailsModel {

    private int userId;
    private String userName;
    private String company;
    private String roles;
    private String eislToken;
    private long serviceId;
    private String coloumnReference;
    private String rowReference;
    private String DataEntitlements;

}
