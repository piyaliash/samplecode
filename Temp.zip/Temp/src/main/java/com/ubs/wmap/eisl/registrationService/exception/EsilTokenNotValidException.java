package com.ubs.wmap.eisl.registrationService.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(code = HttpStatus.FORBIDDEN, reason = "Invalid Esil Token")
public class EsilTokenNotValidException extends Exception{

	private static final long serialVersionUID = -3379429824404071177L;

	public EsilTokenNotValidException(String message, Throwable cause) {
		super(message, cause);
	}

	public EsilTokenNotValidException(String message) {
		super(message);
	}

	public EsilTokenNotValidException(Throwable cause) {
		super(cause);
	}
	
	

}
