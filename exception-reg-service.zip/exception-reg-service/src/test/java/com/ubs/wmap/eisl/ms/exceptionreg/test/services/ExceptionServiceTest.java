package com.ubs.wmap.eisl.ms.exceptionreg.test.services;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.test.context.junit4.SpringRunner;

import com.ubs.wmap.eisl.ms.exceptionreg.services.ExceptionService;
import com.ubs.wmap.eisl.ms.exceptionreg.services.sos.ExceptionRequestSO;
import com.ubs.wmap.eisl.ms.exceptionreg.services.sos.ExceptionResponseSO;

@RunWith(SpringRunner.class)
@DataJpaTest
@EnableAutoConfiguration
@ComponentScan(basePackages = { "com.ubs.wmap.eisl.ms.exceptionreg" })
public class ExceptionServiceTest {
	
	@Autowired
	private ExceptionService eventService;
	
	@Test
	public void testGetEventDetailsWithData() throws Exception {
		ExceptionRequestSO eventRequestSO=new ExceptionRequestSO();
		eventRequestSO.setExceptionServiceId("1");
		ExceptionResponseSO eventResponseSO = eventService.getExceptionDetails(eventRequestSO);
		assertNotNull(eventResponseSO);
	}
	
	@Test
	public void testGetEventDetailsWithOutData() throws Exception {
		ExceptionRequestSO eventRequestSO=new ExceptionRequestSO();
		eventRequestSO.setExceptionServiceId("3");
		ExceptionResponseSO eventResponseSO = eventService.getExceptionDetails(eventRequestSO);
		assertNull(eventResponseSO);
	}
}
