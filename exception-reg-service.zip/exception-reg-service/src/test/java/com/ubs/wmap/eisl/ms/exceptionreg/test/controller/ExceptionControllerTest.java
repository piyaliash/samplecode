package com.ubs.wmap.eisl.ms.exceptionreg.test.controller;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.ubs.wmap.eisl.ms.exceptionreg.controller.ExceptionController;
import com.ubs.wmap.eisl.ms.exceptionreg.services.sos.ExceptionResponseSO;
import com.ubs.wmap.eisl.ms.excptionreg.exception.ExceptionNotFoundException;

@RunWith(SpringRunner.class)
@DataJpaTest
@EnableAutoConfiguration
@ComponentScan(basePackages = { "com.ubs.wmap.eisl.ms.exceptionreg" })
public class ExceptionControllerTest {

	@Autowired
	private ExceptionController eventController;

	@Test
	public void eventControllerDataTest() throws Exception {

		ResponseEntity<ExceptionResponseSO> responseEntity = eventController.getEventDetails("1");
		assertNotNull(responseEntity);
	}

	@Test
	public void eventControllerWithoutDataTest() throws Exception {
		try {
			ResponseEntity<ExceptionResponseSO> responseEntity = eventController.getEventDetails("3");
			assertNotNull(responseEntity);
		} catch (ExceptionNotFoundException ex) {
			assertTrue(true);
		}
	}

}
