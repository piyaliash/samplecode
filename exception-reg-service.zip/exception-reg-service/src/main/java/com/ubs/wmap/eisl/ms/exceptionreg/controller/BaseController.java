package com.ubs.wmap.eisl.ms.exceptionreg.controller;

public abstract class BaseController {

}
