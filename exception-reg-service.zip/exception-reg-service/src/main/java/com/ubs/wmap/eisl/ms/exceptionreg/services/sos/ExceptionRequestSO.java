package com.ubs.wmap.eisl.ms.exceptionreg.services.sos;

import java.io.Serializable;

public class ExceptionRequestSO implements Serializable {

	private static final long serialVersionUID = -998787659770475488L;

	private String exceptionServiceId;

	public String getExceptionServiceId() {
		return exceptionServiceId;
	}

	public void setExceptionServiceId(String exceptionServiceId) {
		this.exceptionServiceId = exceptionServiceId;
	}

	@Override
	public String toString() {
		return new StringBuilder("exceptionServiceId:").append(exceptionServiceId).toString();

	}

}
