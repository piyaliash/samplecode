package com.ubs.wmap.eisl.ms.excptionreg.exception;

public class ExceptionNotFoundException extends RuntimeException{
	
	private static final long serialVersionUID = -7408420202454263359L;

	public ExceptionNotFoundException(String message) {
		super(message);
	}

}
