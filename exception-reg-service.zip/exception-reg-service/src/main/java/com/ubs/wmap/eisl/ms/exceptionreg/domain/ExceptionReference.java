package com.ubs.wmap.eisl.ms.exceptionreg.domain;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "EXCEPTION_REFERENCE")
public class ExceptionReference implements Serializable {

	private static final long serialVersionUID = -2960973719692214842L;

	@Id
	@GeneratedValue
	@Column(name = "EXCEPTION_REF_ID")
	private Long exceptionRefId;

	@Column(name = "EXCEPTION_SERVICE_ID")
	private Integer exceptionServiceId;

	@Column(name = "EXCEPTION_TOPIC")
	private String exceptionTopic;

	@Column(name = "CATEGORY")
	private String category;

	@Column(name = "SEVERITY")
	private String severity;

	@Column(name = "CREATED_BY")
	private String createdBy;

	@Column(name = "LAST_UPDATED_BY")
	private String lastUpdatedBy;

	@Column(name = "CREATION_DATE")
	private Timestamp createdDate;

	@Column(name = "LAST_UPDATED_DATE")
	private Timestamp lastUpdatedDate;

	@OneToOne(mappedBy = "exceptionReference", cascade = CascadeType.ALL)
	@JoinColumn(name = "EXCEPTION_DATA_ID")
	private ExceptionData exceptionData;

	public Long getExceptionRefId() {
		return exceptionRefId;
	}

	public void setExceptionRefId(Long exceptionRefId) {
		this.exceptionRefId = exceptionRefId;
	}

	public Integer getExceptionServiceId() {
		return exceptionServiceId;
	}

	public void setExceptionServiceId(Integer exceptionServiceId) {
		this.exceptionServiceId = exceptionServiceId;
	}

	public String getExceptionTopic() {
		return exceptionTopic;
	}

	public void setExceptionTopic(String exceptionTopic) {
		this.exceptionTopic = exceptionTopic;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getSeverity() {
		return severity;
	}

	public void setSeverity(String severity) {
		this.severity = severity;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public Timestamp getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Timestamp lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public ExceptionData getExceptionData() {
		return exceptionData;
	}

	public void setExceptionData(ExceptionData exceptionData) {
		this.exceptionData = exceptionData;
	}

}
