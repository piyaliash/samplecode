package com.ubs.wmap.eisl.ms.exceptionreg.controller;

import static com.ubs.wmap.eisl.ms.exceptionreg.constants.ExceptionConstants.EVENT_GET_ENDPOINT;
import static com.ubs.wmap.eisl.ms.exceptionreg.constants.ExceptionConstants.EVENT_NOT_FOUND_MSG;
import static com.ubs.wmap.eisl.ms.exceptionreg.constants.ExceptionConstants.INTERNAL_SERVER_ERROR_MSG;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ubs.wmap.eisl.ms.exceptionreg.controller.delegates.ExceptionDelegate;
import com.ubs.wmap.eisl.ms.exceptionreg.services.sos.ExceptionRequestSO;
import com.ubs.wmap.eisl.ms.exceptionreg.services.sos.ExceptionResponseSO;
import com.ubs.wmap.eisl.ms.excptionreg.exception.ExceptionNotFoundException;
import com.ubs.wmap.eisl.ms.excptionreg.exception.ExceptionRefException;

@RestController
public class ExceptionController extends BaseController {

	private static final Logger LOG = LoggerFactory.getLogger(ExceptionController.class);
	
	@Autowired
	private ExceptionDelegate exceptionDelegate;
	
	
	@RequestMapping(value = EVENT_GET_ENDPOINT, method = RequestMethod.GET)
	public ResponseEntity<ExceptionResponseSO> getEventDetails(@RequestParam("token") String token)
			throws ExceptionRefException {
		LOG.debug("token:{}",token);
		ExceptionResponseSO exceptionResponseSO = null;

		try {
			/** TO DO Get service id from **/
			String serviceId="1";
			exceptionResponseSO = exceptionDelegate.getExceptionDetails(constructExceptionRequestSO(serviceId));
			if (exceptionResponseSO == null) {
				throw new ExceptionNotFoundException(EVENT_NOT_FOUND_MSG + serviceId);
			}

		} catch (ExceptionRefException eventException) {
			LOG.error( eventException.getMessage(), eventException);
			throw new ExceptionRefException(INTERNAL_SERVER_ERROR_MSG);
		}

		return ResponseEntity.ok(exceptionResponseSO);
	}

	/**
	 * This is just for testing and has to be remove
	 */
	@RequestMapping(value = "/event/{serviceId}", method = RequestMethod.GET)
	public ResponseEntity<ExceptionResponseSO> getEventDetails1(@PathVariable("serviceId") String serviceId)
			throws ExceptionRefException {
		ExceptionResponseSO eventResponseSO = null;

		try {
			eventResponseSO = exceptionDelegate.getExceptionDetails(constructExceptionRequestSO(serviceId));
			if (eventResponseSO == null) {
				throw new ExceptionNotFoundException(EVENT_NOT_FOUND_MSG + serviceId);
			}

		} catch (ExceptionRefException eventException) {
			LOG.error( eventException.getMessage(), eventException);
			throw new ExceptionRefException(INTERNAL_SERVER_ERROR_MSG);
		}

		return ResponseEntity.ok(eventResponseSO);
	}

	private ExceptionRequestSO constructExceptionRequestSO(String exceptionServiceId) {
		ExceptionRequestSO exceptionRequestSO = new ExceptionRequestSO();
		exceptionRequestSO.setExceptionServiceId(exceptionServiceId);
		return exceptionRequestSO;
	}

}
