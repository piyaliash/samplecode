package com.ubs.wmap.eisl.ms.exceptionreg.domain;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "EXCEPTION_DATA")
public class ExceptionData implements Serializable  {

	private static final long serialVersionUID = -2960973719692214842L;

	@Id
	@GeneratedValue
	@Column(name = "EXCEPTION_DATA_ID")
	private Long exceptionDataId;
	
	@OneToOne(mappedBy="exceptionData")
	private ExceptionReference exceptionReference;
	
	@Lob
	@Column(name="STACK_TRACE")
	private String stackTrace;
	
	@Column(name = "CREATED_BY")
	private String createdBy;
	
	@Column(name = "LAST_UPDATED_BY")
	private String lastUpdatedBy;
	
	@Column(name = "CREATION_DATE")
	private Timestamp createdDate;
	
	@Column(name = "LAST_UPDATED_DATE")
	private Timestamp lastUpdatedDate;

}
