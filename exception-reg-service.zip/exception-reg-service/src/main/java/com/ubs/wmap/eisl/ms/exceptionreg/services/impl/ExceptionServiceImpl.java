package com.ubs.wmap.eisl.ms.exceptionreg.services.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ubs.wmap.eisl.ms.exceptionreg.domain.ExceptionData;
import com.ubs.wmap.eisl.ms.exceptionreg.domain.ExceptionReference;
import com.ubs.wmap.eisl.ms.exceptionreg.repository.ExceptionRepository;
import com.ubs.wmap.eisl.ms.exceptionreg.services.ExceptionService;
import com.ubs.wmap.eisl.ms.exceptionreg.services.sos.ExceptionDataResponseSO;
import com.ubs.wmap.eisl.ms.exceptionreg.services.sos.ExceptionRequestSO;
import com.ubs.wmap.eisl.ms.exceptionreg.services.sos.ExceptionResponseSO;
import com.ubs.wmap.eisl.ms.excptionreg.exception.ExceptionRefException;

@Service
public class ExceptionServiceImpl implements ExceptionService{

	private static final Logger LOG = LoggerFactory.getLogger(ExceptionServiceImpl.class);
	
	@Autowired
	private ExceptionRepository exceptionRepository;
	
	@Override
	public ExceptionResponseSO getExceptionDetails(ExceptionRequestSO exceptionRequestSO) throws ExceptionRefException{
		LOG.debug("exceptionRequestSO:{}",exceptionRequestSO);
		
		ExceptionResponseSO exceptionResponseSO=null;
		
		ExceptionReference exceptionReference=exceptionRepository.findByExceptionServiceId(
				exceptionRequestSO.getExceptionServiceId());
		
		if(exceptionReference!=null) {
			exceptionResponseSO=constructExceptionResponseSO(exceptionReference);
			
			exceptionResponseSO.setExceptionDataResponseSO(
					constructExceptionDataResponseSO(exceptionReference.getExceptionData()));
		}
		
		LOG.debug("exceptionResponseSO:{}",exceptionResponseSO);
		
		return exceptionResponseSO;
	}
	
	private ExceptionResponseSO constructExceptionResponseSO(ExceptionReference exceptionReference) {
		ExceptionResponseSO exceptionResponseSO=new ExceptionResponseSO();
		BeanUtils.copyProperties(exceptionReference, exceptionResponseSO);
		return exceptionResponseSO;
	}
	
	private ExceptionDataResponseSO constructExceptionDataResponseSO(ExceptionData exceptionData) {
		ExceptionDataResponseSO exceptionDataResponseSO=new ExceptionDataResponseSO();
		BeanUtils.copyProperties(exceptionData, exceptionDataResponseSO);
		return exceptionDataResponseSO;
	}

}
