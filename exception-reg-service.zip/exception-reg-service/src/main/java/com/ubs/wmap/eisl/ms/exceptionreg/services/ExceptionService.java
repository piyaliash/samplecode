package com.ubs.wmap.eisl.ms.exceptionreg.services;

import com.ubs.wmap.eisl.ms.exceptionreg.services.sos.ExceptionRequestSO;
import com.ubs.wmap.eisl.ms.exceptionreg.services.sos.ExceptionResponseSO;
import com.ubs.wmap.eisl.ms.excptionreg.exception.ExceptionRefException;
/**
 * Exception service to get exception and add exception details
 * 
 * @author SMAREDDY
 *
 */
public interface ExceptionService {
	
	/**
	 * Get Exception details
	 * @param eventRequestSO
	 * @return ExceptionResponseSO
	 * @throws ExceptionRefException
	 */
	ExceptionResponseSO getExceptionDetails(ExceptionRequestSO eventRequestSO) throws ExceptionRefException;

}
