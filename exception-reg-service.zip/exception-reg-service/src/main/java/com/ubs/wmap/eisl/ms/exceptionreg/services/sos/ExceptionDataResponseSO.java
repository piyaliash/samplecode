package com.ubs.wmap.eisl.ms.exceptionreg.services.sos;

import java.io.Serializable;
import java.sql.Timestamp;

public class ExceptionDataResponseSO implements Serializable{
	
	private static final long serialVersionUID = -8626286941250840467L;

	private Long exceptionDataId;
	private String stackTrace;
	private String createdBy;
	private String lastUpdatedBy;
	private Timestamp createdDate;
	private Timestamp lastUpdatedDate;

	
	public Long getExceptionDataId() {
		return exceptionDataId;
	}
	public void setExceptionDataId(Long exceptionDataId) {
		this.exceptionDataId = exceptionDataId;
	}
	public String getStackTrace() {
		return stackTrace;
	}
	public void setStackTrace(String stackTrace) {
		this.stackTrace = stackTrace;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}
	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}
	public Timestamp getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public Timestamp getLastUpdatedDate() {
		return lastUpdatedDate;
	}
	public void setLastUpdatedDate(Timestamp lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}
	
}
