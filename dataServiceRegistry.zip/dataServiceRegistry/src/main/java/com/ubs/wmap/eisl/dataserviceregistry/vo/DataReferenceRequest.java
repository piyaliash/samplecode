package com.ubs.wmap.eisl.dataserviceregistry.vo;

import java.io.Serializable;

public class DataReferenceRequest implements Serializable {

	private static final long serialVersionUID = -83396507865626884L;
	
	private Integer dataServiceId;
	
	private String protocolName;
	
	public Integer getDataServiceId() {
		return dataServiceId;
	}
	public void setDataServiceId(Integer dataServiceId) {
		this.dataServiceId = dataServiceId;
	}
	public String getProtocolName() {
		return protocolName;
	}
	public void setProtocolName(String protocolName) {
		this.protocolName = protocolName;
	}
	@Override
	public String toString() {
        return new StringBuilder("dataServiceId:").append(dataServiceId).toString();
             
    }
	
}
