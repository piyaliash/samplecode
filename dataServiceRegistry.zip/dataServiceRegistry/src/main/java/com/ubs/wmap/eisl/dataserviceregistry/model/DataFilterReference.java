package com.ubs.wmap.eisl.dataserviceregistry.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "DATA_FILTER_REFERENCE")
public class DataFilterReference implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -715389885855316908L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "Filter_reference_id")
	private Integer filterRefernceId;
	
	@OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "Data_out_reference_id", nullable=false)
	private DataOutReference dataOutReference;
	
	@Column(name = "Filter_Name")
	private String filterName;
	
	@Column(name = "Filter_Options")
	private String filterOption;

	public Integer getFilterRefernceId() {
		return filterRefernceId;
	}

	public void setFilterRefernceId(Integer filterRefernceId) {
		this.filterRefernceId = filterRefernceId;
	}

	public DataOutReference getDataOutReference() {
		return dataOutReference;
	}

	public void setDataOutReference(DataOutReference dataOutReference) {
		this.dataOutReference = dataOutReference;
	}

	public String getFilterName() {
		return filterName;
	}

	public void setFilterName(String filterName) {
		this.filterName = filterName;
	}

	public String getFilterOption() {
		return filterOption;
	}

	public void setFilterOption(String filterOption) {
		this.filterOption = filterOption;
	}
}
