package com.ubs.wmap.eisl.dataserviceregistry.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ubs.wmap.eisl.dataserviceregistry.constant.DataReferenceConstant;
import com.ubs.wmap.eisl.dataserviceregistry.exception.DataReferenceException;
import com.ubs.wmap.eisl.dataserviceregistry.exception.DataReferenceNotFoundException;
import com.ubs.wmap.eisl.dataserviceregistry.model.DataReference;
import com.ubs.wmap.eisl.dataserviceregistry.service.DataReferenceService;
import com.ubs.wmap.eisl.dataserviceregistry.vo.DataReferenceRequest;
import com.ubs.wmap.eisl.dataserviceregistry.vo.DataReferenceResponse;

/**
 * @author Gananath
 *
 */
@RestController
public class DataServiceRegistryController {

	private static final Logger LOG = LoggerFactory.getLogger(DataServiceRegistryController.class);
	@Autowired
	private DataReferenceService dataReferenceService;
	
	@GetMapping(DataReferenceConstant.DATA_REFERENCE_GET_ENDPOINT)
	public ResponseEntity<DataReferenceResponse> getDataReferenceDetails(@RequestParam("token") String token)
			throws DataReferenceException {
		LOG.debug("Controller Enetr: Entering getDataReferenceDetails");
		LOG.debug("token:{}",token);
		DataReferenceResponse dataReference = null;
		try {
			// Need to remove
			DataReferenceRequest request = new DataReferenceRequest();
			request.setDataServiceId(1);
			dataReference = dataReferenceService.getDataReference(request);
			if (null == dataReference) {
				LOG.debug("Controller Exit: Exiting getDataReferenceDetails");
				throw new DataReferenceNotFoundException(DataReferenceConstant.DATA_REFERENCE_NOT_FOUND);
			}
		} catch (DataReferenceException ex) {
			LOG.debug("Controller Exit: Exiting getDataReferenceDetails");
			throw new DataReferenceException(DataReferenceConstant.INTERNAL_SERVER_ERROR_MSG);
		}
		LOG.debug("Controller Exit: Exiting getDataReferenceDetails");
		return ResponseEntity.ok(dataReference);
	}
	
	@PostMapping("/create")
	public ResponseEntity<DataReference> postDataReference(@RequestBody DataReference dataReference) {
		DataReference persistDataReference = null;
		try {
			persistDataReference = dataReferenceService.persistDataReference(dataReference);
		} catch (DataReferenceException e) {
			e.printStackTrace();
		}
		if(persistDataReference != null) {
			return ResponseEntity.ok(persistDataReference);
		}
		return new ResponseEntity<DataReference>(HttpStatus.NOT_FOUND);
	}
}
