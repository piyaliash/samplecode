package com.ubs.wmap.eisl.dataserviceregistry.constant;

public interface DataReferenceConstant {

   public static final String DATA_REFERENCE_NOT_FOUND = "Data reference not found";
   public static final String INTERNAL_SERVER_ERROR_MSG="Internal server error occured";
   public static final String DATA_REFERENCE_GET_ENDPOINT="/eisl/data/v1/data";
}
