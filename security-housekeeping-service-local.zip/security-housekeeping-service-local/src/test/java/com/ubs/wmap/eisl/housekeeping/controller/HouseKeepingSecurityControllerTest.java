package com.ubs.wmap.eisl.housekeeping.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sun.org.apache.xpath.internal.operations.Bool;
import com.ubs.wmap.eisl.housekeeping.TokenService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.Map;

import static org.junit.Assert.*;

@Slf4j
@ActiveProfiles("test")
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.DEFINED_PORT)
public class HouseKeepingSecurityControllerTest {

    @Autowired
    private TokenService tokenService;

    @Autowired
    private TestRestTemplate restTemplate;

    @Autowired
    private ObjectMapper mapper;

    @Value("${service.message.INTERNAL_SERVER_ERROR_MSG}")
    private String INTERNAL_SERVER_ERROR_MSG;

    @Value("${service.testingEndPointValidate}")
    private String VALIDATE_END_POINT;

    @Value("${service.testingEndPointUnwrap}")
    private String UNWRAP_END_POINT;

    @Test
    public void testValidateEISLToken() {

        String uri = UriComponentsBuilder.fromHttpUrl(VALIDATE_END_POINT)
                .queryParam("token", tokenService.init("utkarsh","acct-create", "consumer"))
                .toUriString();
        ResponseEntity<String> response = this.restTemplate.getForEntity(uri, String.class);
        String resp = response.getBody();
        log.info(resp);

        assertEquals(HttpStatus.OK.value(), response.getStatusCodeValue());
        assertEquals(resp, "true");


    }

    @Test
    public void testUnWrapEislToken()  throws Exception{

        String uri = UriComponentsBuilder.fromHttpUrl(UNWRAP_END_POINT)
                .queryParam("token", tokenService.init("utkarsh","acct-create", "consumer"))
                .toUriString();
        ResponseEntity<String> response = this.restTemplate.getForEntity(uri, String.class);

        Map<String, Object> resp = mapper.readValue(response.getBody(), Map.class);
        log.info(response.getBody());

        assertEquals(HttpStatus.OK.value(), response.getStatusCodeValue());
        assertEquals(resp.get("role"), "consumer");
    }
}