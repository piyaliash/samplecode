package com.ubs.wmap.eisl.housekeeping.controller;

import com.ubs.wmap.eisl.housekeeping.TokenService;
import io.jsonwebtoken.Claims;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.constraints.NotBlank;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

@RestController
@Slf4j
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@RequestMapping(value = "/eisl/security/v1/", produces = "application/json")
public class HouseKeepingSecurityController {

	private final TokenService tokenService;

	@Value("${service.message.INTERNAL_SERVER_ERROR_MSG}")
	private String INTERNAL_SERVER_ERROR_MSG;

	@GetMapping("/validate")
	public Boolean validateEISLToken( @NotBlank @RequestParam("token") final String eislToken) {
		return tokenService.isEISLTokenValid(eislToken);
	}

	@GetMapping("/unwrap")
	public ResponseEntity<Object> unWrapEislToken(@NotBlank @RequestParam("token") final String eislToken) throws Exception{
		Claims unwrapEislToken = null;
		try {
			 unwrapEislToken = tokenService.unwrapEislToken(eislToken);
		}catch (Exception e) {
			throw new Exception(INTERNAL_SERVER_ERROR_MSG);
		}

		Map<String, Object> mapFromIoJsonwebtokenClaims = getMapFromIoJsonwebtokenClaims(unwrapEislToken);
		return ResponseEntity.ok()
				.body(mapFromIoJsonwebtokenClaims);

	}
	
	private Map<String, Object>  getMapFromIoJsonwebtokenClaims(Claims claims){
		Map<String, Object> expectedMap = new HashMap<String, Object>();
	    for(Entry<String, Object> entry : claims.entrySet()) {
	        expectedMap.put(entry.getKey() , entry.getValue());
	    }
	    return expectedMap;
	}
}
