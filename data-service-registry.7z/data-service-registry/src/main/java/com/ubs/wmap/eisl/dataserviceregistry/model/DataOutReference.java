package com.ubs.wmap.eisl.dataserviceregistry.model;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "DATA_OUT_REFERENCE")
public class DataOutReference implements Serializable{

	private static final long serialVersionUID = 6524059507619584069L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "Data_out_reference_id")
	private Integer dataOutReferenceId;
	
	@Column(name = "Protocol_name")
	private String protocolName;
	
	@Column(name = "Data_type")
	private String dataType;
	
	@Column(name = "topic")
	private String topic;
	
	@ManyToOne
	@JoinColumn(name="Data_reference_id", nullable=false)
	private DataReference dataOutReference;
	
	@OneToOne(mappedBy = "dataOutReference", cascade = CascadeType.ALL,
            fetch = FetchType.LAZY, optional = false)
	private DataFilterReference dataFilterReference;
	public Integer getDataOutReferenceId() {
		return dataOutReferenceId;
	}

	public void setDataOutReferenceId(Integer dataOutReferenceId) {
		this.dataOutReferenceId = dataOutReferenceId;
	}

	public DataReference getDataOutReference() {
		return dataOutReference;
	}

	public void setDataOutReference(DataReference dataOutReference) {
		this.dataOutReference = dataOutReference;
	}

	public DataFilterReference getDataFilterReference() {
		return dataFilterReference;
	}

	public void setDataFilterReference(DataFilterReference dataFilterReference) {
		this.dataFilterReference = dataFilterReference;
	}

	public String getProtocolName() {
		return protocolName;
	}

	public void setProtocolName(String protocolName) {
		this.protocolName = protocolName;
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	public String getTopicName() {
		return topic;
	}

	public void setTopicName(String topic) {
		this.topic = topic;
	}
}
