package com.ubs.wmap.eisl.dataserviceregistry.vo;

import java.io.Serializable;

public class DataFilterReferenceRequest implements Serializable{
	
	private static final long serialVersionUID = -3472612466681432828L;
	
	private Integer filterRefernceId;
	private String name;
	private String options;
	
	public Integer getFilterRefernceId() {
		return filterRefernceId;
	}
	public void setFilterRefernceId(Integer filterRefernceId) {
		this.filterRefernceId = filterRefernceId;
	}
	
	@Override
	public String toString() {
        return new StringBuilder("filterRefernceId:").append(filterRefernceId)
        		.append("filterName").append(name)
        		.append("filterOption").append(options)
        		.toString();
    }
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getOptions() {
		return options;
	}
	public void setOptions(String options) {
		this.options = options;
	}
}
