package com.ubs.wmap.eisl.dataserviceregistry.model;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "DATA_REFERENCE")
public class DataReference implements Serializable{

	private static final long serialVersionUID = 8682370259634234471L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "Data_reference_id")
	private Integer dataReferenceId;
	
	@Column(name = "Data_service_id")
	private String dataServiceId;
	
	@Column(name = "Data_in_topic")
	private String dataInTopic;
	
	@OneToMany(mappedBy="dataOutReference", cascade=CascadeType.ALL)
	private Set<DataOutReference> dataOutReferences;
	
	public Integer getDataReferenceId() {
		return dataReferenceId;
	}

	public void setDataReferenceId(Integer dataReferenceId) {
		this.dataReferenceId = dataReferenceId;
	}

	public String getDataInTopi() {
		return dataInTopic;
	}

	public void setDataInTopi(String dataInTopi) {
		this.dataInTopic = dataInTopi;
	}
	public Set<DataOutReference> getDataOutReferences() {
		return dataOutReferences;
	}

	public void setDataOutReferences(Set<DataOutReference> dataOutReferences) {
		this.dataOutReferences = dataOutReferences;
	}

	public String getDataServiceId() {
		return dataServiceId;
	}

	public void setDataServiceId(String dataServiceId) {
		this.dataServiceId = dataServiceId;
	}

	public String getDataInTopic() {
		return dataInTopic;
	}

	public void setDataInTopic(String dataInTopic) {
		this.dataInTopic = dataInTopic;
	}
	
}
