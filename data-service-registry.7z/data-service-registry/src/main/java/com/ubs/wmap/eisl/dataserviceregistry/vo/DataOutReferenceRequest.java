package com.ubs.wmap.eisl.dataserviceregistry.vo;

import java.io.Serializable;
import java.util.Set;

import com.ubs.wmap.eisl.dataserviceregistry.model.DataFilterReference;


public class DataOutReferenceRequest implements Serializable {
	
	
	private static final long serialVersionUID = -83396507865626884L;
	
	private Integer dataOutReferenceId;
	private String protocolName;
	private String dataType;
	private String topic;
	private DataFilterReferenceRequest dataFilterReferenceRequest;
	public String getProtocolName() {
		return protocolName;
	}
	public void setProtocolName(String protocolName) {
		this.protocolName = protocolName;
	}
	public String getDataType() {
		return dataType;
	}
	public void setDataType(String dataType) {
		this.dataType = dataType;
	}
	
	public Integer getDataOutReferenceId() {
		return dataOutReferenceId;
	}
	public void setDataOutReferenceId(Integer dataOutReferenceId) {
		this.dataOutReferenceId = dataOutReferenceId;
	}
	@Override
	public String toString() {
        return new StringBuilder ("dataOutReferenceId:").append(dataOutReferenceId)
        		.append("protocolName:").append(protocolName)
        		.append("dataType").append(dataType)
        		.append("topic").append(topic)
        		.toString();
    }
	public DataFilterReferenceRequest getDataFilterReferenceRequest() {
		return dataFilterReferenceRequest;
	}
	public void setDataFilterReferenceRequest(DataFilterReferenceRequest dataFilterReferenceRequest) {
		this.dataFilterReferenceRequest = dataFilterReferenceRequest;
	}
	public String getTopic() {
		return topic;
	}
	public void setTopic(String topic) {
		this.topic = topic;
	}
}
