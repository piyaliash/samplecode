package com.ubs.wmap.eisl.dataserviceregistry.vo;

import java.io.Serializable;

public class DataFilterResponse implements Serializable{

	private static final long serialVersionUID = 228694173931964139L;
	
	private Integer filterRefernceId;
	private String name;
	private String options;
	public Integer getFilterRefernceId() {
		return filterRefernceId;
	}
	public void setFilterRefernceId(Integer filterRefernceId) {
		this.filterRefernceId = filterRefernceId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getOptions() {
		return options;
	}
	public void setOptions(String options) {
		this.options = options;
	}
	
}
