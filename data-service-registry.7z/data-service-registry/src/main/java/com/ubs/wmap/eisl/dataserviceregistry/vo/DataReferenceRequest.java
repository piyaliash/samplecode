package com.ubs.wmap.eisl.dataserviceregistry.vo;

import java.io.Serializable;
import java.util.List;

public class DataReferenceRequest implements Serializable {

	private static final long serialVersionUID = -83396507865626884L;
	
	private String dataServiceId;
	private String dataInTopic;
	
	private List<DataOutReferenceRequest> outReferenceRequests;
	
	public List<DataOutReferenceRequest> getOutReferenceRequests() {
		return outReferenceRequests;
	}
	public void setOutReferenceRequests(List<DataOutReferenceRequest> outReferenceRequests) {
		this.outReferenceRequests = outReferenceRequests;
	}
	
	public String getDataInTopic() {
		return dataInTopic;
	}
	public void setDataInTopic(String dataInTopic) {
		this.dataInTopic = dataInTopic;
	}

	@Override
	public String toString() {
        return new StringBuilder("dataServiceId:").append(dataServiceId)
        		.append("dataInTopic").append(dataInTopic)
        		.toString();
    }
	public String getDataServiceId() {
		return dataServiceId;
	}
	public void setDataServiceId(String dataServiceId) {
		this.dataServiceId = dataServiceId;
	}
	
}
