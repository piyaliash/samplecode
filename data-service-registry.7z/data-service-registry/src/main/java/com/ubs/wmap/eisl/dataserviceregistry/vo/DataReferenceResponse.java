package com.ubs.wmap.eisl.dataserviceregistry.vo;

import java.io.Serializable;
import java.util.Set;

public class DataReferenceResponse implements Serializable {

	private static final long serialVersionUID = -598494958569462261L;
	
	private Integer dataReferenceId;
	private String dataServiceId;
	private String dataInTopic;
	private Set<DataOutReferenceResponse> dataOutReferences;
	public Integer getDataReferenceId() {
		return dataReferenceId;
	}
	public void setDataReferenceId(Integer dataReferenceId) {
		this.dataReferenceId = dataReferenceId;
	}
	public String getDataServiceId() {
		return dataServiceId;
	}
	public void setDataServiceId(String dataServiceId) {
		this.dataServiceId = dataServiceId;
	}
	public String getDataInTopic() {
		return dataInTopic;
	}
	public void setDataInTopic(String dataInTopic) {
		this.dataInTopic = dataInTopic;
	}
	public Set<DataOutReferenceResponse> getDataOutReferences() {
		return dataOutReferences;
	}
	public void setDataOutReferences(Set<DataOutReferenceResponse> dataOutReferences) {
		this.dataOutReferences = dataOutReferences;
	}
}
