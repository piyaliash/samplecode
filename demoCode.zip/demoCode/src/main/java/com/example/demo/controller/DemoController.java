package com.example.demo.controller;

import com.example.demo.service.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.NotBlank;
import java.util.HashMap;

@RestController
@RequestMapping(value = "/web-test")
public class DemoController {

    @Autowired
    Test test;


    @GetMapping(value = "/producer")
    public String getRegistry() {
        System.out.println("test first");
        try {
            test.test();
        }catch(Exception ex){

        }
        System.out.println("test");
        return "ok";
    }
}
