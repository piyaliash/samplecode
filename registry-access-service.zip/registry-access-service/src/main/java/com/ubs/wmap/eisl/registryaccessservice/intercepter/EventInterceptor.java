package com.ubs.wmap.eisl.registryaccessservice.intercepter;

import java.io.IOException;
import java.time.LocalDateTime;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import lombok.RequiredArgsConstructor;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.servlet.HandlerInterceptor;
import com.ubs.wmap.eisl.housekeeping.TokenService;
import com.ubs.wmap.eisl.registryaccessservice.context.EislClaimsContext;
import com.ubs.wmap.eisl.registryaccessservice.context.EislClaimsContextHolder;

import io.jsonwebtoken.Claims;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class EventInterceptor implements HandlerInterceptor {

	public static final String TIMESTAMP="timestamp";
	public static final String STATUS="status";
	public static final String MESSAGE="message";
	
	private final TokenService tokenService;
	
	@Value("${service.message.EISL_INVALID_TOKEN_MSG}")
	private String EISL_INVALID_TOKEN_MSG;
	
	@Value("${service.message.EISL_TOKEN_EMPTY_MSG}")
	private String EISL_TOKEN_EMPTY_MSG;

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		try {
			String eislToken=request.getParameter("eislToken");
			log.debug("eislToken from request param:{}",eislToken);
			
			if(StringUtils.isEmpty(eislToken)) {
				 constructErrorResponseObject(request,response,EISL_TOKEN_EMPTY_MSG,
							HttpServletResponse.SC_BAD_REQUEST);
				 return false;
			}
			
			log.debug("eislToken:{}", eislToken);
			boolean isValidToken = tokenService.isEISLTokenValid(eislToken);
			log.debug("isValidToken:{}", isValidToken);
			if (!isValidToken) {
				 constructErrorResponseObject(request,response,EISL_INVALID_TOKEN_MSG,
							HttpServletResponse.SC_UNAUTHORIZED);
				return false;
			}
			
			Claims claims = tokenService.unwrapEislToken(eislToken);
			createAndSetClaimsInContext(claims);
		}catch(Exception e) {
			constructErrorResponseObject(request,response,EISL_INVALID_TOKEN_MSG,
					HttpServletResponse.SC_UNAUTHORIZED);
			return false;
		}
		return true;
	}
	
	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, 
	      Object handler, Exception exception) throws Exception {
		EislClaimsContextHolder.remove();
	}
	
	private void createAndSetClaimsInContext(Claims claims) {
		EislClaimsContext eislClaimsContext = new EislClaimsContext();
		eislClaimsContext.setClaims(claims);
		EislClaimsContextHolder.set(eislClaimsContext);
	}
	
	private void constructErrorResponseObject(HttpServletRequest request, HttpServletResponse 
			response,String message, int status) {
		
		JSONObject jSONObject = createJsonErrorObject(message,status);
		setErrorInHttpRequestResponse(request, response, status,jSONObject);
		
	}

	private JSONObject createJsonErrorObject(String message, int status) {
		JSONObject json = new JSONObject();
		json.put(TIMESTAMP, LocalDateTime.now());
		json.put(STATUS, status);
		json.put(MESSAGE,message );
		return json;
	}

	private void setErrorInHttpRequestResponse(HttpServletRequest httpRequest, 
			HttpServletResponse httpResponse, int status, JSONObject json) {
		httpResponse.addHeader("Content-Type", "application/json");
		try {
			httpResponse.setStatus(status);
			httpResponse.getWriter().write(json.toString());
			httpResponse.getWriter().flush();
			httpResponse.getWriter().close();
		} catch (IOException e) {
			log.error(e.getMessage());
		}
	}
}
