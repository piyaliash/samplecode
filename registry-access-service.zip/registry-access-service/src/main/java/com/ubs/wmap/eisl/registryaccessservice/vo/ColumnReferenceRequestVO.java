package com.ubs.wmap.eisl.registryaccessservice.vo;

import java.io.Serializable;
import lombok.Data;

@Data
public class ColumnReferenceRequestVO implements Serializable {

	private static final long serialVersionUID = -4254569322670907803L;
	private String name;
	private String type;
	private String jsonModel;
	private String projectionId;
}
