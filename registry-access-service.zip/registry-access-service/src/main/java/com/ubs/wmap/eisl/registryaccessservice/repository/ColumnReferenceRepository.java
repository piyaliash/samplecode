package com.ubs.wmap.eisl.registryaccessservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ubs.wmap.eisl.registryaccessservice.model.ColumnReference;

@Repository
public interface ColumnReferenceRepository extends JpaRepository<ColumnReference, Integer>{

}
