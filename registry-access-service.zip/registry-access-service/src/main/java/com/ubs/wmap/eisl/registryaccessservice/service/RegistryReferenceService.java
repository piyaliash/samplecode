package com.ubs.wmap.eisl.registryaccessservice.service;

import com.ubs.wmap.eisl.registryaccessservice.exception.RegistryReferenceException;
import com.ubs.wmap.eisl.registryaccessservice.vo.RegistrationRequestVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.RegistrationResponseVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.RegistryAccessRequestVO;

public interface RegistryReferenceService {
	
	/**
	 * @param registryAccessRequestVO
	 * 		  	Contains serviceId as a mandatory parameter for query
	 * @return RegistrationResponseVO
	 * 			If found, contains registration and its associate child entities,
	 * 			null, if not found
	 * @throws RegistryReferenceException
	 */
	public RegistrationResponseVO getRegistryReference(RegistryAccessRequestVO registryAccessRequestVO)
			throws RegistryReferenceException;
	
	
	
	/**
	 * Persist registration details into database
	 * @param registrationRequestVO
	 * 			Contains Registration details which will be saved to db
	 * @return RegistrationResponseVO
	 * 			If created, contains registration and its associate child entities,
	 * 			null, if not found
	 * @throws RegistryReferenceException
	 */
	public RegistrationResponseVO persistRegistry(RegistrationRequestVO registrationRequestVO)throws RegistryReferenceException;
	
}
