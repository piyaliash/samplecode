
package com.ubs.wmap.eisl.dataPolicyService.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value= HttpStatus.INTERNAL_SERVER_ERROR)
public class PolicyNotFoundException extends Exception{
    
    public PolicyNotFoundException(String message) {
        super(message);
    }
    
}
