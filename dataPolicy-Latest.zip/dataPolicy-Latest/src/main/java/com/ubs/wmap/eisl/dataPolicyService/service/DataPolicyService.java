
package com.ubs.wmap.eisl.dataPolicyService.service;

import com.ubs.wmap.eisl.dataPolicyService.exception.PolicyNotFoundException;
import com.ubs.wmap.eisl.dataPolicyService.model.DataPolicy;
import java.util.List;

public interface DataPolicyService {

    public List<DataPolicy> loadAll() throws PolicyNotFoundException;
  
    public DataPolicy getDataPolicy(Long policyId) throws PolicyNotFoundException;

 
}
