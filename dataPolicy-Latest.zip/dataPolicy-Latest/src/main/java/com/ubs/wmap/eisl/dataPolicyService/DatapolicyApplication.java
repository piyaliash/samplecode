package com.ubs.wmap.eisl.dataPolicyService;

import com.ubs.wmap.eisl.housekeeping.TokenServiceConfiguration;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Import;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@Import(TokenServiceConfiguration.class)
@EnableJpaRepositories
public class DatapolicyApplication {

	public static void main(String[] args) {
		SpringApplication.run(DatapolicyApplication.class, args);
	}

}
