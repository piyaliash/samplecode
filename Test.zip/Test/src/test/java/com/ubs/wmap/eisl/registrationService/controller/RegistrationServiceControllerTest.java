package com.ubs.wmap.eisl.registrationService.controller;

import com.sun.org.apache.xpath.internal.Arg;
import com.ubs.wmap.eisl.housekeeping.component.TokenServiceImpl;
import com.ubs.wmap.eisl.registrationService.exception.*;
import com.ubs.wmap.eisl.registrationService.model.PayloadSO;
import com.ubs.wmap.eisl.registrationService.model.RegistrationSO;
import com.ubs.wmap.eisl.registrationService.model.ResponseSO;
import com.ubs.wmap.eisl.registrationService.service.RegistrationServiceImpl;
import com.ubs.wmap.eisl.registrationService.util.EislUtil;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;


@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class RegistrationServiceControllerTest {

    @MockBean
    RegistrationServiceImpl registrationService;

    @MockBean
    EislUtil controllerUtil;

    @Autowired
    RegistrationServiceController regServiceController;

    @Autowired
    TokenServiceImpl tokenService;

    @Test
    public void getRegistryTest() throws Exception {
        String eislToken = tokenService.createEILSToken("testUser","testServiceId","testRole");
        ResponseSO response = new ResponseSO();
        ResponseEntity<ResponseSO> expected = ResponseEntity.ok(response);
        Map<String, Object> claims = new HashMap<>();
        claims.put("serviceId","testServiceId");
        Mockito.when(controllerUtil.getEislClaims(ArgumentMatchers.anyString())).thenReturn(claims);
        Mockito.when(registrationService.getRegistration(ArgumentMatchers.anyString(),ArgumentMatchers.anyString(),ArgumentMatchers.anyString())).thenReturn(response);
        ResponseEntity<ResponseSO> result = regServiceController.getRegistry("testAuth",eislToken,"testRole");
        assertEquals("success", expected,result);
    }

    @Test
    public void postRegistrationTest() throws Exception {
        String eislToken = tokenService.createEILSToken("testUser","testServiceId","testRole");
        RegistrationSO response = new RegistrationSO();
        PayloadSO payload = new PayloadSO();
        ResponseEntity<RegistrationSO> expected = ResponseEntity.ok(response);
        Map<String, Object> claims = new HashMap<>();
        claims.put("serviceId","testServiceId");
        Mockito.when(controllerUtil.getEislClaims(ArgumentMatchers.anyString())).thenReturn(claims);
        Mockito.when(registrationService.postRegistration(ArgumentMatchers.anyString(),ArgumentMatchers.any(PayloadSO.class),ArgumentMatchers.anyString())).thenReturn(response);
        ResponseEntity<RegistrationSO> result = regServiceController.addRegistry("testAuth",eislToken,payload);
        assertEquals("success", expected,result);
    }

    @Test
    public void updateRegistration() throws Exception {
        String eislToken = tokenService.createEILSToken("testUser","testServiceId","testRole");
        RegistrationSO response = new RegistrationSO();
        PayloadSO payload = new PayloadSO();
        ResponseEntity<RegistrationSO> expected = ResponseEntity.ok(response);
        Map<String, Object> claims = new HashMap<>();
        claims.put("serviceId","testServiceId");
        Mockito.when(controllerUtil.getEislClaims(ArgumentMatchers.anyString())).thenReturn(claims);
        Mockito.when(registrationService.putRegistration(ArgumentMatchers.anyString(),ArgumentMatchers.any(PayloadSO.class),ArgumentMatchers.anyString())).thenReturn(response);
        ResponseEntity<RegistrationSO> result = regServiceController.updateRegistry("testAuth",eislToken,payload);
        assertEquals("success", expected,result);
    }

    @Test
    public void deleteRegistry() throws Exception {
        String eislToken = tokenService.createEILSToken("testUser","testServiceId","testRole");
        String response = HttpStatus.OK.toString();
        ResponseEntity<Object> expected = ResponseEntity.ok(response);
        Map<String, Object> claims = new HashMap<>();
        claims.put("serviceId","testServiceId");
        claims.put("role","testrole");
        Mockito.when(controllerUtil.getEislClaims(ArgumentMatchers.anyString())).thenReturn(claims);
        Mockito.when(registrationService.deleteRegistration(ArgumentMatchers.anyString(),ArgumentMatchers.anyString(),ArgumentMatchers.anyString())).thenReturn(response);
        ResponseEntity<String> result = regServiceController.deleteRegistry("testAuth",eislToken);
        assertEquals("success",expected.getStatusCode(),result.getStatusCode());
    }

    @Test(expected = DataNotFoundException.class)
    public void getRegistryTestDataNotFound() throws Exception {
        String eislToken = tokenService.createEILSToken("testUser","testServiceId","testRole");
        ResponseSO response = new ResponseSO();
        ResponseEntity<ResponseSO> expected = ResponseEntity.ok(response);
        Map<String, Object> claims = new HashMap<>();
        claims.put("serviceId","testServiceId");
        Mockito.when(controllerUtil.getEislClaims(ArgumentMatchers.anyString())).thenReturn(claims);
        Mockito.when(registrationService.getRegistration(ArgumentMatchers.anyString(),ArgumentMatchers.anyString(),ArgumentMatchers.anyString())).thenThrow(DataNotFoundException.class);
        regServiceController.getRegistry("testAuth",eislToken,"testRole");
    }

    @Test(expected = RegistrationServiceException.class)
    public void getRegistryTestRegServiceException() throws Exception {
        String eislToken = tokenService.createEILSToken("testUser","testServiceId","testRole");
        ResponseSO response = new ResponseSO();
        ResponseEntity<ResponseSO> expected = ResponseEntity.ok(response);
        Map<String, Object> claims = new HashMap<>();
        claims.put("serviceId","testServiceId");
        Mockito.when(controllerUtil.getEislClaims(ArgumentMatchers.anyString())).thenReturn(claims);
        Mockito.when(registrationService.getRegistration(ArgumentMatchers.anyString(),ArgumentMatchers.anyString(),ArgumentMatchers.anyString())).thenThrow(RegistrationServiceException.class);
        regServiceController.getRegistry("testAuth",eislToken,"testRole");
    }


    @Test(expected = BadRequestException.class)
    public void getRegistryTestBadReqException() throws Exception {
        String eislToken = tokenService.createEILSToken("testUser","testServiceId","testRole");
        ResponseSO response = new ResponseSO();
        ResponseEntity<ResponseSO> expected = ResponseEntity.ok(response);
        Map<String, Object> claims = new HashMap<>();
        Mockito.when(controllerUtil.getEislClaims(ArgumentMatchers.anyString())).thenReturn(claims);
        Mockito.when(registrationService.getRegistration(ArgumentMatchers.anyString(),ArgumentMatchers.anyString(),ArgumentMatchers.anyString())).thenThrow(RegistrationServiceException.class);
        regServiceController.getRegistry("testAuth",eislToken,"testRole");
    }

    @Test(expected = DataException.class)
    public void getRegistryTestDataException() throws Exception {
        String eislToken = tokenService.createEILSToken("testUser","testServiceId","testRole");
        Map<String, Object> claims = new HashMap<>();
        claims.put("serviceId","testServiceId");
        Mockito.when(controllerUtil.getEislClaims(ArgumentMatchers.anyString())).thenReturn(claims);
        Mockito.when(registrationService.getRegistration(ArgumentMatchers.anyString(),ArgumentMatchers.anyString(),ArgumentMatchers.anyString())).thenThrow(EislTokenNotValidException.class);
        regServiceController.getRegistry("testAuth",eislToken,"testRole");
    }

    @Test(expected = DataException.class)
    public void postRegistrationDataExceptionTest() throws Exception {
        String eislToken = tokenService.createEILSToken("testUser","testServiceId","testRole");
        PayloadSO payload = new PayloadSO();
        Map<String, Object> claims = new HashMap<>();
        claims.put("serviceId","testServiceId");
        Mockito.when(controllerUtil.getEislClaims(ArgumentMatchers.anyString())).thenReturn(claims);
        Mockito.when(registrationService.postRegistration(ArgumentMatchers.anyString(),ArgumentMatchers.any(PayloadSO.class),ArgumentMatchers.anyString())).thenThrow(DataNotFoundException.class);
        regServiceController.addRegistry("testAuth",eislToken,payload);
    }

    @Test(expected = EislTokenNotValidException.class)
    public void postRegistrationBadReqExceptionTest() throws Exception {
        String eislToken = tokenService.createEILSToken("testUser","testServiceId","testRole");
        PayloadSO payload = new PayloadSO();
        Map<String, Object> claims = new HashMap<>();
        Mockito.when(controllerUtil.getEislClaims(ArgumentMatchers.anyString())).thenReturn(claims);
        Mockito.when(registrationService.postRegistration(ArgumentMatchers.anyString(),ArgumentMatchers.any(PayloadSO.class),ArgumentMatchers.anyString())).thenThrow(DataNotFoundException.class);
        regServiceController.addRegistry("testAuth",eislToken,payload);
    }

    @Test(expected = DataException.class)
    public void updateRegistrationDataExceptionTest() throws Exception {
        String eislToken = tokenService.createEILSToken("testUser","testServiceId","testRole");
        PayloadSO payload = new PayloadSO();
        Map<String, Object> claims = new HashMap<>();
        claims.put("serviceId","testServiceId");
        Mockito.when(controllerUtil.getEislClaims(ArgumentMatchers.anyString())).thenReturn(claims);
        Mockito.when(registrationService.putRegistration(ArgumentMatchers.anyString(),ArgumentMatchers.any(PayloadSO.class),ArgumentMatchers.anyString())).thenThrow(DataNotFoundException.class);
        regServiceController.updateRegistry("testAuth",eislToken,payload);
    }

    @Test(expected = EislTokenNotValidException.class)
    public void updateRegistrationEislNotValidTest() throws Exception {
        String eislToken = tokenService.createEILSToken("testUser","testServiceId","testRole");
        PayloadSO payload = new PayloadSO();
        Map<String, Object> claims = new HashMap<>();
        Mockito.when(controllerUtil.getEislClaims(ArgumentMatchers.anyString())).thenReturn(claims);
        Mockito.when(registrationService.putRegistration(ArgumentMatchers.anyString(),ArgumentMatchers.any(PayloadSO.class),ArgumentMatchers.anyString())).thenThrow(EislTokenNotValidException.class);
        regServiceController.updateRegistry("testAuth",eislToken,payload);
    }

    @Test(expected = EislTokenNotValidException.class)
    public void deleteRegistryEislNotValidTest() throws Exception {
        String eislToken = tokenService.createEILSToken("testUser","testServiceId","testRole");
        ResponseSO response = new ResponseSO();
        Map<String, Object> claims = new HashMap<>();
        Mockito.when(controllerUtil.getEislClaims(ArgumentMatchers.anyString())).thenReturn(claims);
//        Mockito.when(registrationService.deleteRegistration(ArgumentMatchers.anyString(),ArgumentMatchers.anyString())).thenReturn(response);
        regServiceController.deleteRegistry("testAuth",eislToken);
    }

    }
