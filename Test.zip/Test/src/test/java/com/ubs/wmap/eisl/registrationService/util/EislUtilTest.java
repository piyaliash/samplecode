package com.ubs.wmap.eisl.registrationService.util;

import com.ubs.wmap.eisl.housekeeping.TokenService;
import com.ubs.wmap.eisl.registrationService.exception.BadRequestException;
import com.ubs.wmap.eisl.registrationService.exception.DataNotFoundException;
import com.ubs.wmap.eisl.registrationService.exception.EislTokenNotValidException;
import com.ubs.wmap.eisl.registrationService.exception.RegistrationServiceException;
import com.ubs.wmap.eisl.registrationService.model.RegistrationSO;
import com.ubs.wmap.eisl.registrationService.util.EislUtil;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

import static org.springframework.test.web.client.match.MockRestRequestMatchers.method;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withServerError;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withStatus;

@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class EislUtilTest  {
    @Autowired
    TokenService tokenService;

    @Autowired
    EislUtil eislUtil;

    @Autowired
    RestTemplate restTemplate;


    @Test
    public void testgetEislClaims() throws RegistrationServiceException, EislTokenNotValidException {
        String eislToken=tokenService.createEILSToken("test","test","test");
        Map<String, Object> response= eislUtil.getEislClaims(eislToken);
        Assert.assertEquals("Return valid eislToken ",response.get("userName"),"test");
    }

    @Test(expected= EislTokenNotValidException.class)
    public void returnExpiredEislTokenTest() throws RegistrationServiceException, EislTokenNotValidException {
        String eislToken="eyJhbGciOiJSUzI1NiJ9.eyJlbnRpdGxlbWVudHMiOnsiUkVBRE9OTFlfUEVSTUlTU0lPTlMiOjMyMzMxMiwiRlVMTF9BQ0NFU1NfUEVSTUlTU0lPTlMiOjk4NzY1NCwiRURJVF9QRVJNSVNTSU9OUyI6MTQ1MzIyLCJBRE1JTl9QRVJNSVNTSU9OUyI6NjM2MzY2fSwicm9sZSI6ImNvbnN1bWVyIiwiY29ycmVsYXRpb25JZCI6ImNhZDRkOTQ4LTE2M2EtNDViNy04ZjRjLTQ4Y2Q0NjhjNzRjNyIsInVzZXJOYW1lIjoiYWhzYW4xMjMiLCJzZXJ2aWNlSWQiOiJlaXNsLWFjY291bnQtdXBkYXRlcyIsImV4cCI6MTU1ODEyOTgzNiwianRpIjoiYzQwM2Y5MGUtZjc5My00ZTIzLThjNjYtYTM0NDIzNTRhOWIwIn0.Q68zsyYRddWb3yLNk_ybup9V9b2TpTWfQDJf2h4uboOzUafhm--U7cNpkYhkFWJ5h4mCfB2sIiC0nqw0xYSc24FLI47kDZ3mH-napCAXw95Yd58kJj3iG0_4oXVo9rj4FVWoCqc710-WwVpWV7yaZymQG99I2MDfHRuhLUG7Wdd_TMh4Ym0fiRDmEDGLNM4Kjoe0bkVieK41Nm7kxPrl3g3x_J-MwjJN0wo5Mrg9wGzfJBD_qbMhZ7V0voRC2xMgCRSsWwYwP2una2jTgp3GCsdX2Q2oub_0KIXuJao7lp0cq9C-jLidCPGeEYhfRdPEHSKs537SHeA3rik8iGcdOfEcqpMThyABxcMcl1OM7AMe6IStlKJ-oEid-nMsoWTAFz6ATpfqtiF0WTSF-vUJq4cOVCw7TX7-0CXdm_0-wHEyUHpa7UeHerx1UvQZBaODjPR7AMgFc6NPYYnnOQhOg7XE5YCZyBpdpjp5vyECkUfO4ymzmlvboq3cMIMfcLpMP5T7CMWuYO0RY-pft6_6L8T9oicMjJgVw-hM6CsupB4k9vCsbiGK1E2W63XWBJFhpIxIVLtgfKxJtheUeuXXxdtuvSERphldinu0ZOt61MMueIKdqjb3GgMItSqHo9fTvkFonBRvZJnqbia5jUTwORz0QHFsicGjXiuelrIr6D0";
        Map<String, Object> response= eislUtil.getEislClaims(eislToken);
    }

    @Test(expected= EislTokenNotValidException.class)
    public void returnInValidEislTokenTest() throws RegistrationServiceException, EislTokenNotValidException {
        String eislToken="invalidToken";
        Map<String, Object> response= eislUtil.getEislClaims(eislToken);
    }


    @Test (expected = DataNotFoundException.class)
    public void testResclientDataNotFoundException() throws BadRequestException, DataNotFoundException, EislTokenNotValidException {
        HttpClientErrorException ex = new HttpClientErrorException(HttpStatus.NOT_FOUND);
        eislUtil.validateRestClientExceptionForEvents(ex);
    }

    @Test (expected = BadRequestException.class)
    public void testResclientExceptionBadRequest() throws BadRequestException, DataNotFoundException, EislTokenNotValidException {
        HttpClientErrorException ex = new HttpClientErrorException(HttpStatus.BAD_REQUEST);
        eislUtil.validateRestClientExceptionForEvents(ex);
    }

    @Test (expected = EislTokenNotValidException.class)
    public void testResclientExceptionunauthorozed() throws BadRequestException, DataNotFoundException, EislTokenNotValidException {
        HttpClientErrorException ex = new HttpClientErrorException(HttpStatus.UNAUTHORIZED);
        eislUtil.validateRestClientExceptionForEvents(ex);
    }

    @Test (expected = DataNotFoundException.class)
    public void testResclientDataNotFoundExceptionForcheckException() throws BadRequestException, DataNotFoundException, EislTokenNotValidException {
        HttpClientErrorException ex = new HttpClientErrorException(HttpStatus.NOT_FOUND);
        eislUtil.checkException(ex);
    }

    @Test (expected = BadRequestException.class)
    public void testResclientExceptionBadRequestForcheckException() throws BadRequestException, DataNotFoundException, EislTokenNotValidException {
        HttpClientErrorException ex = new HttpClientErrorException(HttpStatus.BAD_REQUEST);
        eislUtil.checkException(ex);
    }

    @Test (expected = EislTokenNotValidException.class)
    public void testResclientExceptionunauthorozedForcheckException() throws BadRequestException, DataNotFoundException, EislTokenNotValidException {
        HttpClientErrorException ex = new HttpClientErrorException(HttpStatus.UNAUTHORIZED);
        eislUtil.checkException(ex);
    }
}
