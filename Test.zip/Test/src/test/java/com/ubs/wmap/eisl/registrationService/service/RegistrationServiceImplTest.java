
package com.ubs.wmap.eisl.registrationService.service;

import com.ubs.wmap.eisl.housekeeping.component.TokenServiceImpl;
import com.ubs.wmap.eisl.registrationService.exception.*;
//import com.ubs.wmap.eisl.registrationService.model.EventSO;
import com.ubs.wmap.eisl.registrationService.model.PayloadSO;
import com.ubs.wmap.eisl.registrationService.model.RegistrationSO;
import com.ubs.wmap.eisl.registrationService.model.ResponseSO;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class RegistrationServiceImplTest {

    @Autowired
    RegistrationServiceImpl registrationService;

    @Autowired
    TokenServiceImpl tokenService;

    @MockBean
    RegistrationServiceDataRest registrationServiceDataRest;

    @Test
    public void getRegistrationTest() throws DataNotFoundException, EislTokenNotValidException, RegistrationServiceException, BadRequestException {
     String eislToken = tokenService.createEILSToken("testUser","testService","testRole");
     RegistrationSO registration = new RegistrationSO();
     registration.setUserName("testUsername");
     ResponseEntity <RegistrationSO> registryResponse = ResponseEntity.ok().body(registration);
        Map<String, Object> eventSO=new HashMap<>();
        eventSO.put("events","{\"eventId\":3002,\"serviceId\":\"eisl-account-create\",\"serviceUrl\":\"http://a302-1138-2384.ash.pwj.com:8090/api/eisl/mule/v1/dataingestion\",\"eventTopic\":\"eisl-account-create\",\"createdBy\":\"user\",\"createdDate\":\"2019-05-28T16:25:07.834+0000\"}");
        ResponseEntity<String> eventsResponse = new ResponseEntity<String>(String.valueOf(eventSO),HttpStatus.OK);
     Map<String, Object> responseMap = new HashMap<>();
     responseMap.put("registration", registration);
     responseMap.put("events", eventsResponse);
     responseMap.put("data", "");
     responseMap.put("exception", "");
     Mockito.when(registrationServiceDataRest.getRegistryResponse(ArgumentMatchers.anyString(),ArgumentMatchers.anyString(),ArgumentMatchers.anyString())).thenReturn(registryResponse);
     Mockito.when(registrationServiceDataRest.getEventsResponseforGet(ArgumentMatchers.anyString(),ArgumentMatchers.anyString(),ArgumentMatchers.anyString())).thenReturn(String.valueOf(eventsResponse));
     Mockito.when(registrationServiceDataRest.getDataResponse(ArgumentMatchers.anyString(),ArgumentMatchers.anyString(),ArgumentMatchers.anyString())).thenReturn("");
     Mockito.when(registrationServiceDataRest.getExceptionsResponse(ArgumentMatchers.anyString(),ArgumentMatchers.anyString(),ArgumentMatchers.anyString())).thenReturn("");
     Mockito.when(registrationServiceDataRest.buildResponseMap(ArgumentMatchers.any(),ArgumentMatchers.any(),ArgumentMatchers.any(),ArgumentMatchers.any())).thenReturn(responseMap);
     ResponseSO result = registrationService.getRegistration(eislToken,"testRole","testServiceId");
     Assert.assertEquals("Registration Data Present",true,result.getResponse().get("events").toString().contains("eisl-account-create"));

    }

    @Test (expected= DataNotFoundException.class)
    public void getRegistrationExceptionTest() throws DataNotFoundException, EislTokenNotValidException, RegistrationServiceException, BadRequestException {
        String eislToken = tokenService.createEILSToken("testUser","testService","testRole");
        RegistrationSO registration = RegistrationSO.builder().build();
        registration.setUserName("testUsername");
        ResponseEntity <RegistrationSO> registryResponse = new ResponseEntity<RegistrationSO>(registration, HttpStatus.NOT_FOUND);
        Map<String, Object> eventSO=new HashMap<>();
        eventSO.put("events","{\"eventId\":3002,\"serviceId\":\"eisl-account-create\",\"serviceUrl\":\"http://a302-1138-2384.ash.pwj.com:8090/api/eisl/mule/v1/dataingestion\",\"eventTopic\":\"eisl-account-create\",\"createdBy\":\"user\",\"createdDate\":\"2019-05-28T16:25:07.834+0000\"}");
        ResponseEntity<String> eventsResponse = new ResponseEntity<String>(String.valueOf(eventSO),HttpStatus.OK);
        Map<String, Object> responseMap = new HashMap<>();
        responseMap.put("registration", registration);
        responseMap.put("events", eventsResponse);
        responseMap.put("data", "");
        responseMap.put("exception", "");
        Mockito.when(registrationServiceDataRest.getRegistryResponse(ArgumentMatchers.anyString(),ArgumentMatchers.anyString(),ArgumentMatchers.anyString())).thenReturn(registryResponse);
        Mockito.when(registrationServiceDataRest.getEventsResponseforGet(ArgumentMatchers.anyString(),ArgumentMatchers.anyString(),ArgumentMatchers.anyString())).thenReturn(String.valueOf(eventsResponse));
        Mockito.when(registrationServiceDataRest.getDataResponse(ArgumentMatchers.anyString(),ArgumentMatchers.anyString(),ArgumentMatchers.anyString())).thenReturn("");
        Mockito.when(registrationServiceDataRest.getExceptionsResponse(ArgumentMatchers.anyString(),ArgumentMatchers.anyString(),ArgumentMatchers.anyString())).thenReturn("");
        Mockito.when(registrationServiceDataRest.buildResponseMap(ArgumentMatchers.any(),ArgumentMatchers.any(),ArgumentMatchers.any(),ArgumentMatchers.any())).thenReturn(responseMap);
        registrationService.getRegistration(eislToken,"testRole","testServiceId");

    }

    @Test
    public void testpostRegistration() throws DataNotFoundException, EislTokenNotValidException, RegistrationServiceException, BadRequestException, DataException {
        String eislToken = tokenService.createEILSToken("testUser","testService","testRole");
        RegistrationSO registration = RegistrationSO.builder().build();
        registration.setUserName("testUsername");
        ResponseEntity <RegistrationSO> registryResponse = ResponseEntity.ok().body(registration);
        Map<String, Object> eventSO=new HashMap<>();
        eventSO.put("events","{\"eventId\":3002,\"serviceId\":\"eisl-account-create\",\"serviceUrl\":\"http://a302-1138-2384.ash.pwj.com:8090/api/eisl/mule/v1/dataingestion\",\"eventTopic\":\"eisl-account-create\",\"createdBy\":\"user\",\"createdDate\":\"2019-05-28T16:25:07.834+0000\"}");
        ResponseEntity<String> eventsResponse = new ResponseEntity<String>(String.valueOf(eventSO),HttpStatus.OK);
        Map<String, Object> responseMap = new HashMap<>();
        responseMap.put("registration", registration);
        responseMap.put("events", eventsResponse);
        responseMap.put("data", "");
        responseMap.put("exception", "");
        PayloadSO payloadSO = new PayloadSO();
        payloadSO.setRole("testRole");
        Mockito.when(registrationServiceDataRest.getRegistryResponseforPost(ArgumentMatchers.anyString(),ArgumentMatchers.anyString(),ArgumentMatchers.anyString())).thenReturn(registryResponse);
        Mockito.when(registrationServiceDataRest.checkEventsData(ArgumentMatchers.anyString(),ArgumentMatchers.anyString(),ArgumentMatchers.anyString())).thenReturn(eventsResponse);
        Mockito.when(registrationServiceDataRest.buildRegistration(ArgumentMatchers.any(PayloadSO.class),ArgumentMatchers.anyString())).thenReturn(registration);
        Mockito.when(registrationServiceDataRest.postRegistryResponse(ArgumentMatchers.anyString(),ArgumentMatchers.any(),ArgumentMatchers.anyString())).thenReturn(registration);
        Assert.assertEquals("Registration Data found","testUsername",registrationService.postRegistration(eislToken,payloadSO,"testServiceId").getUserName());
    }

    @Test
    public void testpostRegistrationwithoutRegistrationData() throws DataNotFoundException, EislTokenNotValidException, RegistrationServiceException, BadRequestException, DataException {
        String eislToken = tokenService.createEILSToken("testUser","testService","testRole");
        RegistrationSO registration = RegistrationSO.builder().build();
        registration.setUserName("testUsername");
        ResponseEntity <RegistrationSO> registryResponse = new ResponseEntity<RegistrationSO>(registration, HttpStatus.NOT_FOUND);
        Map<String, Object> eventSO=new HashMap<>();
        eventSO.put("events","{\"eventId\":3002,\"serviceId\":\"eisl-account-create\",\"serviceUrl\":\"http://a302-1138-2384.ash.pwj.com:8090/api/eisl/mule/v1/dataingestion\",\"eventTopic\":\"eisl-account-create\",\"createdBy\":\"user\",\"createdDate\":\"2019-05-28T16:25:07.834+0000\"}");
        ResponseEntity<String> eventsResponse = new ResponseEntity<String>(String.valueOf(eventSO),HttpStatus.OK);
        Map<String, Object> responseMap = new HashMap<>();
        responseMap.put("registration", registration);
        responseMap.put("events", eventsResponse);
        responseMap.put("data", "");
        responseMap.put("exception", "");
        PayloadSO payloadSO = new PayloadSO();
        payloadSO.setRole("testRole");
        Mockito.when(registrationServiceDataRest.getRegistryResponseforPost(ArgumentMatchers.anyString(),ArgumentMatchers.anyString(),ArgumentMatchers.anyString())).thenReturn(registryResponse);
        Mockito.when(registrationServiceDataRest.checkEventsData(ArgumentMatchers.anyString(),ArgumentMatchers.anyString(),ArgumentMatchers.anyString())).thenReturn(eventsResponse);
        Mockito.when(registrationServiceDataRest.buildRegistration(ArgumentMatchers.any(PayloadSO.class),ArgumentMatchers.anyString())).thenReturn(registration);
        Mockito.when(registrationServiceDataRest.postRegistryResponse(ArgumentMatchers.anyString(),ArgumentMatchers.any(),ArgumentMatchers.anyString())).thenReturn(registration);
        Assert.assertEquals("Registration Data found","testUsername",registrationService.postRegistration(eislToken,payloadSO,"testServiceId").getUserName());
    }

    @Test (expected= RegistrationServiceException.class)
    public void testpostRegistrationcheckException() throws DataNotFoundException, EislTokenNotValidException, RegistrationServiceException, BadRequestException, DataException {
        String eislToken = tokenService.createEILSToken("testUser","testService","testRole");
        RegistrationSO registration = RegistrationSO.builder().build();
        registration.setUserName("testUsername");
        ResponseEntity <RegistrationSO> registryResponse = new ResponseEntity<RegistrationSO>(registration, HttpStatus.NOT_FOUND);
        Map<String, Object> eventSO=new HashMap<>();
        eventSO.put("events","{\"eventId\":3002,\"serviceId\":\"eisl-account-create\",\"serviceUrl\":\"http://a302-1138-2384.ash.pwj.com:8090/api/eisl/mule/v1/dataingestion\",\"eventTopic\":\"eisl-account-create\",\"createdBy\":\"user\",\"createdDate\":\"2019-05-28T16:25:07.834+0000\"}");
        ResponseEntity<String> eventsResponse = new ResponseEntity<String>(String.valueOf(eventSO),HttpStatus.OK);
        Map<String, Object> responseMap = new HashMap<>();
        responseMap.put("registration", registration);
        responseMap.put("events", eventsResponse);
        responseMap.put("data", "");
        responseMap.put("exception", "");
        PayloadSO payloadSO = new PayloadSO();
        payloadSO.setRole("testRole");
        Mockito.when(registrationServiceDataRest.checkEventsData(ArgumentMatchers.anyString(),ArgumentMatchers.anyString(),ArgumentMatchers.anyString())).thenThrow(RegistrationServiceException.class);
        Mockito.when(registrationServiceDataRest.buildRegistration(ArgumentMatchers.any(PayloadSO.class),ArgumentMatchers.anyString())).thenReturn(registration);
        Mockito.when(registrationServiceDataRest.postRegistryResponse(ArgumentMatchers.anyString(),ArgumentMatchers.any(),ArgumentMatchers.anyString())).thenReturn(registration);
        registrationService.postRegistration(eislToken,payloadSO,"testServiceId");
    }

    @Test
    public void testputRegistration() throws DataNotFoundException, EislTokenNotValidException, RegistrationServiceException, BadRequestException, DataException {
        String eislToken = tokenService.createEILSToken("testUser","testService","testRole");
        RegistrationSO registration = RegistrationSO.builder().build();
        registration.setUserName("testUsername");
        ResponseEntity <RegistrationSO> registryResponse = ResponseEntity.ok().body(registration);
        Map<String, Object> eventSO=new HashMap<>();
        eventSO.put("events","{\"eventId\":3002,\"serviceId\":\"eisl-account-create\",\"serviceUrl\":\"http://a302-1138-2384.ash.pwj.com:8090/api/eisl/mule/v1/dataingestion\",\"eventTopic\":\"eisl-account-create\",\"createdBy\":\"user\",\"createdDate\":\"2019-05-28T16:25:07.834+0000\"}");
        ResponseEntity<String> eventsResponse = new ResponseEntity<String>(String.valueOf(eventSO),HttpStatus.OK);
        Map<String, Object> responseMap = new HashMap<>();
        responseMap.put("registration", registration);
        responseMap.put("events", eventsResponse);
        responseMap.put("data", "");
        responseMap.put("exception", "");
        PayloadSO payloadSO = new PayloadSO();
        payloadSO.setRole("testRole");
        Mockito.when(registrationServiceDataRest.getRegistryResponseforPost(ArgumentMatchers.anyString(),ArgumentMatchers.anyString(),ArgumentMatchers.anyString())).thenReturn(registryResponse);
        Mockito.when(registrationServiceDataRest.checkEventsData(ArgumentMatchers.anyString(),ArgumentMatchers.anyString(),ArgumentMatchers.anyString())).thenReturn(eventsResponse);
        Mockito.when(registrationServiceDataRest.buildRegistration(ArgumentMatchers.any(PayloadSO.class),ArgumentMatchers.anyString())).thenReturn(registration);
        Mockito.when(registrationServiceDataRest.putRegistryResponse(ArgumentMatchers.anyString(),ArgumentMatchers.any(),ArgumentMatchers.anyString())).thenReturn(registration);
        Assert.assertEquals("Registration Data found","testUsername",registrationService.putRegistration(eislToken,payloadSO,"testServiceId").getUserName());
    }

    @Test (expected=DataNotFoundException.class)
    public void testputRegistrationWithoutRegistryData() throws DataNotFoundException, EislTokenNotValidException, RegistrationServiceException, BadRequestException, DataException {
        String eislToken = tokenService.createEILSToken("testUser","testService","testRole");
        RegistrationSO registration = RegistrationSO.builder().build();
        registration.setUserName("testUsername");
        ResponseEntity <RegistrationSO> registryResponse = new ResponseEntity<RegistrationSO>(registration, HttpStatus.NOT_FOUND);
        Map<String, Object> eventSO=new HashMap<>();
        eventSO.put("events","{\"eventId\":3002,\"serviceId\":\"eisl-account-create\",\"serviceUrl\":\"http://a302-1138-2384.ash.pwj.com:8090/api/eisl/mule/v1/dataingestion\",\"eventTopic\":\"eisl-account-create\",\"createdBy\":\"user\",\"createdDate\":\"2019-05-28T16:25:07.834+0000\"}");
        ResponseEntity<String> eventsResponse = new ResponseEntity<String>(String.valueOf(eventSO),HttpStatus.OK);
        Map<String, Object> responseMap = new HashMap<>();
        responseMap.put("registration", registration);
        responseMap.put("events", eventsResponse);
        responseMap.put("data", "");
        responseMap.put("exception", "");
        PayloadSO payloadSO = new PayloadSO();
        payloadSO.setRole("testRole");
        Mockito.when(registrationServiceDataRest.getRegistryResponseforPost(ArgumentMatchers.anyString(),ArgumentMatchers.anyString(),ArgumentMatchers.anyString())).thenReturn(registryResponse);
        Mockito.when(registrationServiceDataRest.checkEventsData(ArgumentMatchers.anyString(),ArgumentMatchers.anyString(),ArgumentMatchers.anyString())).thenReturn(eventsResponse);
        Mockito.when(registrationServiceDataRest.buildRegistration(ArgumentMatchers.any(PayloadSO.class),ArgumentMatchers.anyString())).thenReturn(registration);
        Mockito.when(registrationServiceDataRest.putRegistryResponse(ArgumentMatchers.anyString(),ArgumentMatchers.any(),ArgumentMatchers.anyString())).thenReturn(registration);
       registrationService.putRegistration(eislToken,payloadSO,"testServiceId");
    }

    @Test (expected=RegistrationServiceException.class)
    public void testputRegistrationForBadRequestException() throws DataNotFoundException, EislTokenNotValidException, RegistrationServiceException, BadRequestException, DataException {
        String eislToken = tokenService.createEILSToken("testUser","testService","testRole");
        RegistrationSO registration = RegistrationSO.builder().build();
        registration.setUserName("testUsername");
        ResponseEntity <RegistrationSO> registryResponse = new ResponseEntity<RegistrationSO>(registration, HttpStatus.NOT_FOUND);
        Map<String, Object> eventSO=new HashMap<>();
        eventSO.put("events","{\"eventId\":3002,\"serviceId\":\"eisl-account-create\",\"serviceUrl\":\"http://a302-1138-2384.ash.pwj.com:8090/api/eisl/mule/v1/dataingestion\",\"eventTopic\":\"eisl-account-create\",\"createdBy\":\"user\",\"createdDate\":\"2019-05-28T16:25:07.834+0000\"}");
        ResponseEntity<String> eventsResponse = new ResponseEntity<String>(String.valueOf(eventSO),HttpStatus.OK);
        Map<String, Object> responseMap = new HashMap<>();
        responseMap.put("registration", registration);
        responseMap.put("events", "");
        responseMap.put("data", "");
        responseMap.put("exception", "");
        PayloadSO payloadSO = new PayloadSO();
        payloadSO.setRole("testRole");
        Mockito.when(registrationServiceDataRest.getRegistryResponseforPost(ArgumentMatchers.anyString(),ArgumentMatchers.anyString(),ArgumentMatchers.anyString())).thenThrow(RegistrationServiceException.class);
        Mockito.when(registrationServiceDataRest.checkEventsData(ArgumentMatchers.anyString(),ArgumentMatchers.anyString(),ArgumentMatchers.anyString())).thenReturn(eventsResponse);
        Mockito.when(registrationServiceDataRest.buildRegistration(ArgumentMatchers.any(PayloadSO.class),ArgumentMatchers.anyString())).thenReturn(registration);
        Mockito.when(registrationServiceDataRest.putRegistryResponse(ArgumentMatchers.anyString(),ArgumentMatchers.any(),ArgumentMatchers.anyString())).thenReturn(registration);
        registrationService.putRegistration(eislToken,payloadSO,"testServiceId");
    }

    @Test
    public void testdeleteRegistration() throws DataNotFoundException, EislTokenNotValidException, RegistrationServiceException, BadRequestException, DataException {
        final String url = "http://localhost:5050/eisl/Test";
        String eislToken = tokenService.createEILSToken("testUser","testService","testRole");
        RegistrationSO registration = RegistrationSO.builder().build();
        registration.setUserName("testUsername");
        registration.setRegistrationId(1L);
        ResponseEntity <RegistrationSO> registryResponse = new ResponseEntity<RegistrationSO>(registration, HttpStatus.OK);
        Map<String, Object> responseMap = new HashMap<>();
        responseMap.put("registration", registration);
        responseMap.put("events", "");
        responseMap.put("data", "");
        responseMap.put("exception", "");
        PayloadSO payloadSO = new PayloadSO();
        payloadSO.setRole("testRole");
        Mockito.when(registrationServiceDataRest.getRegistryResponseforPost(ArgumentMatchers.anyString(),ArgumentMatchers.anyString(),ArgumentMatchers.anyString())).thenReturn(registryResponse);
        Mockito.when(registrationServiceDataRest.putRegistryResponse(ArgumentMatchers.anyString(),ArgumentMatchers.any(),ArgumentMatchers.anyString())).thenReturn(registration);
        Mockito.when(registrationServiceDataRest.getDeleteResponseForRegistryAccessService(ArgumentMatchers.anyString(),ArgumentMatchers.anyString(),ArgumentMatchers.anyString())).thenReturn(HttpStatus.NOT_FOUND.toString());
        assertEquals("Data Not Found","404 NOT_FOUND",registrationService.deleteRegistration(url,eislToken,"testRole"));
    }

    @Test
    public void testdeleteRegistrationwithRegistrationdata() throws DataNotFoundException, EislTokenNotValidException, RegistrationServiceException, BadRequestException, DataException {
        final String url = "http://localhost:5050/eisl/Test";
        String eislToken = tokenService.createEILSToken("testUser","testService","testRole");
        RegistrationSO registration = RegistrationSO.builder().build();
        registration.setUserName("testUsername");
        registration.setRegistrationId(1L);
        ResponseEntity <RegistrationSO> registryResponse = new ResponseEntity<RegistrationSO>(registration, HttpStatus.OK);
        Map<String, Object> responseMap = new HashMap<>();
        responseMap.put("registration", registration);
        responseMap.put("events", "");
        responseMap.put("data", "");
        responseMap.put("exception", "");
        PayloadSO payloadSO = new PayloadSO();
        payloadSO.setRole("testRole");
        Mockito.when(registrationServiceDataRest.getRegistryResponse(ArgumentMatchers.anyString(),ArgumentMatchers.anyString(),ArgumentMatchers.anyString())).thenReturn(registryResponse);
        Mockito.when(registrationServiceDataRest.putRegistryResponse(ArgumentMatchers.anyString(),ArgumentMatchers.any(),ArgumentMatchers.anyString())).thenReturn(registration);
        Mockito.when(registrationServiceDataRest.getDeleteResponseForRegistryAccessService(ArgumentMatchers.anyString(),ArgumentMatchers.anyString(),ArgumentMatchers.anyString())).thenReturn(HttpStatus.OK.toString());
        assertEquals("Data Not Found","200 OK",registrationService.deleteRegistration(url,eislToken,"testRole"));
    }

    @Test (expected=DataNotFoundException.class)
    public void testdeleteRegistrationwhenRegistrationdataNotPresent() throws DataNotFoundException, EislTokenNotValidException, RegistrationServiceException, BadRequestException, DataException {
        final String url = "http://localhost:5050/eisl/Test";
        String eislToken = tokenService.createEILSToken("testUser","testService","testRole");
        RegistrationSO registration = RegistrationSO.builder().build();
        registration.setUserName("testUsername");
        registration.setRegistrationId(1L);
        ResponseEntity <RegistrationSO> registryResponse = new ResponseEntity<RegistrationSO>(registration, HttpStatus.NOT_FOUND);
        Map<String, Object> responseMap = new HashMap<>();
        responseMap.put("registration", registration);
        responseMap.put("events", "");
        responseMap.put("data", "");
        responseMap.put("exception", "");
        PayloadSO payloadSO = new PayloadSO();
        payloadSO.setRole("testRole");
        Mockito.when(registrationServiceDataRest.getRegistryResponse(ArgumentMatchers.anyString(),ArgumentMatchers.anyString(),ArgumentMatchers.anyString())).thenReturn(registryResponse);
        Mockito.when(registrationServiceDataRest.putRegistryResponse(ArgumentMatchers.anyString(),ArgumentMatchers.any(),ArgumentMatchers.anyString())).thenReturn(registration);
        Mockito.when(registrationServiceDataRest.getDeleteResponseForRegistryAccessService(ArgumentMatchers.anyString(),ArgumentMatchers.anyString(),ArgumentMatchers.anyString())).thenReturn(HttpStatus.OK.toString());
        registrationService.deleteRegistration(url,eislToken,"testRole");
    }
}

