package com.ubs.wmap.eisl.registrationService.service;

import com.ubs.wmap.eisl.registrationService.exception.*;
import com.ubs.wmap.eisl.registrationService.model.PayloadSO;
import com.ubs.wmap.eisl.registrationService.model.RegistrationSO;
import com.ubs.wmap.eisl.registrationService.model.ResponseSO;
import org.springframework.http.HttpStatus;

import javax.validation.constraints.NotBlank;


public interface RegistrationService {


    ResponseSO getRegistration(@NotBlank String eislToken, String role,String serviceId) throws DataException, DataNotFoundException, EislTokenNotValidException, RegistrationServiceException, BadRequestException;


    RegistrationSO putRegistration(@NotBlank String eislToken, PayloadSO payload,String serviceId) throws DataException, DataNotFoundException, EislTokenNotValidException, RegistrationServiceException, BadRequestException;

    RegistrationSO postRegistration(@NotBlank String eislToken, PayloadSO payload,String serviceId) throws DataException, DataNotFoundException, EislTokenNotValidException, RegistrationServiceException, BadRequestException;

    String deleteRegistration(String baseUrl, String eislToken, String role) throws DataNotFoundException, BadRequestException, EislTokenNotValidException, RegistrationServiceException;
}
