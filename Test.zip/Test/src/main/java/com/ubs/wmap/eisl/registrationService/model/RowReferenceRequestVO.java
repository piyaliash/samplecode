package com.ubs.wmap.eisl.registrationService.model;

import lombok.Data;

import java.io.Serializable;

@Data
public class RowReferenceRequestVO implements Serializable {

    private static final long serialVersionUID = 388516328059686097L;


    private String name;
    private String range;
}
