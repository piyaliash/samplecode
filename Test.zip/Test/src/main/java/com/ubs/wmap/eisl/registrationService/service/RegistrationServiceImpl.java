package com.ubs.wmap.eisl.registrationService.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ubs.wmap.eisl.registrationService.exception.*;
import com.ubs.wmap.eisl.registrationService.model.PayloadSO;
import com.ubs.wmap.eisl.registrationService.model.RegistrationSO;
import com.ubs.wmap.eisl.registrationService.model.ResponseSO;
import com.ubs.wmap.eisl.registrationService.util.MessageSourceUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@Service
@Slf4j
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class RegistrationServiceImpl implements RegistrationService {


    private final RegistrationServiceDataRest registrationServiceDataRest;

    private final MessageSourceUtil messages;

    @Value("${registration.service.registryAccessEndpoint}")
    private String registryAccessEndpoint;

    @Value("${registration.service.dataAccessEndpoint}")
    private String dataAccessEndpoint;

    @Value("${registration.service.eventAccessEndpoint}")
    private String eventAccessEndpoint;

    @Value("${registration.service.exceptionAccessEndpoint}")
    private String exceptionAccessEndpoint;

    @Value("${app.custom.registration_Id}")
    private String registrationId;


    @Override
    public ResponseSO getRegistration(String eislToken, String role, String serviceId)
            throws RegistrationServiceException, EislTokenNotValidException, DataNotFoundException, BadRequestException {

        log.debug("Entering getRegistration method :: ");
        ObjectMapper mapper = new ObjectMapper();
        ResponseSO responseDTO = new ResponseSO();
        ResponseEntity<RegistrationSO> getResponse;
        String registryResponse = "";
        getResponse = registrationServiceDataRest.getRegistryResponse(registryAccessEndpoint, eislToken, role);
        if (getResponse.getStatusCode() != HttpStatus.OK) {
            log.error("Registration Data not found");
            throw new DataNotFoundException(messages.getMessage("app.message.REGISTRY_INFO_NOT_FOUND_MESSAGE"));
        }

        try {
            registryResponse = mapper.writeValueAsString(getResponse.getBody());
        } catch (JsonProcessingException e) {
            log.error("error during mapping registry {}:", e);
        }
        Map<String, Object> registration = new HashMap<String, Object>();
        Map<String, Object> events = new HashMap<String, Object>();
        Map<String, Object> data = new HashMap<String, Object>();
        Map<String, Object> exception = new HashMap<String, Object>();


        String eventsResponse =
                registrationServiceDataRest.getEventsResponseforGet(eventAccessEndpoint, eislToken,serviceId);
        try {
            registration = mapper.readValue(registryResponse, new TypeReference<Map<String, Object>>() {
            });
            String dataResponse = registrationServiceDataRest.getDataResponse(dataAccessEndpoint, eislToken, serviceId);
            String exceptionResponse = registrationServiceDataRest.getExceptionsResponse(exceptionAccessEndpoint, eislToken, serviceId);
            events = mapper.readValue(eventsResponse, new TypeReference<Map<String, Object>>() { });
            data = mapper.readValue(dataResponse, new TypeReference<Map<String, Object>>() { });
            exception = mapper.readValue(exceptionResponse, new TypeReference<Map<String, Object>>() {
            });


        } catch (IOException e) {
            log.error("Data not found. {}", e);
        }
        responseDTO.setResponse(registrationServiceDataRest.buildResponseMap(registration, events, data, exception));

        return responseDTO;
    }

    @Override

    public RegistrationSO postRegistration(String eislToken, PayloadSO payload, String serviceId) throws DataException, DataNotFoundException, EislTokenNotValidException, RegistrationServiceException {

        log.debug("Entering postRegistration method :: ");
        try {
            ResponseEntity<RegistrationSO> getResponse
                    = registrationServiceDataRest.getRegistryResponseforPost(registryAccessEndpoint, eislToken, payload.getRole());

            if (getResponse != null && getResponse.getStatusCode() == HttpStatus.OK) {
                log.info("Existing registry found");
                return getResponse.getBody();
            }

            try {
                registrationServiceDataRest.checkEventsData(eislToken, eventAccessEndpoint, serviceId);
            }catch(DataNotFoundException ex){
                throw new DataNotFoundException(messages.getMessage("app.message.EVENT_DATA_NOT_FOUND_MESSAGE"));
            }
            registrationServiceDataRest.checkForDataAndException(serviceId, eislToken,dataAccessEndpoint,exceptionAccessEndpoint);

            RegistrationSO builtRegistry = registrationServiceDataRest.buildRegistration(payload, eislToken);
            return registrationServiceDataRest.postRegistryResponse(registryAccessEndpoint, builtRegistry, eislToken);

        } catch (RegistrationServiceException | BadRequestException e) {
            log.error("Error occured while posting data to Registry access Service {}",e);
            throw new RegistrationServiceException(messages.getMessage("app.message.INTERNAL_SERVER_ERROR_MSG"));
        }
    }


    @Override
    public RegistrationSO putRegistration(String eislToken, PayloadSO payload,String serviceId)
            throws DataException, DataNotFoundException, EislTokenNotValidException, RegistrationServiceException {
        log.debug("Entering putRegistration method :: ");
        try {
            ResponseEntity<RegistrationSO> getResponse
                    = registrationServiceDataRest.getRegistryResponseforPost(registryAccessEndpoint, eislToken, payload.getRole());

            if (getResponse != null && getResponse.getStatusCode() == HttpStatus.OK) {
                log.info("Existing registry found");
                registrationServiceDataRest.checkEventsData(eislToken,eventAccessEndpoint,serviceId);
                registrationServiceDataRest.checkForDataAndException(serviceId, eislToken,dataAccessEndpoint,exceptionAccessEndpoint);
                RegistrationSO builtRegistry = registrationServiceDataRest.buildRegistration(payload, eislToken);
                return registrationServiceDataRest.putRegistryResponse(registryAccessEndpoint, builtRegistry, eislToken);

            }

            log.error("Registry Not Found While updating {}");
            throw new DataNotFoundException(messages.getMessage("app.message.REGISTRY_INFO_NOT_FOUND_MESSAGE"));


        } catch (RegistrationServiceException | BadRequestException e) {
            log.error("Error occured while updating data to Registry access Service {}",e);
            throw new RegistrationServiceException(messages.getMessage("app.message.INTERNAL_SERVER_ERROR_MSG"));
        }
    }

    @Override
    public String deleteRegistration(String baseUrl, String eislToken, String role) throws DataNotFoundException, BadRequestException, EislTokenNotValidException, RegistrationServiceException {
        log.debug("Entering getRegistration method :: ");
        ObjectMapper mapper = new ObjectMapper();
        String registryResponse = "";

        ResponseEntity<RegistrationSO> getResponse = registrationServiceDataRest.getRegistryResponse(registryAccessEndpoint, eislToken, role);
        if (getResponse!=null && getResponse.getStatusCode() != HttpStatus.OK) {
            log.error("Registration Data not found");
            throw new DataNotFoundException(messages.getMessage("app.message.REGISTRY_INFO_NOT_FOUND_MESSAGE"));
        }

        try {
            registryResponse = getResponse !=null?mapper.writeValueAsString(getResponse.getBody()):"";
        } catch (JsonProcessingException e) {
            log.error("error during mapping registry {}:", e);
        }

        Map<String, Object> registration = new HashMap<String, Object>();
        try {
            registration = mapper.readValue(registryResponse, new TypeReference<Map<String, Object>>() {
            });
        } catch (IOException e) {
            log.error("Data not found. {}", e);
        }
        String status= registrationServiceDataRest.getDeleteResponseForRegistryAccessService(baseUrl,eislToken,registration.isEmpty()?"":registration.get(registrationId).toString());
        return status;
    }

}
