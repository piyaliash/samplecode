package com.ubs.wmap.eisl.registrationService.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;


public class EislTokenNotValidException extends Exception {

    private static final long serialVersionUID = -3379429824404071177L;

    public EislTokenNotValidException(String message, Throwable cause) {
        super(message, cause);
    }

    public EislTokenNotValidException(String message) {
        super(message);
    }

    public EislTokenNotValidException(Throwable cause) {
        super(cause);
    }


}
