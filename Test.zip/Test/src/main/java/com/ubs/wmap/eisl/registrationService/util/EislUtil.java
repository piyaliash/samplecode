package com.ubs.wmap.eisl.registrationService.util;

import com.ubs.wmap.eisl.housekeeping.TokenService;
import com.ubs.wmap.eisl.housekeeping.component.exceptions.TokenExpireException;
import com.ubs.wmap.eisl.housekeeping.component.exceptions.TokenUnwrapException;
import com.ubs.wmap.eisl.registrationService.exception.BadRequestException;
import com.ubs.wmap.eisl.registrationService.exception.DataNotFoundException;
import com.ubs.wmap.eisl.registrationService.exception.EislTokenNotValidException;
import com.ubs.wmap.eisl.registrationService.exception.RegistrationServiceException;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;

import java.util.Map;


@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@Component
@Slf4j
public class EislUtil {

    @Value("${app.custom.token_attribute_name}")
    private String eislObjectKey;

    private final MessageSourceUtil messages;

    private final TokenService tokenService;

    public String trimAuthorizationSchema(String authorizationHeader) {
        return authorizationHeader.replaceAll("^Bearer ", "");
    }

    public Map<String, Object> getEislClaims(String eisToken)
            throws EislTokenNotValidException, RegistrationServiceException {
        Map<String, Object> eislClaims = null;
        try {
            eislClaims = tokenService.init(eisToken);
        } catch (TokenExpireException ex) {
            log.error("Token Expired {} ", ex);
            throw new EislTokenNotValidException(messages.getMessage("app.message.EISL_EXPIRE_TOKEN_MSG"));
        }catch(TokenUnwrapException ex){
            log.error("Invalid Token {} ", ex);
            throw new EislTokenNotValidException(messages.getMessage("app.message.EISL_INVALID_TOKEN_MSG"));
        }
        catch (RuntimeException rx) {
            log.error("{}", rx);
            throw new RegistrationServiceException(messages.getMessage("app.message.INTERNAL_SERVER_ERROR_MSG"));
        }

        return eislClaims.containsKey(eislObjectKey)? (Map<String, Object>) eislClaims.get(eislObjectKey): eislClaims;

    }

    public void checkException(RestClientException e) throws DataNotFoundException, BadRequestException, EislTokenNotValidException {
        if (e instanceof HttpStatusCodeException) {
            HttpStatusCodeException ex = (HttpStatusCodeException) e;
            if (HttpStatus.NOT_FOUND == ex.getStatusCode()) {
                log.error("No Data Found from Registry Access Service: {} ", e);
                throw new DataNotFoundException(messages.getMessage("app.message.REGISTRY_INFO_NOT_FOUND_MESSAGE"));
            } else if (HttpStatus.BAD_REQUEST == ex.getStatusCode()) {
                log.error("Registry Access Service Url is not Correct : {} ", e);
                throw new BadRequestException("Malformed URL for registration service");
            } else if (HttpStatus.UNAUTHORIZED == ex.getStatusCode()) {
                log.error("EISL Token Exception during Registry access service: {} ", ex);
                throw new EislTokenNotValidException(messages.getMessage("app.message.EISL_INVALID_REGISTRY_ACCESS"));
            }
        }
    }


    public void validateRestClientExceptionForEvents(RestClientException e) throws DataNotFoundException, BadRequestException, EislTokenNotValidException {
        if (e instanceof HttpStatusCodeException) {
            HttpStatusCodeException ex = (HttpStatusCodeException) e;
            if (HttpStatus.NOT_FOUND == ex.getStatusCode()) {
                log.error("No Data Found from Events Service: {} ", e);
                throw new DataNotFoundException(messages.getMessage("app.message.EVENT_DATA_NOT_FOUND_MESSAGE"));
            } else if (HttpStatus.BAD_REQUEST == ex.getStatusCode()) {
                log.error("Events Service Url is not Correct : {} ", e);
                throw new BadRequestException("Malformed URL for registration service");
            } else if (HttpStatus.UNAUTHORIZED == ex.getStatusCode()) {
                log.error("EISL Token Exception during Events service: {} ", ex);
                throw new EislTokenNotValidException(messages.getMessage("app.message.EISL_INVALID_EVENT_SERVICE"));
            }
        }
    }
}
