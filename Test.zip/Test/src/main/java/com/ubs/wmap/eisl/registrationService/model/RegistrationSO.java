package com.ubs.wmap.eisl.registrationService.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Set;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RegistrationSO implements Serializable {

    private static final long serialVersionUID = 6349874774163306834L;
    private Long registrationId;
    private String userName;
    private String userId;
    private String company;
    private String eislToken;
    private String serviceId;
    private String dataEntitlement;
    private String role;
    private Set<ColumnReferenceRequestVO> columnReferences;
    private Set<RowReferenceRequestVO> rowReferences;
}
