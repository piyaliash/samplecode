package com.ubs.wmap.eisl.registrationService.controller;

import com.ubs.wmap.eisl.housekeeping.TokenService;
import com.ubs.wmap.eisl.housekeeping.component.exceptions.TokenExpireException;
import com.ubs.wmap.eisl.housekeeping.component.exceptions.TokenUnwrapException;
import com.ubs.wmap.eisl.registrationService.exception.*;
import com.ubs.wmap.eisl.registrationService.model.PayloadSO;
import com.ubs.wmap.eisl.registrationService.model.RegistrationSO;
import com.ubs.wmap.eisl.registrationService.model.ResponseSO;
import com.ubs.wmap.eisl.registrationService.service.RegistrationServiceImpl;
import com.ubs.wmap.eisl.registrationService.util.EislUtil;
import com.ubs.wmap.eisl.registrationService.util.MessageSourceUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.NotBlank;
import java.util.Map;

@RestController
@Slf4j
@RequestMapping(value = "/registrations", produces = "application/json")
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class RegistrationServiceController {


    @Value("${registration.service.registryAccessEndpoint}")
    private String registryAccessEndpoint;
    @Value("${app.custom.eisl_eislObject_serviceId}")
    private String serviceId;
    @Value("${app.custom.eisl_eislObject_role}")
    private String role;



    private final RegistrationServiceImpl registrationService;

    private final MessageSourceUtil messages;

    private final EislUtil eislUtil;



    @GetMapping
    public ResponseEntity<ResponseSO> getRegistry(@NotBlank @RequestHeader(name = "Authorization") String authHeader,
                                                  @NotBlank @RequestParam("token") String eislToken,
                                                  @NotBlank @RequestParam("role") String role)
            throws EislTokenNotValidException, DataException, DataNotFoundException, BadRequestException, RegistrationServiceException {
        log.debug("Registration service initiated to get Registry Details:");

        String basicToken = eislUtil.trimAuthorizationSchema(authHeader);

        if (!eislUtil.getEislClaims(eislToken).containsKey(serviceId)) {
            log.error("Service ID Missing from EISL Token");
            throw new BadRequestException(messages.getMessage("app.message.SERVICE_ID_EMPTY_MESSAGE"));
        }

        try {

            ResponseSO dto = registrationService.getRegistration(eislToken, role,eislUtil.getEislClaims(eislToken).get(serviceId).toString());

            return ResponseEntity.ok()
                    .body(dto);
        } catch (DataNotFoundException ex) {
            log.error("Registry information not found {} ", ex);
            throw new DataNotFoundException(ex.getMessage());
        } catch (RegistrationServiceException ex) {
            log.error("Internal Server Error while accessing registration service {}", ex);
            throw new RegistrationServiceException(messages.getMessage("app.message.INTERNAL_SERVER_ERROR_MSG"));
        } catch (Exception ex) {
            log.error("Exception occurred during configuration calls {} ", ex);
            throw new DataException(messages.getMessage("app.message.DATA_EXCEPTION_MSG"));
        }
    }

    @PostMapping
    public ResponseEntity<RegistrationSO> addRegistry(@NotBlank @RequestHeader(name = "Authorization") final String authHeader,
                                                      @NotBlank @RequestParam("token") final String eislToken, @RequestBody PayloadSO payload) throws EislTokenNotValidException, DataException, RegistrationServiceException {
        log.debug("Registration service initiated to get create Registry : {}", payload);

        String basicToken = eislUtil.trimAuthorizationSchema(authHeader);
        if (!eislUtil.getEislClaims(eislToken).containsKey(serviceId)) {
            log.error("Eisl Token not valid");
            throw new EislTokenNotValidException(messages.getMessage("app.message.SERVICE_ID_EMPTY_MESSAGE"));
        }

        try {
            RegistrationSO dto;

            dto = registrationService.postRegistration(eislToken, payload,eislUtil.getEislClaims(eislToken).get(serviceId).toString());

            return ResponseEntity.ok()
                    .body(dto);
        } catch (DataNotFoundException | DataException ex) {
            log.error("Invalid Data to build registry {} ", ex);
            throw new DataException(ex.getMessage());
        }

    }

    @PutMapping
    public ResponseEntity<RegistrationSO> updateRegistry(@NotBlank @RequestHeader(name = "Authorization") final String authHeader,
                                                         @NotBlank @RequestParam("token") final String eislToken, @RequestBody PayloadSO payload) throws EislTokenNotValidException, DataException, RegistrationServiceException {
        log.debug("Registration service initiated to update Registry Details : {}",payload);
        String basicToken = eislUtil.trimAuthorizationSchema(authHeader);
        if (!eislUtil.getEislClaims(eislToken).containsKey(serviceId)) {
            log.error("Eisl Token not valid");
            throw new EislTokenNotValidException(messages.getMessage("app.message.EISL_INVALID_TOKEN_MSG"));
        }
        try {
            RegistrationSO dto;

            dto = registrationService.putRegistration(eislToken, payload,eislUtil.getEislClaims(eislToken).get(serviceId).toString());

            return ResponseEntity.ok()
                    .body(dto);
        } catch (DataNotFoundException | DataException ex) {
            log.error("Invalid Data to build registry {} ", ex);
            throw new DataException(ex.getMessage());
        }

    }


    @DeleteMapping
    public ResponseEntity<String> deleteRegistry(@NotBlank @RequestHeader(name = "Authorization") String authHeader,
                                                 @NotBlank @RequestParam("token") String eislToken)
            throws EislTokenNotValidException, RegistrationServiceException, BadRequestException, DataNotFoundException {
        log.debug("Registration service initiated to delete Registry Details : ");
        String basicToken = eislUtil.trimAuthorizationSchema(authHeader);
        if (!eislUtil.getEislClaims(eislToken).containsKey(serviceId)) {
            log.error("Eisl Token not valid");
            throw new EislTokenNotValidException(messages.getMessage("app.message.EISL_INVALID_TOKEN_MSG"));
        }
        try {
            String status = registrationService.deleteRegistration(registryAccessEndpoint, eislToken, eislUtil.getEislClaims(eislToken).get(role).toString());
            return ResponseEntity.ok()
                    .body(status);
        } catch (DataNotFoundException ex) {
            log.error("Invalid Data to build registry {} ", ex);
            throw new DataNotFoundException(ex.getMessage());
        }

    }

}
