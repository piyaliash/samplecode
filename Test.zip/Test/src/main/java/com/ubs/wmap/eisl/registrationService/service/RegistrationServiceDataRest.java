package com.ubs.wmap.eisl.registrationService.service;

import com.ubs.wmap.eisl.housekeeping.TokenService;
import com.ubs.wmap.eisl.housekeeping.component.exceptions.TokenExpireException;
import com.ubs.wmap.eisl.housekeeping.component.exceptions.TokenUnwrapException;
import com.ubs.wmap.eisl.registrationService.exception.*;
import com.ubs.wmap.eisl.registrationService.model.PayloadSO;
import com.ubs.wmap.eisl.registrationService.model.RegistrationSO;
import com.ubs.wmap.eisl.registrationService.model.ResponseSO;
import com.ubs.wmap.eisl.registrationService.util.EislUtil;
import com.ubs.wmap.eisl.registrationService.util.MessageSourceUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.HashMap;
import java.util.Map;


@Service
@Slf4j
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class RegistrationServiceDataRest {

    private final RestTemplate restTemplate;

    private final MessageSourceUtil messages;

    private final EislUtil eislUtil;


    ResponseEntity<RegistrationSO> getRegistryResponse(String baseUrl, String stringParam, String role)
            throws DataNotFoundException, EislTokenNotValidException, RegistrationServiceException, BadRequestException {


        log.debug("Entering get registry response method ::");
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(baseUrl + "/").path(role).queryParam("token", stringParam);

        try {
            final ResponseEntity<RegistrationSO> responseDto = restTemplate.exchange(
                    builder.toUriString(),
                    HttpMethod.GET,
                    null,
                    new ParameterizedTypeReference<RegistrationSO>() {
                    }
            );
            return responseDto;
        } catch (RestClientException e) {
            eislUtil.checkException(e);
            log.error("Internal Server occured while accessing Registry Access {} ", e);
            throw new RegistrationServiceException(messages.getMessage("app.message.REGISTRY_INTERNAL_SERVER_ERROR_MSG"));
        }
    }

    ResponseEntity<RegistrationSO> getRegistryResponseforPost(String baseUrl, String stringParam, String role)
            throws EislTokenNotValidException, RegistrationServiceException {


        log.debug("Entering get registry response for post method");
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(baseUrl + "/").path(role).queryParam("token", stringParam);

        ResponseEntity<RegistrationSO> responseDto = null;

        try {
            responseDto = restTemplate.exchange(
                    builder.toUriString(),
                    HttpMethod.GET,
                    null,
                    new ParameterizedTypeReference<RegistrationSO>() {
                    }
            );
            return responseDto;
        } catch (RestClientException e) {
            if (e instanceof HttpStatusCodeException) {
                HttpStatusCodeException ex = (HttpStatusCodeException) e;
                if (HttpStatus.UNAUTHORIZED == ex.getStatusCode()) {
                    log.error("EISL Token Exception during Registry Access Service: {} ", ex);
                    throw new EislTokenNotValidException(messages.getMessage("app.message.EISL_INVALID_REGISTRY_ACCESS"));
                }
            }
            return responseDto;
        }
    }


    RegistrationSO postRegistryResponse(String baseUrl, RegistrationSO registrationData, String eislToken)
            throws EislTokenNotValidException, RegistrationServiceException, DataException, DataNotFoundException, BadRequestException {

        log.debug("Entering post registry response method :: ");
        MultiValueMap<String, RegistrationSO> map = new LinkedMultiValueMap<String, RegistrationSO>();
        map.add("payload", registrationData);

        HttpEntity<RegistrationSO> requestEntity = new HttpEntity<>(registrationData);

        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(baseUrl).queryParam("token", eislToken);
        try {
            final ResponseEntity<RegistrationSO> responseDto = restTemplate.exchange(builder.toUriString(), HttpMethod.POST,
                    requestEntity, new ParameterizedTypeReference<RegistrationSO>() {
                    });
            return responseDto.getBody();
        } catch (RestClientException e) {
            eislUtil.checkException(e);
            log.error("Internal Server occured while accessing Registry Access", e);
            throw new RegistrationServiceException(messages.getMessage("app.message.REGISTRY_INTERNAL_SERVER_ERROR_MSG"));
        }
    }

    RegistrationSO putRegistryResponse(String baseUrl, RegistrationSO registrationData, String eislToken)
            throws DataException, EislTokenNotValidException, RegistrationServiceException, DataNotFoundException, BadRequestException {

        log.debug("Entering post registry response method ::");
        MultiValueMap<String, RegistrationSO> map = new LinkedMultiValueMap<String, RegistrationSO>();
        map.add("payload", registrationData);

        HttpEntity<RegistrationSO> requestEntity = new HttpEntity<>(registrationData);

        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(baseUrl).queryParam("token", eislToken);
        try {
            final ResponseEntity<RegistrationSO> responseDto = restTemplate.exchange(builder.toUriString(), HttpMethod.PUT,
                    requestEntity, new ParameterizedTypeReference<RegistrationSO>() {
                    });
            return responseDto.getBody();
        } catch (RestClientException e) {
            eislUtil.checkException(e);
            log.error("Internal Server occured while accessing Registry Access", e);
            throw new RegistrationServiceException(messages.getMessage("app.message.REGISTRY_INTERNAL_SERVER_ERROR_MSG"));
        }
    }


    ResponseEntity<String> getEventsResponse(String baseUrl, String eislToken, String serviceId) throws DataNotFoundException, EislTokenNotValidException, RegistrationServiceException, BadRequestException {

        log.debug("Entering get Event method ::");

        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(baseUrl).queryParam("serviceid", serviceId).queryParam("token", eislToken);
        try {
            final ResponseEntity<String> responseDto = restTemplate.exchange(builder.toUriString(), HttpMethod.GET,
                    null, new ParameterizedTypeReference<String>() {
                    });
            return responseDto;
        } catch (RestClientException e) {
            eislUtil.validateRestClientExceptionForEvents(e);
            log.error("Internal Server occured while accessing Registry Access", e);
            throw new RegistrationServiceException(messages.getMessage("app.message.EVENTS_INTERNAL_SERVER_ERROR_MSG"));
        }
    }


    String getEventsResponseforGet(String baseUrl, String eislToken,String serviceId) throws DataNotFoundException, EislTokenNotValidException, RegistrationServiceException {

        log.debug("Entering get Event Response for Get Method ::");
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(baseUrl).queryParam("serviceid", serviceId).queryParam("token", eislToken);
        ResponseEntity<String>  responseDto = null;

        try {
            responseDto = restTemplate.exchange(builder.toUriString(), HttpMethod.GET,
                    null, new ParameterizedTypeReference<String> () {
                    });
            return responseDto.getBody();
        } catch (RestClientException ex) {
            log.debug("No Events Data Found {}",ex);
            return "";
        }
    }

    String getDataResponse(String baseUrl, String firstParam, String stringParam)
            throws EislTokenNotValidException {

        log.debug("BaseURL: {}, firstParam: {}, stringParam: {}", baseUrl, firstParam, stringParam);
        Map<String, String> uriParams = new HashMap<>();
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(baseUrl).queryParam("serviceid", stringParam).queryParam("token", firstParam);

        try {
            final ResponseEntity<String> responseDto = restTemplate.exchange(builder.toUriString(), HttpMethod.GET,
                    null, new ParameterizedTypeReference<String>() {
                    });
            return responseDto.getBody();
        } catch (RestClientException e) {
            if (e instanceof HttpStatusCodeException) {
                HttpStatusCodeException ex = (HttpStatusCodeException) e;
                if (HttpStatus.UNAUTHORIZED == ex.getStatusCode()) {
                    log.error("EISL Token Exception during Data Registry service: {} ", ex);
                    throw new EislTokenNotValidException(messages.getMessage("app.message.EISL_INVALID_DATA_ACCESS"));
                }
            }
            log.error("No Data Found from Data Registry Service: {} ", e);
            return "";
        }
    }

    String getExceptionsResponse(String baseUrl, String firstParam,
                                 String serviceId)
            throws EislTokenNotValidException {

        log.debug("BaseURL: {}, firstParam: {}, stringParam: {}", baseUrl, firstParam, serviceId);
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(baseUrl).queryParam("serviceid", serviceId).queryParam("token", firstParam);
        try {
            final ResponseEntity<String> responseDto = restTemplate.exchange(builder.toUriString(),
                    HttpMethod.GET, null, new ParameterizedTypeReference<String>() {
                    });
            return responseDto.getBody();
        } catch (RestClientException e) {
            if (e instanceof HttpStatusCodeException) {
                HttpStatusCodeException ex = (HttpStatusCodeException) e;
                if (HttpStatus.UNAUTHORIZED == ex.getStatusCode()) {
                    log.error("EISL Token Exception during exception service: {} ", ex);
                    throw new EislTokenNotValidException(messages.getMessage("app.message.EISL_INVALID_EXCEPTION_SERVICE"));
                }
            }
            log.error("No Data Found from Exception Registry Service: {} ", e);
            return "";
        }
    }


    protected RegistrationSO buildRegistration(PayloadSO payload, String eislToken) {
        log.debug("payload: {}, eislToken: {}", payload, eislToken);
        return RegistrationSO.builder().userName(payload.getUserName()).company(payload.getCompany()).role(payload.getRole()).build();
    }

    String getDeleteResponseForRegistryAccessService(String baseUrl,String eislToken,String registrationId) throws BadRequestException, DataNotFoundException, EislTokenNotValidException {
        log.debug("Entering deleteRegistration method :: ");
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(baseUrl).queryParam("registrationid", registrationId).queryParam("token", eislToken);
        ResponseEntity<String> responseDto =null;
        try {
            responseDto = restTemplate.exchange(builder.toUriString(), HttpMethod.DELETE,
                    null, new ParameterizedTypeReference<String>() {
                    });
            return responseDto.getStatusCode().toString();

        } catch (RestClientException e) {
            eislUtil.checkException(e);
            return "";
        }
    }


    protected Map<String, Object> buildResponseMap(Map<String, Object> registration, Map<String, Object> events, Map<String, Object> data, Map<String, Object> exception) {
        Map<String, Object> responseMap = new HashMap<>();
        responseMap.put("registration", registration);
        responseMap.put("events", events);
        responseMap.put("data", data);
        responseMap.put("exception", exception);
        return responseMap;
    }


    protected ResponseEntity<String> checkEventsData(String eislToken, String eventAccessEndpoint, String serviceId) throws RegistrationServiceException, DataNotFoundException, EislTokenNotValidException, BadRequestException {
        ResponseEntity<String> eventsResponse = getEventsResponse(eventAccessEndpoint, eislToken,serviceId);
       if (eventsResponse.getStatusCode() != HttpStatus.OK) {

            throw new DataNotFoundException(messages.getMessage("app.message.EVENT_DATA_NOT_FOUND_MESSAGE"));
        }
        return eventsResponse;
    }

    protected void checkForDataAndException(String serviceId, String eislToken, String dataAccessEndpoint,String exceptionAccessEndpoint) throws RegistrationServiceException, DataNotFoundException, EislTokenNotValidException {
        String dataResponse = getDataResponse(dataAccessEndpoint, eislToken,
                serviceId);

        String exceptionResponse = getExceptionsResponse(exceptionAccessEndpoint, eislToken,
                serviceId);

        if (dataResponse.isEmpty()) {
            log.warn("Data Reference missing ");
        }

        if (exceptionResponse.isEmpty()) {
            log.warn("Exception Reference missing ");
        }

    }


}
