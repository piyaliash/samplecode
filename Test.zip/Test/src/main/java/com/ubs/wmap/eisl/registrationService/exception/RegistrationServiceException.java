package com.ubs.wmap.eisl.registrationService.exception;

public class RegistrationServiceException extends Exception {

    public RegistrationServiceException(String message) {
        super(message);
    }
}
