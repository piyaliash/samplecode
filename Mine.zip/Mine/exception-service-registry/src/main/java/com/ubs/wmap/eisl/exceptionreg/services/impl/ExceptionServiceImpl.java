package com.ubs.wmap.eisl.exceptionreg.services.impl;

import javax.transaction.Transactional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ubs.wmap.eisl.exceptionreg.util.EislClaimsContextUtil;
import com.ubs.wmap.eisl.exceptionreg.exception.ExceptionRegException;
import com.ubs.wmap.eisl.exceptionreg.model.ExceptionData;
import com.ubs.wmap.eisl.exceptionreg.model.ExceptionReference;
import com.ubs.wmap.eisl.exceptionreg.repository.ExceptionDataRepository;
import com.ubs.wmap.eisl.exceptionreg.repository.ExceptionRefRepository;
import com.ubs.wmap.eisl.exceptionreg.services.ExceptionService;
import com.ubs.wmap.eisl.exceptionreg.services.sos.ExceptionDataResponseSO;
import com.ubs.wmap.eisl.exceptionreg.services.sos.ExceptionRequestSO;
import com.ubs.wmap.eisl.exceptionreg.services.sos.ExceptionResponseSO;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@Service
@Slf4j
public class ExceptionServiceImpl implements ExceptionService{

	
	private final ExceptionRefRepository exceptionRepository;
	
	private final ExceptionDataRepository exceptionDataRepository;
	
	private final EislClaimsContextUtil eislContextUtil;
	
	@Override
	public ExceptionResponseSO getExceptionDetails(ExceptionRequestSO exceptionRequestSO) throws ExceptionRegException{
		log.debug("exceptionRequestSO:{}",exceptionRequestSO);
		
		ExceptionResponseSO exceptionResponseSO=null;
		
		ExceptionReference exceptionReference=exceptionRepository.findByExceptionServiceId(
				exceptionRequestSO.getExceptionServiceId());
		
		if(exceptionReference!=null) {
			exceptionResponseSO=constructExceptionResponseSO(exceptionReference);
		}
		
		log.debug("exceptionResponseSO:{}",exceptionResponseSO);
		
		return exceptionResponseSO;
	}
	
	private ExceptionResponseSO constructExceptionResponseSO(ExceptionReference exceptionReference) {
		ExceptionResponseSO exceptionResponseSO=new ExceptionResponseSO();
		BeanUtils.copyProperties(exceptionReference, exceptionResponseSO);
		exceptionResponseSO.setExceptionDataResponseSO(
				constructExceptionDataResponseSO(exceptionReference.getExceptionData()));
		
		return exceptionResponseSO;
	}
	
	private ExceptionDataResponseSO constructExceptionDataResponseSO(ExceptionData exceptionData) {
		if(exceptionData!=null) {
			ExceptionDataResponseSO exceptionDataResponseSO=new ExceptionDataResponseSO();
			BeanUtils.copyProperties(exceptionData, exceptionDataResponseSO);
			return exceptionDataResponseSO;
		}
		return null;
	}

	@Transactional
	@Override
	public ExceptionResponseSO saveExceptionDetails(ExceptionRequestSO exceptionRequestSO)
			throws ExceptionRegException {
		log.debug("exceptionRequestSO:{}",exceptionRequestSO);
		
		//save parent table
		ExceptionReference exceptionReference=constructExceptionReferenceEntityFromSO(exceptionRequestSO);
		if(eislContextUtil.getContextParam("userName")!=null) {
			exceptionReference.setCreatedBy((String)eislContextUtil.getContextParam("userName"));
		}else {
			exceptionReference.setCreatedBy("DEF_USER");
		}
		//get child table data 
		ExceptionData exceptionData =exceptionDataRepository.getOne(exceptionRequestSO.getExceptionDataRefId());
		if(exceptionData!=null) {
			exceptionReference.setExceptionData(exceptionData);
		}
		exceptionReference=exceptionRepository.save(exceptionReference);
		exceptionRepository.flush();
		
		
		//get latest data
		exceptionReference=exceptionRepository.getOne(exceptionReference.getExceptionRefId());
		
		return constructExceptionResponseSO(exceptionReference);
	}
	
	private ExceptionReference constructExceptionReferenceEntityFromSO(ExceptionRequestSO exceptionRequestSO) {
		ExceptionReference exceptionReference=new ExceptionReference ();
		BeanUtils.copyProperties(exceptionRequestSO, exceptionReference);
		return exceptionReference;
	}
	
	
}
