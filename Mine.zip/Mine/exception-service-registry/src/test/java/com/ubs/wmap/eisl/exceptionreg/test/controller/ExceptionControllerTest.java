package com.ubs.wmap.eisl.exceptionreg.test.controller;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Import;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.ubs.wmap.eisl.exceptionreg.context.EislClaimsContext;
import com.ubs.wmap.eisl.exceptionreg.context.EislClaimsContextHolder;
import com.ubs.wmap.eisl.exceptionreg.controller.ExceptionRegController;
import com.ubs.wmap.eisl.exceptionreg.exception.ExceptionRefNotFoundException;
import com.ubs.wmap.eisl.exceptionreg.services.sos.ExceptionPostRequestSO;
import com.ubs.wmap.eisl.exceptionreg.services.sos.ExceptionResponseSO;
import com.ubs.wmap.eisl.housekeeping.TokenService;
import com.ubs.wmap.eisl.housekeeping.TokenServiceConfiguration;

import io.jsonwebtoken.Claims;

@RunWith(SpringRunner.class)
@DataJpaTest
@EnableAutoConfiguration
@Import(TokenServiceConfiguration.class)
@ComponentScan(basePackages = { "com.ubs.wmap.eisl.exceptionreg" })
public class ExceptionControllerTest {

	@Autowired
	private ExceptionRegController exceptionRegController;
	
	@Autowired
	private TokenService tokenService;

	@Test
	public void testExceptionControllerData() throws Exception {
		createEislContext();
		ResponseEntity<ExceptionResponseSO> responseEntity = exceptionRegController.getExceptionDetails("eislToken","1");
		assertNotNull(responseEntity);
	}

	@Test
	public void testExceptionControllerWithoutData() throws Exception {
		createEislContext();
		try {
			exceptionRegController.getExceptionDetails("eislToken","13");
		} catch (ExceptionRefNotFoundException ex) {
			assertTrue("Exception is thrown when Data not Found",true);
		}
	}
	
	
	@Test
	public void testPostExceptionDetails() throws Exception {
		createEislContext();
	
		ExceptionPostRequestSO exceptionPostRequestSO = new ExceptionPostRequestSO();
		exceptionPostRequestSO.setCategory("category");
		exceptionPostRequestSO.setSeverity("severity");
		exceptionPostRequestSO.setExceptionTopic("topic");
		exceptionPostRequestSO.setExceptionDataRefId(Long.valueOf("1"));
		ResponseEntity<ExceptionResponseSO> responseEntity = exceptionRegController.saveExceptionDetails("eislToken",exceptionPostRequestSO);
		assertNotNull(responseEntity.getBody().getExceptionRefId());

	}
	
	
	public void createEislContext() {
		/** This is just for testing and to be remove**/
		String eislToken = tokenService.init("userid", "1", "Admin");
		Claims claims = tokenService.unwrapEislToken(eislToken);
		createAndSetClaimsInContext(claims);
	}
	
	
	private void createAndSetClaimsInContext(Claims claims) {
		EislClaimsContext eislClaimsContext = new EislClaimsContext();
		eislClaimsContext.setClaims(claims);
		EislClaimsContextHolder.set(eislClaimsContext);
	}

}
