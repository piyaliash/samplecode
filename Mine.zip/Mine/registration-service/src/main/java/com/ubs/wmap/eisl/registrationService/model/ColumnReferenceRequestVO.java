package com.ubs.wmap.eisl.registrationService.model;

import java.io.Serializable;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
public class ColumnReferenceRequestVO implements Serializable {

	private static final long serialVersionUID = -4254569322670907803L;
	private String name;
	private String type;
}
