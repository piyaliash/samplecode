package com.ubs.wmap.eisl.registrationService.model;

import java.io.Serializable;
import java.util.Set;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Builder
public class RegistrationSO implements Serializable{

	private static final long serialVersionUID = 6349874774163306834L;
	private String userName;
	private String userId;
	private String company;
	private String eislToken;
	private String serviceId;
	private String dataEntitlement;
	private RoleRequestVO role;
	private Set<ColumnReferenceRequestVO> columnReferences;
	private Set<RowReferenceRequestVO> rowReferences;
}
