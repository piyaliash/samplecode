package com.ubs.wmap.eisl.registryaccessservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.ubs.wmap.eisl.registryaccessservice.model.Roles;

@Repository
public interface RoleRepository extends JpaRepository<Roles, Long>{

}
