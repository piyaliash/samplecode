package com.ubs.wmap.eisl.eventregistry.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ubs.wmap.eisl.eventregistry.controller.delegates.EventDelegate;
import com.ubs.wmap.eisl.eventregistry.exception.EventBadRequestException;
import com.ubs.wmap.eisl.eventregistry.exception.EventException;
import com.ubs.wmap.eisl.eventregistry.exception.EventNotFoundException;
import com.ubs.wmap.eisl.eventregistry.services.sos.EventRequestSO;
import com.ubs.wmap.eisl.eventregistry.services.sos.EventResponseSO;
import com.ubs.wmap.eisl.eventregistry.util.EislClaimsContextUtil;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@RestController
@Slf4j
public class EventController {

	private final EventDelegate eventDelegate;

	private final EislClaimsContextUtil eislClaimsContextUtil;

	@Value("${app.message.INTERNAL_SERVER_ERROR_MSG}")
	private String INTERNAL_SERVER_ERROR_MSG;

	@Value("${app.message.EVENT_NOT_FOUND_MSG}")
	private String EVENT_NOT_FOUND_MSG;
	
	@Value("${app.message.SERVICE_ID_EMPTY_MSG}")
	private String SERVICE_ID_EMPTY_MSG;
	
	@GetMapping(value = "/eisl/event/v1/events")
	public ResponseEntity<EventResponseSO> getEventDetails(@RequestParam("eislToken") String eislToken)
			throws EventException, EventBadRequestException, EventNotFoundException {
		EventResponseSO eventResponseSO = null;

		// Get service id from the claims
		String serviceId = null;
		Object serviceIdObj = eislClaimsContextUtil.getContextParam("serviceId");
		if (serviceIdObj != null) {
			serviceId = (String) serviceIdObj;
		}
		log.debug("serviceId from claims:{}", serviceId);
		if (StringUtils.isEmpty(serviceId)) {
			throw new EventBadRequestException(SERVICE_ID_EMPTY_MSG);
		}

		try {
			eventResponseSO = eventDelegate.getEventDetails(serviceId);
			if (eventResponseSO == null) {
				throw new EventNotFoundException(EVENT_NOT_FOUND_MSG + ":" + serviceId);
			}

		} catch (EventException eventException) {
			log.error(eventException.getMessage(), eventException);
			throw new EventException(INTERNAL_SERVER_ERROR_MSG);
		}
		return ResponseEntity.ok(eventResponseSO);
	}

	@PostMapping(value = "/eisl/event/v1/event")
	public ResponseEntity<EventResponseSO> saveEventDetails(@RequestParam("eislToken") String eislToken,
			@RequestBody EventRequestSO eventRequestSO)
			throws EventException {
		log.debug("eventRequestSO:{}", eventRequestSO);
		EventResponseSO eventResponseSO = null;

		try {
			eventResponseSO = eventDelegate.saveEventDetails(eventRequestSO);

		} catch (EventException eventException) {
			log.error(eventException.getMessage(), eventException);
			throw new EventException(INTERNAL_SERVER_ERROR_MSG);
		}
		log.debug("eventResponseSO:{}", eventResponseSO);
		return ResponseEntity.ok(eventResponseSO);
	}
}
