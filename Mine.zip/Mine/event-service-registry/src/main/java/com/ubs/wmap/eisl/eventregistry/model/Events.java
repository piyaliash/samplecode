package com.ubs.wmap.eisl.eventregistry.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import lombok.Data;

@Data
@Entity
@Table(name = "EVENTS")
@EntityListeners(AuditingEntityListener.class)
public class Events implements Serializable  {

	private static final long serialVersionUID = -2960973719692214842L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "EVENT_SERVICE_ID")
	private Long eventServiceId;

	@Column(name = "SERVICE_ID")
	private String serviceId;
	
	@Column(name = "SERVICE_NAME")
	private String serviceName;
	
	@Column(name = "EVENT_TOPIC")
	private String eventTopic;
	
	@Column(name = "DATA_SERVICE_ID")
	private Integer dataServiceId;
	
	@Column(name = "EXCEPTION_SERVICE_ID")
	private Integer exceptionServiceId;
	
	@Column(name = "CREATED_BY", nullable = false, updatable = false )
	private String createdBy;
	
	@Column(name = "LAST_UPDATED_BY")
	private String lastUpdatedBy;
	
	@Column(name = "CREATION_DATE" , nullable = false, updatable = false)
	@Temporal(TemporalType.TIMESTAMP)
	@CreatedDate
	private Date createdDate;
	
	@Column(name = "LAST_UPDATED_DATE")
	@Temporal(TemporalType.TIMESTAMP)
	@LastModifiedDate
	private Date lastUpdatedDate;


}
