package com.ubs.wmap.eisl.eventregistry.test.repository;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.test.context.junit4.SpringRunner;

import com.ubs.wmap.eisl.eventregistry.model.Events;
import com.ubs.wmap.eisl.eventregistry.repository.EventRepository;

@RunWith(SpringRunner.class)
@DataJpaTest
@EnableAutoConfiguration
@ComponentScan(basePackages = { "com.ubs.wmap.eisl.eventregistry" })
public class EventRepositoryTest {

	@Autowired
	private EventRepository eventRepository;

	@Test
	public void testfindByServiceIdWithData() throws Exception {
		Events values = eventRepository.findByServiceId("1");
		assertNotNull(values);
	}
	
	
	@Test
	public void testfindByServiceIdWithOutData() throws Exception {
		Events values = eventRepository.findByServiceId("3");
		assertNull(values);
	}

}
