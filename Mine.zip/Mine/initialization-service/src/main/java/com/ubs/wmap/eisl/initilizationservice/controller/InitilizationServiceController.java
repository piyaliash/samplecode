
package com.ubs.wmap.eisl.initilizationservice.controller;

import javax.validation.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import com.ubs.wmap.eisl.initilizationservice.exceptions.InvalidEislTokenException;
import com.ubs.wmap.eisl.initilizationservice.models.Payload;
import com.ubs.wmap.eisl.initilizationservice.service.InitilizationServiceImpl;

import lombok.extern.slf4j.Slf4j;


@RestController
@Slf4j
@RequestMapping(produces = "application/json")
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class InitilizationServiceController {
    

    private final InitilizationServiceImpl initializationService;
    
    @PostMapping(value = "/eisl/intialization/v1/registrations")
    public ResponseEntity<?> postInitialization(@NotBlank @RequestHeader(name = "BasicToken") final String basicToken,
            @NotBlank @RequestParam("Role") final String Role, @NotBlank @RequestParam("userId") final String userId, @NotBlank @RequestParam("serviceId") final String serviceId,@RequestBody Payload payload) throws InvalidEislTokenException
    {
        try {
            //log.debug("Entering Intialization Sequence");
            String eislToken = initializationService.generateEislToken(basicToken, null, userId);
            initializationService.postRegistration(basicToken, eislToken, payload);
            return ResponseEntity.ok().body(eislToken);
        } catch (InvalidEislTokenException ex) {
            //log.error("Eisl Token could not be built");
            throw new InvalidEislTokenException("Insufficent Data to build Eisl Token");
        }
        
    }
    
}
