/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ubs.wmap.eisl.initilizationservice.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;


@ResponseStatus(code = HttpStatus.FORBIDDEN, reason = "Invalid Eisl Token")
public class InvalidEislTokenException extends Exception {

   
    public InvalidEislTokenException() {
    }


    public InvalidEislTokenException(String msg) {
        super(msg);
    }
}
