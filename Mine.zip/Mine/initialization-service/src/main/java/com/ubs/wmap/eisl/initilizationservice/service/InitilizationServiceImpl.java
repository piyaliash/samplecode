
package com.ubs.wmap.eisl.initilizationservice.service;

import com.ubs.wmap.eisl.housekeeping.TokenService;
import com.ubs.wmap.eisl.housekeeping.component.TokenServiceImpl;
import com.ubs.wmap.eisl.initilizationservice.exceptions.InvalidEislTokenException;
import com.ubs.wmap.eisl.initilizationservice.models.Payload;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

@Service
@Slf4j
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class InitilizationServiceImpl implements InitilizationService{
    

    private final TokenService tokenSerivce;
    

    private final RestTemplate restTemplate;
   
    
    public boolean validateEislToken(String eislToken) throws InvalidEislTokenException{
        try{
        boolean isValid = tokenSerivce.isEISLTokenValid(eislToken);
        return isValid;
        }
        catch(Exception e){
          throw new InvalidEislTokenException();
        }
    }
    
    public String generateEislToken(String basicToken,String eislToken,String claims) throws InvalidEislTokenException{
        try{
        String newToken = tokenSerivce.init(basicToken, eislToken, claims);
        return newToken;
        }catch(Exception e)
        {
            throw new InvalidEislTokenException();
        }
    }
    
    @Override
    public void postRegistration(String basicToken,String eislToken, Payload payload){
        String url = "/eisl/resitraion/v1/registrations";
        HttpHeaders headers = new HttpHeaders();
        headers.add("basicToken", basicToken);
        MultiValueMap<String,Object> request = new LinkedMultiValueMap<>();
        request.add("payload", payload);
        HttpEntity<Object> requestEntity = new HttpEntity<>(request,headers);
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url).queryParam("eislToken", eislToken);
        restTemplate.postForObject(builder.toUriString(), requestEntity, String.class);
    }
    
    @Override
    public void putRegistration(String basicToken,String eislToken, Payload payload){
     String url = "/eisl/resitraion/v1/registrations";
        HttpHeaders headers = new HttpHeaders();
        headers.add("basicToken", basicToken);
        MultiValueMap<String,Object> request = new LinkedMultiValueMap<>();
        request.add("payload", payload);
        HttpEntity<Object> requestEntity = new HttpEntity<>(request,headers);
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url).queryParam("eislToken", eislToken);
        restTemplate.put(builder.toUriString(), String.class, requestEntity);
    }
    
    @Override
    public void deleteRegistration(String basicToken,String eislToken){
        HttpHeaders headers = new HttpHeaders();
        headers.add("basicToken", basicToken);
        HttpEntity<String> requestEntity = new HttpEntity<>(headers);
        final String url = "/eisl/registration/v1/registration";
        
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url).queryParam("eislToken", eislToken);
        restTemplate.delete(builder.toUriString(), requestEntity);   
    }
    
    
    
}
