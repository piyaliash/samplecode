
package com.ubs.wmap.eisl.initilizationservice.controller;

import javax.validation.constraints.NotBlank;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import com.ubs.wmap.eisl.initilizationservice.exceptions.InvalidEislTokenException;
import com.ubs.wmap.eisl.initilizationservice.service.InitilizationServiceImpl;

import lombok.extern.slf4j.Slf4j;


@RestController
@Slf4j
@RequestMapping(produces = "application/json")
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class TerminateController {


    private final InitilizationServiceImpl initializationService;


    @DeleteMapping(value = "/intialization/v1/registrations")
    public ResponseEntity<?> terminateInitilization(@NotBlank @RequestHeader (name = "basicToken") final String basicToken,
            @NotBlank @RequestParam("eislToken") final String eislToken ) throws InvalidEislTokenException
    {
        try {
            //log.debug("Entering Terminate Sequence");
            boolean isValid = initializationService.validateEislToken(eislToken);
            initializationService.deleteRegistration(basicToken, eislToken);
            return ResponseEntity.ok().build();
        } catch (InvalidEislTokenException ex) {
            //log.error("Eisl Token Invalid");
            throw new InvalidEislTokenException("EislTokenNotValid");
        }
    }
}
