package com.ubs.wmap.eisl.dataserviceregistry;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;

import com.ubs.wmap.eisl.dataserviceregistry.exception.DataReferenceException;
import com.ubs.wmap.eisl.dataserviceregistry.model.DataFilterReference;
import com.ubs.wmap.eisl.dataserviceregistry.model.DataOutReference;
import com.ubs.wmap.eisl.dataserviceregistry.model.DataReference;
import com.ubs.wmap.eisl.dataserviceregistry.repository.DataFilterReferenceRepository;
import com.ubs.wmap.eisl.dataserviceregistry.repository.DataOutReferenceRepository;
import com.ubs.wmap.eisl.dataserviceregistry.repository.DataRefefrenceRepository;
import com.ubs.wmap.eisl.dataserviceregistry.service.impl.DataReferenceServiceImpl;
import com.ubs.wmap.eisl.dataserviceregistry.vo.DataFilterReferenceRequest;
import com.ubs.wmap.eisl.dataserviceregistry.vo.DataFilterResponse;
import com.ubs.wmap.eisl.dataserviceregistry.vo.DataOutReferenceRequest;
import com.ubs.wmap.eisl.dataserviceregistry.vo.DataOutReferenceResponse;
import com.ubs.wmap.eisl.dataserviceregistry.vo.DataReferenceRequest;
import com.ubs.wmap.eisl.dataserviceregistry.vo.DataReferenceResponse;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

@Slf4j
@ActiveProfiles("test")
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.DEFINED_PORT)
@ComponentScan(basePackages = {"com.ubs.wmap.eisl.dataserviceregistry"})
public class DataReferenceServiceTest{
	
	@Mock
	private DataRefefrenceRepository dataRepo;
	
	@Mock
	private DataOutReferenceRepository dataOutReferenceRepository;
	
	@Mock
	private DataFilterReferenceRepository dataFilterReferenceRepository;
	
	@InjectMocks
	private DataReferenceServiceImpl dataService;
	
	@Test
	public void testGetDataReference() throws DataReferenceException {
		//prepare data
		DataReferenceRequest dataReferenceRequest = new DataReferenceRequest();
		dataReferenceRequest.setDataServiceId("TestService1");
		
		DataReference dataReferenceResponse = new DataReference();
		dataReferenceResponse.setDataInTopic("TestTopic");
		dataReferenceResponse.setDataReferenceId(1);
		dataReferenceResponse.setDataServiceId("TestService1");
		Set<DataOutReference> dataOutRefs = new HashSet<>();
		
		DataFilterReference dataFilterReference = new DataFilterReference();
		dataFilterReference.setFilterRefernceId(1);
		dataFilterReference.setName("filterName");
		dataFilterReference.setOptions("filteroption");
		
		DataOutReference dataOut = new DataOutReference();
		dataOut.setDataOutReferenceId(1);
		dataOut.setDataType("dataTypeTest");
		dataOut.setProtocolName("protocolTest");
		dataOut.setTopic("TopicTest");
		dataOut.setDataFilterReference(dataFilterReference);
		
		dataOutRefs.add(dataOut);
		dataReferenceResponse.setDataOutReferences(dataOutRefs);
		
		//Mock repo data
        Mockito.when(dataRepo.findBydataServiceId("TestService1")).thenReturn(dataReferenceResponse);
        
        DataReferenceResponse dataReference = dataService.getDataReference(dataReferenceRequest);
        assertNotNull(dataReference);
        assertEquals("TestTopic", dataReference.getDataInTopic());
        assertEquals("TestService1", dataReference.getDataServiceId());
        assertEquals(new Integer(1), dataReference.getDataReferenceId());
        Set<DataOutReferenceResponse> dataOutReferences = dataReference.getDataOutReferences();
        assertNotNull(dataOutReferences);
        assertEquals(1, dataOutReferences.size());
        for (DataOutReferenceResponse dataOutReferenceResponse : dataOutReferences) {
			assertEquals(new Integer(1), dataOutReferenceResponse.getDataOutReferenceId());
			assertEquals("dataTypeTest", dataOutReferenceResponse.getDataType());
			assertEquals("protocolTest", dataOutReferenceResponse.getProtocolName());
			assertEquals("TopicTest", dataOutReferenceResponse.getTopic());
			DataFilterResponse dataFilt = dataOutReferenceResponse.getDataFilterReference();
			assertNotNull(dataFilt);
			assertEquals(new Integer(1), dataFilt.getFilterRefernceId());
			assertEquals("filterName", dataFilt.getName());
			assertEquals("filteroption", dataFilt.getOptions());
		}
	}

	@Test
	public void testPostDataReference() throws DataReferenceException {
		//Mock repo data
        Mockito.when(dataRepo.findById(1)).thenReturn(getDataFReferenceMockedDataById(true));
        Optional<DataReference> dataRefe = getDataFReferenceMockedDataById(false);
        Mockito.when(dataRepo.save( dataRefe.get())).thenReturn(getDataFReferenceMockedDataById(true).get());
        Mockito.when(dataOutReferenceRepository.save( getDataOutRef(false))).thenReturn(getDataOutRef(true));
        Mockito.when(dataFilterReferenceRepository.save( getDataFilterReference(false))).thenReturn(getDataFilterReference(true));
        DataReferenceResponse saveDataReference = dataService.saveDataReference(getDataReferenceRequest());
        assertNotNull(saveDataReference);
        //Need to write other assert
	}
	
	private DataOutReference getDataOutRef(boolean isIdRequired) {
		DataOutReference dataOutReference = new DataOutReference();
		dataOutReference.setDataType("dataType");
		dataOutReference.setProtocolName("protocolName");
		dataOutReference.setTopic("topic");
		if(isIdRequired) {
			dataOutReference.setDataOutReferenceId(1);
		}
		return dataOutReference;
	}
	
	private DataFilterReference getDataFilterReference(boolean isIdRequired){
		DataFilterReference dataFilterReference = new DataFilterReference();
		dataFilterReference.setName("filterName");
		dataFilterReference.setName("filteroption");
		if(isIdRequired) {
			dataFilterReference.setFilterRefernceId(1);
		}
		return dataFilterReference;
	}
	
	private DataReferenceRequest getDataReferenceRequest() {
		DataReferenceRequest dataReferenceRequest = new DataReferenceRequest();
		dataReferenceRequest.setDataInTopic("TestTopic");
		dataReferenceRequest.setDataServiceId("TestService1");
		dataReferenceRequest.setDataReferenceId(1);
		List<DataOutReferenceRequest> dataOutReferenceRequests = new ArrayList<>();
		DataOutReferenceRequest dataOutReferenceRequest = new DataOutReferenceRequest();
		dataOutReferenceRequest.setDataType("dataType");
		dataOutReferenceRequest.setProtocolName("protocolName");
		dataOutReferenceRequest.setTopic("topic");
		DataFilterReferenceRequest dataFilterReferenceRequest = new DataFilterReferenceRequest();
		dataFilterReferenceRequest.setName("filterName");
		dataFilterReferenceRequest.setOptions("filteroption");
		dataOutReferenceRequest.setDataFilterReferenceRequest(dataFilterReferenceRequest);
		dataReferenceRequest.setOutReferenceRequests(dataOutReferenceRequests);
		return dataReferenceRequest;
	}
	
	private Optional<DataReference> getDataFReferenceMockedDataById(boolean isIdRequired) {
		DataReference dataReferenceResponse = new DataReference();
		Optional<DataReference> of = Optional.of(dataReferenceResponse);
		
		dataReferenceResponse.setDataInTopic("TestTopic");
		if (isIdRequired) {
			dataReferenceResponse.setDataReferenceId(1);
		}
		dataReferenceResponse.setDataServiceId("TestService1");
		Set<DataOutReference> dataOutRefs = new HashSet<>();
		
		DataFilterReference dataFilterReference = new DataFilterReference();
		if (isIdRequired) {
			dataFilterReference.setFilterRefernceId(1);
		}
		dataFilterReference.setName("filterName");
		dataFilterReference.setOptions("filteroption");
		
		DataOutReference dataOut = new DataOutReference();
		if (isIdRequired) {
			dataOut.setDataOutReferenceId(1);
		}
		dataOut.setDataType("dataType");
		dataOut.setProtocolName("protocolName");
		dataOut.setTopic("topic");
		dataOut.setDataFilterReference(dataFilterReference);
		
		dataOutRefs.add(dataOut);
		dataReferenceResponse.setDataOutReferences(dataOutRefs);
		return of;
	}
}
