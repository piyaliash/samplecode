package com.ubs.wmap.eisl.registryaccessservice;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.HashSet;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.util.NestedServletException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ubs.wmap.eisl.registryaccessservice.controller.RegistryAccessController;
import com.ubs.wmap.eisl.registryaccessservice.service.RegistryReferenceService;
import com.ubs.wmap.eisl.registryaccessservice.util.EislClaimsContextUtil;
import com.ubs.wmap.eisl.registryaccessservice.vo.ColumnReferenceRequestVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.ColumnReferenceResponseVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.RegistrationRequestVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.RegistrationResponseVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.RegistryAccessRequestVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.RoleRequestVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.RoleResponseVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.RowReferenceRequestVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.RowReferenceResponseVO;

@ActiveProfiles("test")
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ComponentScan(basePackages = {"com.ubs.wmap.eisl.registryaccessservice"})
public class RegistryAccessControllerTest {
private MockMvc mockMvc;
	
	@Mock
	private RegistryReferenceService registryReferenceService;
	@Mock
	private EislClaimsContextUtil eislClaimsContextUtil;
	@InjectMocks
	private RegistryAccessController registryAccessController;
	
	@Autowired
	private WebApplicationContext webApplicationContext;
	
	@Autowired
	private RegistryAccessController controller;
	
	@Before
	public void setup() {
		mockMvc= MockMvcBuilders.standaloneSetup(registryAccessController).build();
	}
	@Test
	public void testGetRegistryDetails() throws Exception {
		
		RegistryAccessRequestVO registryRequestVO = new RegistryAccessRequestVO();
		registryRequestVO.setServiceId("testService");
		
		Mockito.when(eislClaimsContextUtil.getContextParam("serviceId")).thenReturn("testService");
		
		Mockito.when(registryReferenceService.getRegistryReference(registryRequestVO)).thenReturn(getRegistrationResponse(false));
		mockMvc.perform(get("/eisl/users/v1/registrations").param("eislToken", "abcd-abc12-qwe")).andDo(print()).andExpect(status().isOk())
		.andExpect(content().contentType("application/json;charset=UTF-8"))
		.andExpect(MockMvcResultMatchers.jsonPath("$.role").exists())
		.andExpect(MockMvcResultMatchers.jsonPath("$.columnReferences").exists())
		.andExpect(MockMvcResultMatchers.jsonPath("$.rowReferences").exists())
		.andExpect(MockMvcResultMatchers.jsonPath("$.serviceId").value("testService"))
		.andExpect(MockMvcResultMatchers.jsonPath("$.userName").value("gana"))
		.andExpect(MockMvcResultMatchers.jsonPath("$.userId").value("test123"))
		.andExpect(MockMvcResultMatchers.jsonPath("$.eislToken").value("token-sample"));
	}
	
	@Test
	public void testSaveRegistryDetails() throws Exception {
		
		Mockito.when(registryReferenceService.persistRegistry(getRegistrationRequestData())).thenReturn(getRegistrationResponse(true));
		
		mockMvc.perform(post("/eisl/users/v1/registrations").contentType(MediaType.APPLICATION_JSON)
				.content(asJsonString(getRegistrationRequestData())).param("eislToken", "abcd-abc12-qwe")).andDo(print()).andExpect(status().isOk())
		.andExpect(content().contentType("application/json;charset=UTF-8"))
		.andExpect(MockMvcResultMatchers.jsonPath("$.role").exists())
		.andExpect(MockMvcResultMatchers.jsonPath("$.columnReferences").exists())
		.andExpect(MockMvcResultMatchers.jsonPath("$.rowReferences").exists())
		.andExpect(MockMvcResultMatchers.jsonPath("$.registrationId").value(1))
		.andExpect(MockMvcResultMatchers.jsonPath("$.serviceId").value("testService"))
		.andExpect(MockMvcResultMatchers.jsonPath("$.userName").value("gana"))
		.andExpect(MockMvcResultMatchers.jsonPath("$.userId").value("test123"))
		.andExpect(MockMvcResultMatchers.jsonPath("$.eislToken").value("token-sample"));
	}
	
	@Test(expected = NestedServletException.class)
	public void testExceptionWhenServiceIdEmpty() throws Exception {
		RegistryAccessRequestVO registryRequestVO = new RegistryAccessRequestVO();
		registryRequestVO.setServiceId("testService");
		Mockito.when(eislClaimsContextUtil.getContextParam("serviceId")).thenReturn("");
		
		Mockito.when(registryReferenceService.getRegistryReference(registryRequestVO)).thenReturn(getRegistrationResponse(false));
		mockMvc.perform(get("/eisl/users/v1/registrations").param("eislToken", "abcd-abc12-qwe")).andDo(print()).andExpect(status().isOk());
		
	}
	
	@Test(expected = Exception.class)
	public void whenGetDataReferenceExceptionCaught() throws Exception {
		controller.getRegistryDetails("vsfsd-hbjh-hbhj");
	}
	private RegistrationRequestVO getRegistrationRequestData() {
		RegistrationRequestVO registrationRequestVO = new RegistrationRequestVO();
		registrationRequestVO.setRegistrationId(1L);
		registrationRequestVO.setCompany("testcomp");
		registrationRequestVO.setDataEntitlement("dataent");
		registrationRequestVO.setEislToken("qbcd");
		registrationRequestVO.setServiceId("TestService1");
		registrationRequestVO.setUserId("testuser");
		registrationRequestVO.setUserName("user");
		RoleRequestVO roleRequestVO = new RoleRequestVO();
		roleRequestVO.setConsume("TestConsume");
		roleRequestVO.setPublish("publish");
		registrationRequestVO.setRole(roleRequestVO);
		Set<ColumnReferenceRequestVO> columnReferences = new HashSet<>();
		Set<RowReferenceRequestVO> rowReferences = new HashSet<>();
		ColumnReferenceRequestVO columnReferenceRequestVO = new ColumnReferenceRequestVO();		
		columnReferenceRequestVO.setName("name");
		columnReferenceRequestVO.setType("type");
		columnReferences.add(columnReferenceRequestVO);
		RowReferenceRequestVO rowReferenceRequestVO = new RowReferenceRequestVO();
		rowReferenceRequestVO.setName("reowName");
		rowReferenceRequestVO.setRange("rangeType");
		rowReferences.add(rowReferenceRequestVO);
		registrationRequestVO.setColumnReferences(columnReferences);
		registrationRequestVO.setRowReferences(rowReferences);
		
		return registrationRequestVO;
	}
	private RegistrationResponseVO getRegistrationResponse(boolean isIdRequired) {
		RegistrationResponseVO registrationResponseVO = new RegistrationResponseVO();
		if(isIdRequired) {
			registrationResponseVO.setRegistrationId(1L);
		}
		registrationResponseVO.setServiceId("testService");
		registrationResponseVO.setCompany("ubs");
		registrationResponseVO.setDataEntitlement("test");
		registrationResponseVO.setEislToken("token-sample");
		registrationResponseVO.setRegistrationId(1L);
		registrationResponseVO.setUserName("gana");
		registrationResponseVO.setUserId("test123");
		RoleResponseVO roleresp = new RoleResponseVO();
		if(isIdRequired) {
			roleresp.setRoleId(1L);
		}
		roleresp.setPublish("publish");
		roleresp.setConsume("consume");
		registrationResponseVO.setRole(roleresp);

		Set<ColumnReferenceResponseVO> columnReferences = new HashSet<>();
		
		ColumnReferenceResponseVO col = new ColumnReferenceResponseVO();
		if(isIdRequired) {
			col.setColumnReferenceId(1);
		}
		col.setJsonModel("jsonmodel");
		col.setName("name");
		col.setProjectionId("1");
		columnReferences.add(col);
		
		Set<RowReferenceResponseVO> rowReferences = new HashSet<>();
		RowReferenceResponseVO row = new RowReferenceResponseVO();
		row.setName("rowname");
		row.setRange("range");
		if(isIdRequired) {
			row.setRowReferenceId(1);
		}
		rowReferences.add(row);
		registrationResponseVO.setColumnReferences(columnReferences);
		registrationResponseVO.setRowReferences(rowReferences);
		return registrationResponseVO;
	}
	private String asJsonString(RegistrationRequestVO request) {
		String asJson = null;
		try {
			asJson = new ObjectMapper().writeValueAsString(request);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		return asJson;
	}
}
