package com.ubs.wmap.eisl.eventregistry.services.impl;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import com.ubs.wmap.eisl.eventregistry.exception.EventException;
import com.ubs.wmap.eisl.eventregistry.model.Events;
import com.ubs.wmap.eisl.eventregistry.repository.EventRepository;
import com.ubs.wmap.eisl.eventregistry.services.EventService;
import com.ubs.wmap.eisl.eventregistry.services.sos.EventRequestSO;
import com.ubs.wmap.eisl.eventregistry.services.sos.EventResponseSO;
import com.ubs.wmap.eisl.eventregistry.util.EislClaimsContextUtil;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@Service
@Slf4j
public class EventServiceImpl implements EventService{


	private final EventRepository eventRepository;
	
	private final EislClaimsContextUtil eislContextUtil;
	
	@Override
	public EventResponseSO getEventDetails(EventRequestSO eventRequestSO) throws EventException{
		log.debug("eventRequestSO:{}",eventRequestSO);
		
		EventResponseSO eventResponseSO=null;
		
		Events events=eventRepository.findByServiceId(eventRequestSO.getServiceId());
		
		if(events!=null) {
			eventResponseSO=constructEventResponseSO(events);
		}
		
		log.debug("eventResponseSO:{}",eventResponseSO);
		
		return eventResponseSO;
	}
	
	private EventResponseSO constructEventResponseSO(Events events) {
		EventResponseSO eventResponseSO=new EventResponseSO();
		BeanUtils.copyProperties(events, eventResponseSO);
		return eventResponseSO;
	}

	@Override
	public EventResponseSO saveEventDetails(EventRequestSO eventRequestSO) throws EventException {
		log.debug("eventRequestSO:{}",eventRequestSO);
		Events events=constructEventsEntityFromSO(eventRequestSO);
		Object userName=eislContextUtil.getContextParam("userName");
		if(userName!=null) {
			events.setCreatedBy((String)userName);
		}else {
			events.setCreatedBy("DEF_USER");
		}
		try {
			events=eventRepository.save(events);
		}catch(DataIntegrityViolationException dataIntegrityViolationException ) {
			log.error(dataIntegrityViolationException.getMessage(), dataIntegrityViolationException);
			throw new EventException("DataIntegrityViolationException");
		}
		
		//get latest data 
		events=eventRepository.getOne(events.getEventServiceId());
		
		EventResponseSO eventResponseSO=constructEventResponseSO(events);
		log.debug("eventResponseSO:{}",eventResponseSO);
		return eventResponseSO;
	}
	
	
	private Events constructEventsEntityFromSO(EventRequestSO eventRequestSO) {
		Events events=new Events();
		BeanUtils.copyProperties(eventRequestSO, events);
		return events;
	}

}
