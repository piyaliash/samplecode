package com.ubs.wmap.eisl.eventregistry.test.repository;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.test.context.junit4.SpringRunner;

import com.ubs.wmap.eisl.eventregistry.model.Events;
import com.ubs.wmap.eisl.eventregistry.repository.EventRepository;

@RunWith(SpringRunner.class)
@DataJpaTest
@EnableAutoConfiguration
@ComponentScan(basePackages = { "com.ubs.wmap.eisl.eventregistry" })
public class EventRepositoryTest {

	@Autowired
	private EventRepository eventRepository;

	/**
	 * Get event details for given service id
	 */
	@Test
	public void testfindByServiceIdWithData() throws Exception {
		Events events = eventRepository.findByServiceId("1");
		assertNotNull(events.getEventServiceId());
	}
	
	
	/**
	 * No event data found for given service id
	 */
	@Test
	public void testfindByServiceIdWithOutData() throws Exception {
		Events events = eventRepository.findByServiceId("3");
		assertNull("No data found so checking for null object",events);
	}
	
	/**
	 * Save event details
	 */
	@Test
	public void testSaveEventData() throws Exception {
		Events events = new Events();
		events.setServiceId("serviceId5");
		events.setServiceUrl("serviceUrl5");
		events.setEventTopic("Topic5");
		events.setCreatedBy("user5");
		events.setDataServiceId(Integer.valueOf(5));
		events.setExceptionServiceId(Integer.valueOf(5));
		events=eventRepository.save(events);
		assertNotNull(events.getExceptionServiceId());
	}

}
