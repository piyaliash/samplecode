
package com.ubs.wmap.eisl.initializationservice.service;

import com.ubs.wmap.eisl.housekeeping.TokenService;
import com.ubs.wmap.eisl.housekeeping.component.exceptions.TokenExpireException;
import com.ubs.wmap.eisl.housekeeping.component.exceptions.TokenUnwrapException;
import com.ubs.wmap.eisl.initializationservice.exceptions.BadRequestException;
import com.ubs.wmap.eisl.initializationservice.exceptions.InvalidEislTokenException;
import com.ubs.wmap.eisl.initializationservice.models.Payload;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.Map;

@Service
@Slf4j
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class InitializationServiceImpl implements InitializationService {


    private final RestTemplate restTemplate;

    private final TokenService tokenService;

    @Value("${app.custom.token_attribute_name}")
    private String eislObjectKey;

    @Value("${app.custom.eisl_eislObject_userName}")
    private String userName;

    @Value("${app.custom.eisl_eislObject_serViceId}")
    private String serviceId;

    @Value("${app.message.CONNECTION_ERROR}")
    private String CONNECTION_ERROR;

    public Map<String,Object> getEislClaims(String eisToken) throws InvalidEislTokenException {
        Map<String, Object> eislClaims = null;
        try{
            eislClaims = tokenService.init(eisToken);
        } catch (TokenExpireException | TokenUnwrapException ex) {
            log.error("Invalid Token {} ",ex.getMessage());
            throw new InvalidEislTokenException("Invalid Token");
        }catch (RuntimeException rx) {
            log.error("{}", rx.getMessage());
            throw new InvalidEislTokenException("Internal server error occurred");
        }

        if(eislClaims.containsKey(eislObjectKey)) {
            return (Map<String, Object>) eislClaims.get(eislObjectKey);
        }

        return eislClaims;

    }

    public String generateEislToken(String userId, String serviceId, String role) throws InvalidEislTokenException {
        try {
            return tokenService.createEILSToken(userId, serviceId, role);
        } catch (Exception e) {
            log.error("Exception occured while generating Eisl Token {} ",e.getMessage());
            throw new InvalidEislTokenException(e.getMessage());
        }
    }

    @Override
    public void postRegistration(String basicToken, String eislToken, Payload payload, String registrationServiceEndpoint) throws BadRequestException {
        HttpHeaders headers = new HttpHeaders();
        headers.add("basicToken", basicToken);
        MultiValueMap<String, Object> request = new LinkedMultiValueMap<>();
        request.add("payload", payload);
        HttpEntity<Object> requestEntity = new HttpEntity<>(request, headers);
        try {
            UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(registrationServiceEndpoint).queryParam("eislToken", eislToken);
            restTemplate.postForObject(builder.toUriString(), requestEntity, String.class);
        }catch(Exception ex){
            log.error("Exception occured while creating Registration Information {} ",ex.getMessage());
            throw new BadRequestException(CONNECTION_ERROR);
        }
    }

    @Override
    public void putRegistration(String basicToken, String eislToken, String registrationServiceEndpoint) throws BadRequestException {
        HttpHeaders headers = new HttpHeaders();
        headers.add("basicToken", basicToken);
        MultiValueMap<String, Object> request = new LinkedMultiValueMap<>();
        HttpEntity<Object> requestEntity = new HttpEntity<>(request, headers);
        try {
            UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(registrationServiceEndpoint).queryParam("eislToken", eislToken);
            restTemplate.put(builder.toUriString(), String.class, requestEntity);
        }catch (Exception ex){
            log.error("Exception occured while updating Registration Information {} ",ex.getMessage());
            throw new BadRequestException(CONNECTION_ERROR);
        }
    }

    @Override
    public void deleteRegistration(String basicToken, String eislToken, String registrationServiceEndpoint) throws BadRequestException {
        HttpHeaders headers = new HttpHeaders();
        headers.add("basicToken", basicToken);
        HttpEntity<String> requestEntity = new HttpEntity<>(headers);
        try {
            UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(registrationServiceEndpoint).queryParam("eislToken", eislToken);
            restTemplate.delete(builder.toUriString(), requestEntity);
        }catch (Exception ex){
            log.error("Exception occured while deleting Registration Information {}",ex.getMessage());
            throw new BadRequestException(CONNECTION_ERROR);
        }
    }


}
