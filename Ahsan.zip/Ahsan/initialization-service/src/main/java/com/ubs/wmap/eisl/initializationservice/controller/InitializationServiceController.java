
package com.ubs.wmap.eisl.initializationservice.controller;

import com.ubs.wmap.eisl.initializationservice.exceptions.BadRequestException;
import com.ubs.wmap.eisl.initializationservice.exceptions.InitException;
import com.ubs.wmap.eisl.initializationservice.models.Payload;
import com.ubs.wmap.eisl.initializationservice.service.InitializationServiceImpl;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.NotBlank;
import java.util.HashMap;

import static org.apache.commons.lang3.StringUtils.isEmpty;


@RestController
@Slf4j
@RequestMapping(produces = "application/json")
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class InitializationServiceController {


    private final InitializationServiceImpl initializationService;

    @Value("${app.message.INTERNAL_SERVER_ERROR_MSG}")
    private String INTERNAL_SERVER_ERROR_MSG;

    @Value("${app.message.BASIC_TOKEN_EMPTY_MSG}")
    private String BASIC_TOKEN_EMPTY_MSG;

    @Value("${app.message.EISL_TOKEN_EMPTY_MSG}")
    private String EISL_TOKEN_EMPTY_MSG;

    @Value("${app.message.EISL_INVALID_TOKEN_MSG}")
    private String EISL_INVALID_TOKEN_MSG;

    @Value("${app.message.INVALID_REQUEST}")
    private String INVALID_REQUEST;

    @Value("${app.custom.token_attribute_name}")
    private String eislObjectKey;

    @Value("${service.registrationServiceEndpoint}")
    private String registrationServiceEndpoint;


    @PostMapping(value = "/initialize")
    public ResponseEntity<HashMap> postInitialization(@NotBlank @RequestHeader(name = "Authorization") final String authHeader,
                                                      @NotBlank @RequestParam("userId") final String userId,
                                                      @NotBlank @RequestParam("serviceId") final String serviceId,
                                                      @NotBlank @RequestParam("role") final String role,
                                                      @RequestBody Payload payload) throws BadRequestException, InitException {
        String basicToken = trimAuthorizationSchema(authHeader);

        if (isEmpty(userId) || isEmpty(serviceId) || isEmpty(role)) {
            log.error("Invalid Data For Authorization");
            throw new BadRequestException(INVALID_REQUEST);
        }

        String eislToken = initializationService.generateEislToken(userId, serviceId, role);
        try {
            initializationService.postRegistration(basicToken, eislToken, payload,registrationServiceEndpoint);
            return ResponseEntity.ok().body(new HashMap<String, Object>() {{
                put("eislToken", eislToken);
            }});
        } catch (Exception ex) {
            log.error("Exception Occurred: {}", ex.getMessage());
            throw new InitException(ex.getMessage());
        }

    }

    @PostMapping(value = "/reinitialize")
    public ResponseEntity<?> postInitialization(@NotBlank @RequestHeader(name = "Authorization") final String authHeader,
                                                @NotBlank @RequestParam("token") final String eislToken) throws BadRequestException, InitException {
        String basicToken = trimAuthorizationSchema(authHeader);

        if (isEmpty(eislToken)) {
            log.error("Token is Empty");
            throw new BadRequestException(INVALID_REQUEST);
        }

        try {
            String ValidatedEislToken = initializationService.generateEislToken(basicToken, eislToken, null);
            initializationService.putRegistration(basicToken, ValidatedEislToken,registrationServiceEndpoint);
            return ResponseEntity.ok().body(eislToken);
        } catch (Exception ex) {
            log.error("Exception Occurred: {}", ex.getMessage());
            throw new InitException(ex.getMessage());
        }

    }

    @DeleteMapping(value = "/initialize")
    public ResponseEntity<?> terminateInitilization(@NotBlank @RequestHeader(name = "Authorization") final String authHeader,
                                                    @NotBlank @RequestParam("token") final String eislToken) throws BadRequestException, InitException {
        String basicToken = trimAuthorizationSchema(authHeader);

        if (isEmpty(eislToken)) {
            throw new BadRequestException(INVALID_REQUEST);
        }

        try {
            if (initializationService.getEislClaims(eislToken).containsKey(eislObjectKey)) {
                initializationService.deleteRegistration(basicToken, eislToken,registrationServiceEndpoint);
                return ResponseEntity.ok().build();
            } else {
                return ResponseEntity.notFound().build();
            }

        } catch (Exception ex) {
            log.warn("Exception Occurred: {}", ex.getMessage());
            throw new InitException(ex.getMessage());
        }
    }

    private String trimAuthorizationSchema(String authorizationHeader) {
        return authorizationHeader.replaceAll("^Bearer ", "");
    }

}
