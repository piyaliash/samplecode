package com.ubs.wmap.eisl.initializationservice.exceptions;

public class BadRequestException extends Exception{
	
	private static final long serialVersionUID = -2154287827168582345L;

	public BadRequestException(String message) {
		super(message);
	}

}
