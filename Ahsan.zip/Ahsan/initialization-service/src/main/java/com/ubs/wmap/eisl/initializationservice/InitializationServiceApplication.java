package com.ubs.wmap.eisl.initializationservice;

import com.ubs.wmap.eisl.housekeeping.TokenServiceConfiguration;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Import;


@SpringBootApplication
@Import(TokenServiceConfiguration.class)
public class InitializationServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(InitializationServiceApplication.class, args);
	}

}
