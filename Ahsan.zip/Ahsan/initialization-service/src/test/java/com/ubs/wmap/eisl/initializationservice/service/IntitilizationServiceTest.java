package com.ubs.wmap.eisl.initializationservice.service;


import com.ubs.wmap.eisl.housekeeping.component.TokenServiceImpl;
import com.ubs.wmap.eisl.initializationservice.exceptions.BadRequestException;
import com.ubs.wmap.eisl.initializationservice.exceptions.InvalidEislTokenException;
import com.ubs.wmap.eisl.initializationservice.models.Payload;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

@SuppressWarnings("deprecation")
@Slf4j
@RunWith(MockitoJUnitRunner.class)
@ActiveProfiles("test")
public class IntitilizationServiceTest {

    @Mock
    RestTemplate restTemplate;

    @Mock
    TokenServiceImpl tokenService;

    @Mock
    UriComponentsBuilder uriComponentsBuilder;

    @InjectMocks
    InitializationServiceImpl initializationService;



    @Test
    public void postRegistrationTest() throws BadRequestException {
        String basicToken = "testBasic";
        Payload payload = new Payload();
        String eislToken = "TestEisl";
        String url="https://localhost:8080";
        HttpHeaders headers = new HttpHeaders();
        headers.add("basicToken", basicToken);
        MultiValueMap<String, Object> request = new LinkedMultiValueMap<>();
        request.add("payload", payload);
        HttpEntity<Object> requestEntity = new HttpEntity<>(request, headers);
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl("https://localhost:8080")
                .queryParam("eislToken", eislToken);
        //Mockito.when(restTemplate.postForObject(builder.toUriString(), requestEntity, String.class)).thenReturn(eislToken);
        initializationService.postRegistration(eislToken, basicToken, payload,url);
    }

    @Test
    public void deleteRegistration() throws BadRequestException {
        String basicToken = "testBasic";
        Payload payload = new Payload();
        String eislToken = "TestEisl";
        String url="https://localhost:8080";
        HttpHeaders headers = new HttpHeaders();
        headers.add("basicToken", basicToken);
        MultiValueMap<String, Object> request = new LinkedMultiValueMap<>();
        request.add("payload", payload);
        HttpEntity<Object> requestEntity = new HttpEntity<>(request, headers);
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl("https://localhost:8080")
                .queryParam("eislToken", eislToken);
        initializationService.deleteRegistration(basicToken, eislToken,url);
    }

    @Test
    public void putRegistration() {
        String basicToken = "testBasic";
        Payload payload = new Payload();
        String eislToken = "TestEisl";
        String url="https://localhost:8080";
        HttpHeaders headers = new HttpHeaders();
        headers.add("basicToken", basicToken);
        MultiValueMap<String, Object> request = new LinkedMultiValueMap<>();
        request.add("payload", payload);
        HttpEntity<Object> requestEntity = new HttpEntity<>(request, headers);
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl("https://localhost:8080")
                .queryParam("eislToken", eislToken);
        restTemplate.put(builder.toUriString(), String.class, requestEntity);
    }
}


