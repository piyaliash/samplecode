package com.ubs.wmap.eisl.dataserviceregistry.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ubs.wmap.eisl.dataserviceregistry.constant.DataReferenceConstant;
import com.ubs.wmap.eisl.dataserviceregistry.exception.DataReferenceException;
import com.ubs.wmap.eisl.dataserviceregistry.exception.DataReferenceNotFoundException;
import com.ubs.wmap.eisl.dataserviceregistry.exception.DataRegistryBadRequestException;
import com.ubs.wmap.eisl.dataserviceregistry.model.DataReference;
import com.ubs.wmap.eisl.dataserviceregistry.service.DataReferenceService;
import com.ubs.wmap.eisl.dataserviceregistry.vo.DataReferenceRequest;
import com.ubs.wmap.eisl.dataserviceregistry.vo.DataReferenceResponse;

/**
 * @author Gananath
 *
 */
@RestController
public class DataServiceRegistryController extends BaseController{

	private static final Logger LOG = LoggerFactory.getLogger(DataServiceRegistryController.class);
	@Autowired
	private DataReferenceService dataReferenceService;
	
	@GetMapping(DataReferenceConstant.DATA_REFERENCE_ENDPOINT)
	public ResponseEntity<DataReferenceResponse> getDataReferenceDetails(@RequestParam("eislToken") String token,
			@RequestParam("dataServiceId") String dataServiceId)
			throws DataReferenceException, DataRegistryBadRequestException {
		LOG.debug("Controller Enetr: Entering getDataReferenceDetails");
		LOG.debug("token:{}",token);
		super.validateToken(token);
		LOG.debug("Token is Valid");
		DataReferenceResponse dataReference = null;
		try {
			DataReferenceRequest request = new DataReferenceRequest();
			request.setDataServiceId(Integer.parseInt(dataServiceId));
			dataReference = dataReferenceService.getDataReference(request);
			if (null == dataReference) {
				LOG.debug("Controller Exit: Exiting getDataReferenceDetails");
				throw new DataReferenceNotFoundException(DataReferenceConstant.DATA_REFERENCE_NOT_FOUND);
			}
		} catch (DataReferenceException ex) {
			LOG.debug("Controller Exit: Exiting getDataReferenceDetails");
			throw new DataReferenceException(DataReferenceConstant.INTERNAL_SERVER_ERROR_MSG);
		}
		LOG.debug("Controller Exit: Exiting getDataReferenceDetails");
		return ResponseEntity.ok(dataReference);
	}
	
	@PostMapping(value = DataReferenceConstant.DATA_REFERENCE_ENDPOINT, consumes = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE,
					MediaType.APPLICATION_XML_VALUE })
	public ResponseEntity<DataReferenceResponse> postDataReference(@RequestBody DataReference dataReference,
			@RequestParam("eislToken") String token) throws DataReferenceException, DataRegistryBadRequestException {
		LOG.debug("Controller Enter: Entering postdatareferencemethod");
		super.validateToken(token);
		DataReferenceResponse persistDataReference = new DataReferenceResponse();
		try {
			persistDataReference = dataReferenceService.persistDataReference(dataReference);
			if (null == persistDataReference) {
				LOG.debug("Controller Exit: Exiting postdatareferencemethod reason 1");
				throw new DataReferenceNotFoundException(DataReferenceConstant.DATA_REFERENCE_NOT_FOUND);
			}
			LOG.debug("Controller Exit: Exiting postDataReferencemethod on completion");
			return new ResponseEntity<DataReferenceResponse>(persistDataReference, HttpStatus.OK);
		} catch (DataReferenceException e) {
			LOG.debug("Controller Exit: Exiting postDataReferencemethod reason 2");
			throw new DataReferenceException(DataReferenceConstant.INTERNAL_SERVER_ERROR_MSG);
		}
	}
}
