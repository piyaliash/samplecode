package com.ubs.wmap.eisl.dataserviceregistry.exception;

public class DataReferenceException extends Exception {

	private static final long serialVersionUID = 3172706732973364925L;

	public DataReferenceException(String message) {
		super(message);
	}
	public DataReferenceException(Throwable cause) {
		super(cause);
	}
	public DataReferenceException(String message, Throwable cause) {
		super(message, cause);
	}
	@Override
	public String getMessage() {
		return super.getMessage();
	}
}
