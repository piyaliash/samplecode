package com.ubs.wmap.eisl.dataserviceregistry.service.impl;

import java.util.HashSet;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ubs.wmap.eisl.dataserviceregistry.exception.DataReferenceException;
import com.ubs.wmap.eisl.dataserviceregistry.model.DataFilterReference;
import com.ubs.wmap.eisl.dataserviceregistry.model.DataOutReference;
import com.ubs.wmap.eisl.dataserviceregistry.model.DataReference;
import com.ubs.wmap.eisl.dataserviceregistry.repository.DataRefefrenceRepository;
import com.ubs.wmap.eisl.dataserviceregistry.service.DataReferenceService;
import com.ubs.wmap.eisl.dataserviceregistry.vo.DataFilterResponse;
import com.ubs.wmap.eisl.dataserviceregistry.vo.DataOutReferenceResponse;
import com.ubs.wmap.eisl.dataserviceregistry.vo.DataReferenceRequest;
import com.ubs.wmap.eisl.dataserviceregistry.vo.DataReferenceResponse;

/**
 * @author Gananath
 *
 */

@Service
public class DataReferenceServiceImpl implements DataReferenceService {

	private static final Logger LOG = LoggerFactory.getLogger(DataReferenceServiceImpl.class);
	@Autowired
	private DataRefefrenceRepository dataRefefrenceRepository;
	
	/* (non-Javadoc)
	 * @see com.ubs.wmap.eisl.dataserviceregistry.service.DataReferenceService#getDataReference(com.ubs.wmap.eisl.dataserviceregistry.vo.DataReferenceRequest)
	 */
	@Override
	public DataReferenceResponse getDataReference(DataReferenceRequest dataReferenceRequest)
			throws DataReferenceException {
		LOG.debug("Service Enter:Inside getDataReference");
		LOG.debug("DataReferenceRequest : {}",dataReferenceRequest);
		DataReferenceResponse response = null;
		DataReference dataReference = dataRefefrenceRepository
				.findBydataServiceId(dataReferenceRequest.getDataServiceId());
		if (dataReference != null) {
			response = constructDataReference(dataReference);
			response.setDataOutReferences(constructDataOutReferences(dataReference.getDataOutReferences()));
		}
		LOG.debug("DataReferenceResponse : {}",response);
		LOG.debug("Service Exit:Exiting getDataReference");
		return response;
	}
	
	private Set<DataOutReferenceResponse> constructDataOutReferences(Set<DataOutReference> dataOutReferences) {
		Set<DataOutReferenceResponse> dataOutSet = new HashSet<>();
		for (DataOutReference dataOutReference : dataOutReferences) {
			DataOutReferenceResponse constructDataOutReference = constructDataOutReference(dataOutReference);
			dataOutSet.add(constructDataOutReference);
		}
		return dataOutSet;
	}

	private DataFilterResponse constructDataFilterResponse(DataFilterReference dataFilterReference) {
		DataFilterResponse dataFilterResponse = new DataFilterResponse();
		BeanUtils.copyProperties(dataFilterReference, dataFilterResponse);
		return dataFilterResponse;
	}
	
	private DataOutReferenceResponse constructDataOutReference(DataOutReference dataOutReference) {
		DataOutReferenceResponse dataOutReferenceResponse = new DataOutReferenceResponse();
		DataFilterReference dataFilterReference = dataOutReference.getDataFilterReference();
		DataFilterResponse constructDataFilterResponse = null;
		if(dataFilterReference != null) {
			constructDataFilterResponse = constructDataFilterResponse(dataFilterReference);
		}
		BeanUtils.copyProperties(dataOutReference, dataOutReferenceResponse);
		dataOutReferenceResponse.setDataFilterReference(constructDataFilterResponse);
		return dataOutReferenceResponse;
	}
	private DataReferenceResponse constructDataReference (DataReference dataReference){
		DataReferenceResponse dataReferenceResponse = new DataReferenceResponse();
		BeanUtils.copyProperties(dataReference, dataReferenceResponse);
		return dataReferenceResponse;
	}
	
	@Override
	public DataReferenceResponse  persistDataReference(DataReference dataReference) {
		dataReference= dataRefefrenceRepository.save(dataReference);
		return constructDataReference(dataReference);
	}
}
