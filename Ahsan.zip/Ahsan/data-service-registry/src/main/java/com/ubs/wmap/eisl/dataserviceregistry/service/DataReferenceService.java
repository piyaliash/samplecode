package com.ubs.wmap.eisl.dataserviceregistry.service;

import com.ubs.wmap.eisl.dataserviceregistry.exception.DataReferenceException;
import com.ubs.wmap.eisl.dataserviceregistry.model.DataReference;
import com.ubs.wmap.eisl.dataserviceregistry.vo.DataReferenceRequest;
import com.ubs.wmap.eisl.dataserviceregistry.vo.DataReferenceResponse;

/**
 * @author Gananath
 *
 */
public interface DataReferenceService {

	/**
	 * @param dataReferenceRequest
	 * @return DataReferenceResponse
	 * @throws DataReferenceException
	 */
	public DataReferenceResponse getDataReference(DataReferenceRequest dataReferenceRequest)
			throws DataReferenceException;
	
	
	/**
	 * @param dataReferencerequest
	 * @return DataReference
	 * @throws DataReferenceException
	 */
	public DataReferenceResponse saveDataReference(DataReferenceRequest dataReferencerequest) 
			throws DataReferenceException;
}
