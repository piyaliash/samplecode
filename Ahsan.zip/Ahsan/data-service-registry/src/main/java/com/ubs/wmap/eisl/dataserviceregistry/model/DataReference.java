package com.ubs.wmap.eisl.dataserviceregistry.model;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "DATA_REFERENCE")
public class DataReference implements Serializable{

	private static final long serialVersionUID = 8682370259634234471L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "Data_reference_id")
	private Integer dataReferenceId;
	
	@Column(name = "Data_service_id")
	private Integer dataServiceId;
	
	@Column(name = "Data_in_id")
	private String dataInTopic;
	
	@Column(name = "Data_out_reference")
	private String dataOutReference;
	
	@OneToMany(mappedBy="dataOutReference")
	private Set<DataOutReference> dataOutReferences;
	
	public Integer getDataReferenceId() {
		return dataReferenceId;
	}

	public void setDataReferenceId(Integer dataReferenceId) {
		this.dataReferenceId = dataReferenceId;
	}

	public Integer getDataServiceId() {
		return dataServiceId;
	}

	public void setDataServiceId(Integer dataServiceId) {
		this.dataServiceId = dataServiceId;
	}

	public String getDataInTopi() {
		return dataInTopic;
	}

	public void setDataInTopi(String dataInTopi) {
		this.dataInTopic = dataInTopi;
	}

	public String getDataOutReference() {
		return dataOutReference;
	}

	public void setDataOutReference(String dataOutReference) {
		this.dataOutReference = dataOutReference;
	}

	public Set<DataOutReference> getDataOutReferences() {
		return dataOutReferences;
	}

	public void setDataOutReferences(Set<DataOutReference> dataOutReferences) {
		this.dataOutReferences = dataOutReferences;
	}
	
}
