package com.ubs.wmap.eisl.dataserviceregistry.vo;

import java.io.Serializable;

import lombok.Data;

@Data
public class DataFilterResponse implements Serializable{

	private static final long serialVersionUID = 228694173931964139L;
	
	private Integer filterRefernceId;
	private String name;
	private String options;
	
}
