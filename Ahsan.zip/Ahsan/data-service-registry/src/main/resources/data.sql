insert into DATA_REFERENCE (Data_reference_id, Data_service_id, Data_in_id, Data_out_reference)
values (1, 1, 'topictest','outreference-test');

insert into DATA_OUT_REFERENCE (Data_out_reference_id, Data_reference_id, Protocol_name, Data_type, Topic_name)
values (1, 1, 'protocolTest1','rest', 'topicTest3');
insert into DATA_OUT_REFERENCE (Data_out_reference_id, Data_reference_id, Protocol_name, Data_type, Topic_name)
values (2, 1, 'protocolTest2','file', 'topicTest4');

insert into DATA_FILTER_REFERENCE (Filter_reference_id, Data_out_reference_id, Filter_Name, Filter_Options)
values (1, 1, 'filtertest1','filteroption1');