/*
package com.ubs.wmap.eisl.ms.exceptionreg.test.repository;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.test.context.junit4.SpringRunner;

import com.ubs.wmap.eisl.ms.exceptionreg.domain.ExceptionReference;
import com.ubs.wmap.eisl.ms.exceptionreg.repository.ExceptionRepository;

@RunWith(SpringRunner.class)
@DataJpaTest
@EnableAutoConfiguration
@ComponentScan(basePackages = { "com.ubs.wmap.eisl.ms.exceptionreg" })
public class ExceptionRepositoryTest {

	@Autowired
	private ExceptionRepository eventRepository;

	@Test
	public void testfindByServiceIdWithData() throws Exception {
		ExceptionReference values = eventRepository.findByExceptionServiceId(new Integer(1));
		assertNotNull(values);
	}
	
	
	@Test
	public void testfindByServiceIdWithOutData() throws Exception {
		ExceptionReference values = eventRepository.findByExceptionServiceId(new Integer(2));
		assertNull(values);
	}

}
*/
