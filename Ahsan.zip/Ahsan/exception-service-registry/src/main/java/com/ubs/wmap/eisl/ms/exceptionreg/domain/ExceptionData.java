package com.ubs.wmap.eisl.ms.exceptionreg.domain;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "EXCEPTION_DATA")
public class ExceptionData implements Serializable {

	private static final long serialVersionUID = -2960973719692214842L;
	
	@Id
	@GeneratedValue
	@Column(name = "EXCEPTION_DATA_ID")
	private Long exceptionDataId;

	@Lob
	@Column(name = "STACK_TRACE")
	private String stackTrace;

	@Column(name = "META_DATA")
	private String metadata;

	@Column(name = "CREATED_BY")
	private String createdBy;

	@Column(name = "LAST_UPDATED_BY")
	private String lastUpdatedBy;

	@Column(name = "CREATION_DATE")
	private Timestamp createdDate;

	@Column(name = "LAST_UPDATED_DATE")
	private Timestamp lastUpdatedDate;
	


	public ExceptionReference getExceptionReference() {
		return exceptionReference;
	}

	public void setExceptionReference(ExceptionReference exceptionReference) {
		this.exceptionReference = exceptionReference;
	}

	@OneToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "EXCEPTION_REF_ID", nullable = false)
	private ExceptionReference exceptionReference;

	public Long getExceptionDataId() {
		return exceptionDataId;
	}

	public void setExceptionDataId(Long exceptionDataId) {
		this.exceptionDataId = exceptionDataId;
	}

	public String getStackTrace() {
		return stackTrace;
	}

	public void setStackTrace(String stackTrace) {
		this.stackTrace = stackTrace;
	}

	public String getMetadata() {
		return metadata;
	}

	public void setMetadata(String metadata) {
		this.metadata = metadata;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public Timestamp getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Timestamp lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

}
