package com.ubs.wmap.eisl.ms.exceptionreg.controller;

import static com.ubs.wmap.eisl.ms.exceptionreg.constants.ExceptionRegConstants.EXCEPTIONREG_INVALID_TOKEN_MSG;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.ubs.wmap.eisl.housekeeping.TokenService;
import com.ubs.wmap.eisl.ms.exceptionreg.exception.ExceptionRegBadRequestException;

public abstract class BaseController {

	private static final Logger LOG = LoggerFactory.getLogger(ExceptionRegController.class);
	
	@Autowired
	private TokenService tokenService;
	
	public void validateToken(String eislToken) throws ExceptionRegBadRequestException{
		/** This is just for testing **/
		//eislToken=tokenService.init("userid","1", "Admin");
	
		LOG.info("eislToken:{}",eislToken);
	
		boolean isTokenValid = tokenService.isEISLTokenValid(eislToken);
		LOG.info("isTokenValid:{}", isTokenValid);
		if (!isTokenValid) {
			throw new ExceptionRegBadRequestException(EXCEPTIONREG_INVALID_TOKEN_MSG);
		}
		
	}
}
