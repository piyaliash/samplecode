package com.ubs.wmap.eisl.ms.exceptionreg.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ubs.wmap.eisl.ms.exceptionreg.domain.ExceptionReference;

@Repository
public interface  ExceptionRepository extends JpaRepository<ExceptionReference, Long> {
	
	ExceptionReference findByExceptionServiceId(@Param("exceptionServiceId") Integer exceptionServiceId);

}
