package com.ubs.wmap.eisl.ms.exceptionreg.constants;

public final class ExceptionRegConstants {
	
	private ExceptionRegConstants() {
	}

	public static final String EXCEPTION_NOT_FOUND_MSG="Exception Reference Not found for given ";
	
	public static final String INTERNAL_SERVER_ERROR_MSG="Internal server error occured ";
	
	public static final String EXCEPTIONREG_GET_ENDPOINT="/eisl/exception/v1/exceptions";
	
	public static final String EXCEPTIONREG_TOKEN_EMPTY_MSG="Token is empty";
	
	public static final String EXCEPTIONREG_INVALID_TOKEN_MSG="Invalid Token";
}
