package com.ubs.wmap.eisl.ms.exceptionreg.exception;

public class ExceptionRefException extends Exception  {
	
	private static final long serialVersionUID = 8089713711480335861L;

	
	public ExceptionRefException(String message) {
		super(message);
	}
	

}
