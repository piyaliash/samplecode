package com.ubs.wmap.eisl.ms.exceptionreg.services.sos;

import java.io.Serializable;
import java.sql.Timestamp;

public class ExceptionResponseSO implements Serializable {

	private static final long serialVersionUID = 7273465233846581680L;

	private Long exceptionRefId;
	private String category;
	private String exceptionTopic;
	private Integer exceptionServiceId;
	private String createdBy;
	private String lastUpdatedBy;
	private Timestamp createdDate;
	private Timestamp lastUpdatedDate;
	private ExceptionDataResponseSO exceptionDataResponseSO;

	public ExceptionDataResponseSO getExceptionDataResponseSO() {
		return exceptionDataResponseSO;
	}

	public void setExceptionDataResponseSO(ExceptionDataResponseSO exceptionDataResponseSO) {
		this.exceptionDataResponseSO = exceptionDataResponseSO;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	

	public Integer getExceptionServiceId() {
		return exceptionServiceId;
	}

	public void setExceptionServiceId(Integer exceptionServiceId) {
		this.exceptionServiceId = exceptionServiceId;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public Timestamp getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Timestamp lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	@Override
	public String toString() {
		return new StringBuilder("exceptionRefId:").append(exceptionRefId).append(",category:").append(category)
				.append(",exceptionTopic:").append(exceptionTopic).append(",exceptionServiceId:")
				.append(exceptionServiceId).append(",createdBy:").append(createdBy).append(",lastUpdatedBy:")
				.append(lastUpdatedBy).append(",createdDate:").append(createdDate).append(",lastUpdatedDate:")
				.append(lastUpdatedDate).toString();
	}

}
