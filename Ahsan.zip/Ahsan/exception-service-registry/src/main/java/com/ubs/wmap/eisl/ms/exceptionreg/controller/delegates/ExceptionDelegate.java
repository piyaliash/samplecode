package com.ubs.wmap.eisl.ms.exceptionreg.controller.delegates;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ubs.wmap.eisl.ms.exceptionreg.services.ExceptionService;
import com.ubs.wmap.eisl.ms.exceptionreg.services.sos.ExceptionRequestSO;
import com.ubs.wmap.eisl.ms.exceptionreg.services.sos.ExceptionResponseSO;
import com.ubs.wmap.eisl.ms.exceptionreg.exception.ExceptionRefException;

@Component
public class ExceptionDelegate {
	
	
	@Autowired
	private ExceptionService exceptionService;
	
	public ExceptionResponseSO getExceptionDetails(ExceptionRequestSO exceptionRequestSO) throws ExceptionRefException{
		 return exceptionService.getExceptionDetails(exceptionRequestSO);
	}

}
