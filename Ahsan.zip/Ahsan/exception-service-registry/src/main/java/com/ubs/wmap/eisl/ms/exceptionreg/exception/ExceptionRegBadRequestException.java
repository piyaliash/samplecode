package com.ubs.wmap.eisl.ms.exceptionreg.exception;

public class ExceptionRegBadRequestException extends Exception{
	
	private static final long serialVersionUID = -2154287827168582345L;

	public ExceptionRegBadRequestException(String message) {
		super(message);
	}

}
