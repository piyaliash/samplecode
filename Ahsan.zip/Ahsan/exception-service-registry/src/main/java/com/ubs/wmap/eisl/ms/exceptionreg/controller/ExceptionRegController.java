package com.ubs.wmap.eisl.ms.exceptionreg.controller;

import static com.ubs.wmap.eisl.ms.exceptionreg.constants.ExceptionRegConstants.EXCEPTIONREG_GET_ENDPOINT;
import static com.ubs.wmap.eisl.ms.exceptionreg.constants.ExceptionRegConstants.EXCEPTION_NOT_FOUND_MSG;
import static com.ubs.wmap.eisl.ms.exceptionreg.constants.ExceptionRegConstants.INTERNAL_SERVER_ERROR_MSG;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ubs.wmap.eisl.ms.exceptionreg.controller.delegates.ExceptionDelegate;
import com.ubs.wmap.eisl.ms.exceptionreg.services.sos.ExceptionRequestSO;
import com.ubs.wmap.eisl.ms.exceptionreg.services.sos.ExceptionResponseSO;
import com.ubs.wmap.eisl.ms.exceptionreg.exception.ExceptionRefException;
import com.ubs.wmap.eisl.ms.exceptionreg.exception.ExceptionRefNotFoundException;
import com.ubs.wmap.eisl.ms.exceptionreg.exception.ExceptionRegBadRequestException;

@RestController
public class ExceptionRegController extends BaseController {

	private static final Logger LOG = LoggerFactory.getLogger(ExceptionRegController.class);
	
	@Autowired
	private ExceptionDelegate exceptionDelegate;
	
	
	@RequestMapping(value = EXCEPTIONREG_GET_ENDPOINT, method = RequestMethod.GET)
	public ResponseEntity<ExceptionResponseSO> getEventDetails(@RequestParam("eislToken") String token,
			@RequestParam("exceptionServiceId") String exceptionServiceId )
			throws ExceptionRefException, ExceptionRegBadRequestException {
		ExceptionResponseSO exceptionResponseSO = null;
		
		LOG.debug("token:{}",token);
		
		super.validateToken(token);

		try {
			exceptionResponseSO = exceptionDelegate.getExceptionDetails(constructExceptionRequestSO(exceptionServiceId));
			if (exceptionResponseSO == null) {
				throw new ExceptionRefNotFoundException(EXCEPTION_NOT_FOUND_MSG + exceptionServiceId);
			}

		} catch (ExceptionRefException eventException) {
			LOG.error( eventException.getMessage(), eventException);
			throw new ExceptionRefException(INTERNAL_SERVER_ERROR_MSG);
		}

		return ResponseEntity.ok(exceptionResponseSO);
	}

	private ExceptionRequestSO constructExceptionRequestSO(String exceptionServiceId) {
		ExceptionRequestSO exceptionRequestSO = new ExceptionRequestSO();
		exceptionRequestSO.setExceptionServiceId(Integer.valueOf(exceptionServiceId));
		return exceptionRequestSO;
	}

}
