package com.ubs.wmap.eisl.registryaccessservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Import;

import com.ubs.wmap.eisl.housekeeping.TokenServiceConfiguration;

@SpringBootApplication
@Import(TokenServiceConfiguration.class)
public class RegistryAccessServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(RegistryAccessServiceApplication.class, args);
	}

}
