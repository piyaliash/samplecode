package com.ubs.wmap.eisl.registryaccessservice.vo;

import java.io.Serializable;
import java.util.Set;


public class RegistrationResponseVO implements Serializable {

	private static final long serialVersionUID = 2387423001946124578L;

	private String userName;
	
	private String userId;
	
	private String company;
	
	private String eislToken;
	
	private String serviceId;
	
	private String dataEntitlement;
	
	private RoleResponseVO role;
	
	private Set<ColumnReferenceResponseVO> columnReferences;
	
	private Set<RowReferenceResponseVO> rowReferences;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getEislToken() {
		return eislToken;
	}

	public void setEislToken(String eislToken) {
		this.eislToken = eislToken;
	}

	public String getServiceId() {
		return serviceId;
	}

	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}

	public String getDataEntitlement() {
		return dataEntitlement;
	}

	public void setDataEntitlement(String dataEntitlement) {
		this.dataEntitlement = dataEntitlement;
	}

	public RoleResponseVO getRole() {
		return role;
	}

	public void setRole(RoleResponseVO role) {
		this.role = role;
	}

	public Set<ColumnReferenceResponseVO> getColumnReferences() {
		return columnReferences;
	}

	public void setColumnReferences(Set<ColumnReferenceResponseVO> columnReferences) {
		this.columnReferences = columnReferences;
	}

	public Set<RowReferenceResponseVO> getRowReferences() {
		return rowReferences;
	}

	public void setRowReferences(Set<RowReferenceResponseVO> rowReferences) {
		this.rowReferences = rowReferences;
	}
}
