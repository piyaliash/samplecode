package com.ubs.wmap.eisl.registryaccessservice.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.ubs.wmap.eisl.registryaccessservice.service.RegistryReferenceService;
import com.ubs.wmap.eisl.registryaccessservice.vo.RegistrationResponseVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.RegistryAccessRequestVO;
import com.ubs.wmap.eisl.registryaccessservice.constant.RegistryAccessConstant;
import com.ubs.wmap.eisl.registryaccessservice.exception.RegistryAccessBadRequestException;
import com.ubs.wmap.eisl.registryaccessservice.exception.RegistryAccessNotFoundException;
import com.ubs.wmap.eisl.registryaccessservice.exception.RegistryReferenceException;
import com.ubs.wmap.eisl.registryaccessservice.model.Registration;


@RestController
public class RegistryAccessController extends BaseController{
	private static final Logger LOG = LoggerFactory.getLogger(RegistryAccessController.class);
	@Autowired
	private RegistryReferenceService registryReferenceService;
	
	@GetMapping(RegistryAccessConstant.REGISTRY_ACCESS_ENDPOINT)
	public ResponseEntity<RegistrationResponseVO> getDataReferenceDetails(@RequestParam("eislToken") String token,
			@RequestParam("serviceId") String serviceId)
			throws RegistryReferenceException, RegistryAccessBadRequestException {
		LOG.debug("Controller Enetr: Entering getDataReferenceDetails");
		super.validateToken(token);
		RegistrationResponseVO registrationResponse = null;
		try {
			RegistryAccessRequestVO request = new RegistryAccessRequestVO();
			request.setServiceId(serviceId);
			registrationResponse = registryReferenceService.getRegistryReference(request);
			if (null == registrationResponse) {
				LOG.debug("Controller Exit: Exiting getDataReferenceDetails");
				throw new RegistryAccessNotFoundException(RegistryAccessConstant.REGISTRY_ACCESS_NOT_FOUND);
			}
		} catch (RegistryReferenceException ex) {
			LOG.debug("Controller Exit: Exiting getDataReferenceDetails");
			throw new RegistryReferenceException(RegistryAccessConstant.INTERNAL_SERVER_ERROR_MSG);
		}
		LOG.debug("Controller Exit: Exiting getDataReferenceDetails");
		return ResponseEntity.ok(registrationResponse);
	}
	
	@PostMapping(RegistryAccessConstant.REGISTRY_ACCESS_ENDPOINT)
	public ResponseEntity<Registration> postRegistration(@RequestBody Registration registration,
			@RequestParam("eislToken") String token) throws RegistryAccessBadRequestException, RegistryReferenceException {
		super.validateToken(token);
		Registration persistRegistration = null;
		try {
			persistRegistration = registryReferenceService.persistRegistration(registration);
		} catch (RegistryReferenceException e) {
			throw new RegistryReferenceException(RegistryAccessConstant.INTERNAL_SERVER_ERROR_MSG);
		}
		if (persistRegistration != null) {
			return ResponseEntity.ok(persistRegistration);
		}
		return new ResponseEntity<Registration>(HttpStatus.NOT_FOUND);
	}
	
	@DeleteMapping(RegistryAccessConstant.REGISTRY_ACCESS_ENDPOINT)
	public void deleteRegistration(@RequestBody Registration registration, @RequestParam("eislToken") String token)
			throws RegistryAccessBadRequestException, RegistryReferenceException {
		super.validateToken(token);
		try {
			registryReferenceService.deleteRegistration(registration);
		} catch (RegistryReferenceException e) {
			throw new RegistryReferenceException(RegistryAccessConstant.INTERNAL_SERVER_ERROR_MSG);
		}
	}
}
