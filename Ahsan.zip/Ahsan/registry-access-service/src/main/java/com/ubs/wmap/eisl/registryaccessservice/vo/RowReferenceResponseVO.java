package com.ubs.wmap.eisl.registryaccessservice.vo;

import java.io.Serializable;

public class RowReferenceResponseVO implements Serializable {

	private static final long serialVersionUID = -5757508586634635377L;
	
	private String name;
	private String type;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	
	
}
