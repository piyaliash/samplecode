package com.ubs.wmap.eisl.registryaccessservice.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlTransient;

import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name = "ROWREFERENCE")
public class RowReference implements Serializable {

	private static final long serialVersionUID = -3825079572925086252L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "ROW_REFERENCE_ID")
	private Integer rowReferenceId;
	
	@Column(name = "NAME")
	private String name;
	
	@Column(name = "ROW_TYPE")
	private String type;
	
	@ManyToOne
	@JoinColumn(name="REGISTRATION_ID", nullable=false)
	
	private Registration registration;

	public Integer getRowReferenceId() {
		return rowReferenceId;
	}

	public void setRowReferenceId(Integer rowReferenceId) {
		this.rowReferenceId = rowReferenceId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Registration getRegistration() {
		return registration;
	}

	public void setRegistration(Registration registration) {
		this.registration = registration;
	}
}
