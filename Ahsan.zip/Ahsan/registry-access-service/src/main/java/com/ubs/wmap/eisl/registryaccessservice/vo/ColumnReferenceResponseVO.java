package com.ubs.wmap.eisl.registryaccessservice.vo;

import java.io.Serializable;
import java.util.Set;

public class ColumnReferenceResponseVO implements Serializable {

	private static final long serialVersionUID = 5996480652849234318L;
	private String Name;
	private String Type;
	public String getName() {
		return Name;
	}
	
	public void setName(String name) {
		Name = name;
	}

	public String getType() {
		return Type;
	}
	public void setType(String type) {
		Type = type;
	}	

}
