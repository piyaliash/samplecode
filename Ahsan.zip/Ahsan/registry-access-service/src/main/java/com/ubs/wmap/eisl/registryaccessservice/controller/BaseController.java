package com.ubs.wmap.eisl.registryaccessservice.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import com.ubs.wmap.eisl.housekeeping.TokenService;
import com.ubs.wmap.eisl.registryaccessservice.exception.RegistryAccessBadRequestException;

import io.jsonwebtoken.Claims;
public class BaseController {
	 private static final Logger LOG = LoggerFactory.getLogger(BaseController.class);
     
	 @Autowired
     private TokenService tokenService;
     public void validateToken(String eislToken) throws RegistryAccessBadRequestException {
         /** This is just for testing **/
      /*   eislToken = tokenService.init("userid", "1", "Admin");
         LOG.info("eislToken:{}", eislToken);*/
         boolean isTokenValid = tokenService.isEISLTokenValid(eislToken);
         LOG.info("isTokenValid:{}", isTokenValid);
		if (!isTokenValid) {
			throw new RegistryAccessBadRequestException("Invalid Token");
		}
     }

     public Claims getClaims(String eislToken) {
		return tokenService.unwrapEislToken(eislToken);
	}
	
	public String getServiceIdFromClaims(String eislToken) {
		String serviceId = null;
		Claims claims = this.getClaims(eislToken);
		if (claims != null && claims.get("serviceId") != null) {
			serviceId = (String) claims.get("serviceId");
		}
		return serviceId;
	}
}
