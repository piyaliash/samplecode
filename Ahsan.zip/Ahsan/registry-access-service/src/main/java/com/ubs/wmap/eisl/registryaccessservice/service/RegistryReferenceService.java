package com.ubs.wmap.eisl.registryaccessservice.service;

import com.ubs.wmap.eisl.registryaccessservice.exception.RegistryReferenceException;
import com.ubs.wmap.eisl.registryaccessservice.model.Registration;
import com.ubs.wmap.eisl.registryaccessservice.vo.RegistrationResponseVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.RegistryAccessRequestVO;

/**
 * @author Suman
 *
 */

public interface RegistryReferenceService {
	/**
	 * @param registryAccessRequestVO
	 * @return RegistrationResponseVO
	 * @throws RegistryReferenceException
	 */
	public RegistrationResponseVO getRegistryReference(RegistryAccessRequestVO registryAccessRequestVO)
			throws RegistryReferenceException;
	
	
	/**
	 * @param registration
	 * @return Registration
	 * @throws RegistryReferenceException
	 */
	public Registration persistRegistration(Registration registration) throws RegistryReferenceException;
	
	/**
	 * @param registration
	 * @return void
	 * @throws RegistryReferenceException
	 */	
	public void deleteRegistration(Registration registration) throws RegistryReferenceException;
}
