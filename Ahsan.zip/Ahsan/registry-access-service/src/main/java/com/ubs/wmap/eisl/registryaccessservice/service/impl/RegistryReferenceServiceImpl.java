package com.ubs.wmap.eisl.registryaccessservice.service.impl;

import java.util.HashSet;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ubs.wmap.eisl.registryaccessservice.exception.RegistryReferenceException;
import com.ubs.wmap.eisl.registryaccessservice.model.ColumnReference;
import com.ubs.wmap.eisl.registryaccessservice.model.Registration;
import com.ubs.wmap.eisl.registryaccessservice.model.Roles;
import com.ubs.wmap.eisl.registryaccessservice.model.RowReference;
import com.ubs.wmap.eisl.registryaccessservice.repository.RegistrationRepository;
import com.ubs.wmap.eisl.registryaccessservice.service.RegistryReferenceService;
import com.ubs.wmap.eisl.registryaccessservice.vo.ColumnReferenceResponseVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.RegistrationResponseVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.RegistryAccessRequestVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.RoleResponseVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.RowReferenceResponseVO;

@Service
public class RegistryReferenceServiceImpl implements RegistryReferenceService {

	private static final Logger LOG = LoggerFactory.getLogger(RegistryReferenceServiceImpl.class);
	@Autowired
	private RegistrationRepository registrationRepository;

	@Override
	public RegistrationResponseVO getRegistryReference(RegistryAccessRequestVO registryAccessRequestVO)
			throws RegistryReferenceException {

		LOG.debug("Service Enter:Inside getDataReference");
		LOG.debug("DataReferenceRequest : {}", registryAccessRequestVO);

		RegistrationResponseVO response = null;
		Registration registration = registrationRepository.findByServiceId(registryAccessRequestVO.getServiceId());
		if (registration != null) {
			response = constructDataReference(registration);
			if(registration.getColumnReferences()!=null)
			response.setColumnReferences(constructColumnReferences(registration.getColumnReferences()));
			if(registration.getRowReferences()!=null)
			response.setRowReferences(constructRowReferences(registration.getRowReferences()));
			if(registration.getRole()!=null)
			response.setRole(constructRoleReferences(registration.getRole()));
			
		}
		LOG.debug("DataReferenceResponse : {}", response);
		LOG.debug("Service Exit:Exiting getDataReference");
		return response;

	}
	
	private RoleResponseVO constructRoleReferences(Roles roles) {
		RoleResponseVO roleResponseVO = constructRole(roles);		
		return roleResponseVO;
	}
	
	private RoleResponseVO constructRole(Roles roles) {
		RoleResponseVO roleResponseVO = new RoleResponseVO();
		BeanUtils.copyProperties(roles, roleResponseVO);
		return roleResponseVO;
	}
	

	private Set<ColumnReferenceResponseVO> constructColumnReferences(Set<ColumnReference> columnReferences) {
		Set<ColumnReferenceResponseVO> columnRefSet = new HashSet<>();
		for (ColumnReference columnReference : columnReferences) {
			ColumnReferenceResponseVO constructColumnReference = constructColumnReference(columnReference);
			
			columnRefSet.add(constructColumnReference);
		}
		return columnRefSet;
	}
	
	
	private ColumnReferenceResponseVO constructColumnReference(ColumnReference columnReference) {
		ColumnReferenceResponseVO columnReferenceResponseVO = new ColumnReferenceResponseVO();
		BeanUtils.copyProperties(columnReference, columnReferenceResponseVO);
		return columnReferenceResponseVO;
	}
	
	private Set<RowReferenceResponseVO> constructRowReferences(Set<RowReference> rowReferences) {
		Set<RowReferenceResponseVO> rowRefSet = new HashSet<>();
		for (RowReference rowReference : rowReferences) {
			RowReferenceResponseVO constructRowReference = constructRowReference(rowReference);
			rowRefSet.add(constructRowReference);
		}
		return rowRefSet;
	}
	
	private RowReferenceResponseVO constructRowReference(RowReference rowReference) {
		RowReferenceResponseVO rowReferenceResponseVO = new RowReferenceResponseVO();
		BeanUtils.copyProperties(rowReference, rowReferenceResponseVO);
		return rowReferenceResponseVO;
	}	

	private RegistrationResponseVO constructDataReference(Registration registration) {
		RegistrationResponseVO registrationResponseVO = new RegistrationResponseVO();
		BeanUtils.copyProperties(registration, registrationResponseVO);
		return registrationResponseVO;
	}

	@Override
	public Registration persistRegistration(Registration registration) throws RegistryReferenceException {

		return registrationRepository.save(registration);
	}
	
	@Override
	public void deleteRegistration(Registration registration) throws RegistryReferenceException {
		
		registrationRepository.delete(registration);
	}

}
