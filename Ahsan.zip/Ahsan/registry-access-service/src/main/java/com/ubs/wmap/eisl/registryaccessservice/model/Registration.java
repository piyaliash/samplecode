package com.ubs.wmap.eisl.registryaccessservice.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "REGISTRATION")
public class Registration implements Serializable{

	private static final long serialVersionUID = 3770085916847755446L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "REGISTRATION_ID")
	private Long registrationId;
	
	@Column(name = "USER_NAME")
	private String userName;
	
	@Column(name = "USER_ID")
	private String userId;
	
	@Column(name = "COMPANY")
	private String company;
	
	@Column(name = "EISL_TOKEN")
	private String eislToken;
	
	@Column(name = "SERVICE_ID")
	private String serviceId;
	
	@Column(name = "DATA_ENTITLEMENT")
	private String dataEntitlement;
	
	
		  
	@OneToOne(mappedBy = "registration", cascade = CascadeType.ALL, fetch =
	  FetchType.LAZY, optional = false)	
		  
	private Roles Role;	
	
	@OneToMany(mappedBy="registration")
	
	private Set<ColumnReference> columnReferences;
	
	
	@OneToMany(mappedBy="registration")
	
	private Set<RowReference> rowReferences;
	
	@Column(name = "CREATED_BY")
	private String createdBy;
	
	@Column(name = "LAST_UPDATED_BY")
	private String lastUpdatedBy;
	
	@Column(name = "CREATION_DATE")
	private Timestamp createdDate;
	
	@Column(name = "LAST_UPDATED_DATE")
	private Timestamp lastUpdatedDate;
	
	public Long getRegistrationId() {
		return registrationId;
	}

	public void setRegistrationId(Long registrationId) {
		this.registrationId = registrationId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getEislToken() {
		return eislToken;
	}

	public void setEislToken(String eislToken) {
		this.eislToken = eislToken;
	}

	public String getServiceId() {
		return serviceId;
	}

	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}

	public String getDataEntitlement() {
		return dataEntitlement;
	}

	public void setDataEntitlement(String dataEntitlement) {
		this.dataEntitlement = dataEntitlement;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public Timestamp getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Timestamp lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public Roles getRole() {
		return Role;
	}

	public void setRole(Roles role) {
		Role = role;
	}

	public Set<ColumnReference> getColumnReferences() {
		return columnReferences;
	}

	public void setColumnReferences(Set<ColumnReference> columnReferences) {
		this.columnReferences = columnReferences;
	}

	public Set<RowReference> getRowReferences() {
		return rowReferences;
	}

	public void setRowReferences(Set<RowReference> rowReferences) {
		this.rowReferences = rowReferences;
	}
}
