package com.ubs.wmap.eisl.registryaccessservice.vo;

import java.io.Serializable;

import com.ubs.wmap.eisl.registryaccessservice.model.Registration;

public class RoleResponseVO implements Serializable {

	private static final long serialVersionUID = -1302500552053706652L;

	private String publish;
	
	private String consume;
	
	public String getPublish() {
		return publish;
	}

	public void setPublish(String publish) {
		this.publish = publish;
	}

	public String getConsume() {
		return consume;
	}

	public void setConsume(String consume) {
		this.consume = consume;
	}
}
