package com.ubs.wmap.eisl.registryaccessservice.vo;

import java.io.Serializable;

public class RegistryAccessRequestVO implements Serializable{

	private static final long serialVersionUID = -3373977109871002547L;
	
	private String eislToken;
	
	private String userId;
	
	private String serviceId;
	
	private String role;

	public String getEislToken() {
		return eislToken;
	}

	public void setEislToken(String eislToken) {
		this.eislToken = eislToken;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getServiceId() {
		return serviceId;
	}

	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}
}
