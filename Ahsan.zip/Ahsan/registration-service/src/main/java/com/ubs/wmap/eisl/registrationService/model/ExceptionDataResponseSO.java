package com.ubs.wmap.eisl.registrationService.model;

import lombok.Data;

import java.io.Serializable;
import java.sql.Timestamp;

@Data
public class ExceptionDataResponseSO implements Serializable{
	
	private static final long serialVersionUID = -8626286941250840467L;

	private Long exceptionDataId;
	private String stackTrace;
	private String createdBy;
	private String lastUpdatedBy;
	private Timestamp createdDate;
	private Timestamp lastUpdatedDate;


}
