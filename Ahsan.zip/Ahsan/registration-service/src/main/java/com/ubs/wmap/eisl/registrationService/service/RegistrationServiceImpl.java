package com.ubs.wmap.eisl.registrationService.service;

import static com.ubs.wmap.eisl.registrationService.constants.RegistrationConstants.DATA_END_POINT;
import static com.ubs.wmap.eisl.registrationService.constants.RegistrationConstants.EVENTS_END_POINT;
import static com.ubs.wmap.eisl.registrationService.constants.RegistrationConstants.EXCEPTIONS_END_POINT;
import static com.ubs.wmap.eisl.registrationService.constants.RegistrationConstants.REGISTRY_ACCESS_END_POINT;

import javax.validation.constraints.NotBlank;

//import com.ubs.wmap.eisl.housekeeping.TokenService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.ubs.wmap.eisl.housekeeping.TokenService;
import com.ubs.wmap.eisl.registrationService.exception.InvalidDataException;
import com.ubs.wmap.eisl.registrationService.model.DataReferenceResponse;
import com.ubs.wmap.eisl.registrationService.model.EventResponseSO;
import com.ubs.wmap.eisl.registrationService.model.ExceptionResponseSO;
import com.ubs.wmap.eisl.registrationService.model.PayloadSO;
import com.ubs.wmap.eisl.registrationService.model.RegistrationSO;
import com.ubs.wmap.eisl.registrationService.model.ResponseSO;

import io.jsonwebtoken.Claims;

@Service
public class RegistrationServiceImpl implements RegistrationService {

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private TokenService tokenService;

	@Override
	public boolean validateToken(String basicToken, String eislToken) {
		boolean isValid = tokenService.isEISLTokenValid(eislToken);
		return isValid;

	}

	public ResponseEntity<RegistrationSO> getRegistryResponse(String baseUrl, String firstParam, String stringParam) {

//        final String url = String.format("/eisl/%s", baseUrl);

		final String url = baseUrl;
//
//		HttpHeaders headers = new HttpHeaders();
//		headers.add("basicToken", firstParam);

//    	 MultiValueMap<String, PayloadDTO> map= new LinkedMultiValueMap<String, PayloadDTO>();
//         map.add("payload", payload);
		Claims claims = tokenService.unwrapEislToken(stringParam);

		//HttpEntity<MultiValueMap<String, PayloadSO>> requestEntity = new HttpEntity<>(headers);

		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url).queryParam("eislToken", stringParam)
				.queryParam("eislToken", claims.get("serviceId"));

		final ResponseEntity<RegistrationSO> responseDto = restTemplate.exchange(builder.toUriString(), HttpMethod.GET,
				null, new ParameterizedTypeReference<RegistrationSO>() {
				});
		return responseDto;
	}

	public ResponseEntity<RegistrationSO> postRegistryResponse(String baseUrl, RegistrationSO registrationData) {

//        final String url = String.format("/eisl/%s", baseUrl);
		final String url = baseUrl;

		MultiValueMap<String, RegistrationSO> map = new LinkedMultiValueMap<String, RegistrationSO>();
		map.add("payload", registrationData);

		HttpEntity<MultiValueMap<String, RegistrationSO>> requestEntity = new HttpEntity<>(map);

		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url).queryParam("registrationData",
				registrationData);

		final ResponseEntity<RegistrationSO> responseDto = restTemplate.exchange(builder.toUriString(), HttpMethod.POST,
				requestEntity, new ParameterizedTypeReference<RegistrationSO>() {
				});
		return responseDto;
	}

	public ResponseEntity<RegistrationSO> putRegistryResponse(String baseUrl, RegistrationSO registrationData) {

//        final String url = String.format("/eisl/%s", baseUrl);

		final String url = baseUrl;

		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url).queryParam("registrationData",
				registrationData);

		final ResponseEntity<RegistrationSO> responseDto = restTemplate.exchange(builder.toUriString(), HttpMethod.PUT,
				null, new ParameterizedTypeReference<RegistrationSO>() {
				});
		return responseDto;
	}

	public ResponseEntity<EventResponseSO> getEventsResponse(String baseUrl, String firstParam, String stringParam) {

//        final String url = String.format("/eisl/%s", baseUrl);
		final String url = baseUrl;

//		HttpHeaders headers = new HttpHeaders();
//		headers.add("basicToken", firstParam);
//
//		HttpEntity<EventResponseSO> requestEntity = new HttpEntity<>(headers);

		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url).queryParam("eislToken", stringParam);

		final ResponseEntity<EventResponseSO> responseDto = restTemplate.exchange(builder.toUriString(), HttpMethod.GET,
				null, new ParameterizedTypeReference<EventResponseSO>() {
				});
		return responseDto;
	}

	public ResponseEntity<DataReferenceResponse> getDataResponse(String baseUrl, String firstParam, String stringParam,
			String basicToken) {

//        final String url = String.format("/eisl/%s", baseUrl);

		final String url = baseUrl;

//		HttpHeaders headers = new HttpHeaders();
//		headers.add("basicToken", basicToken);
//
//		HttpEntity<DataSO> requestEntity = new HttpEntity<>(headers);

		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url).queryParam("eislToken", firstParam)
				.queryParam("dataServiceId", stringParam);

		final ResponseEntity<DataReferenceResponse> responseDto = restTemplate.exchange(builder.toUriString(), HttpMethod.GET,
				null, new ParameterizedTypeReference<DataReferenceResponse>() {
				});
		return responseDto;
	}

	public ResponseEntity<ExceptionResponseSO> getExceptionsResponse(String baseUrl, String firstParam,
			String exceptionServiceId, String basicToken) {

//		final String url = String.format("/eisl/%s", baseUrl);
		final String url = baseUrl;
//		HttpHeaders headers = new HttpHeaders();
//		headers.add("basicToken", basicToken);
//
//		HttpEntity<ExceptionResponseSO> requestEntity = new HttpEntity<>(headers);
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url).queryParam("eislToken", firstParam)
				.queryParam("exceptionServiceId", exceptionServiceId);
		final ResponseEntity<ExceptionResponseSO> responseDto = restTemplate.exchange(builder.toUriString(),
				HttpMethod.GET, null, new ParameterizedTypeReference<ExceptionResponseSO>() {
				});
		return responseDto;

	}

	@Override
	public ResponseSO deleteRegistration(String baseUrl, String basicToken, String eislToken) {
		final String url = String.format("/eisl/%s", baseUrl);

		HttpHeaders headers = new HttpHeaders();
		headers.add("basicToken", basicToken);

		HttpEntity<ResponseSO> requestEntity = new HttpEntity<>(headers);

		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url).queryParam("basicToken", basicToken)
				.queryParam("eislToken", eislToken);

		final ResponseEntity<ResponseSO> responseDto = restTemplate.exchange(builder.toUriString(), HttpMethod.DELETE,
				requestEntity, new ParameterizedTypeReference<ResponseSO>() {
				});
		return responseDto.getBody();
	}

	@Override
	public ResponseSO postRegistration(@NotBlank String basicToken, @NotBlank String eislToken, PayloadSO payload)
			throws InvalidDataException {

		ResponseSO responseDTO = new ResponseSO();
		ResponseEntity<RegistrationSO> getResponse = getRegistryResponse(EVENTS_END_POINT, basicToken, eislToken);
		if (getResponse.getStatusCode() == HttpStatus.OK) {
			responseDTO.setRegistrationDto(getResponse.getBody());
			return responseDTO;
		}
		ResponseEntity<EventResponseSO> eventsResponse = getEventsResponse(EVENTS_END_POINT, basicToken, eislToken);
		ResponseEntity<DataReferenceResponse> dataResponse = getDataResponse(DATA_END_POINT, eislToken,
				eventsResponse.getBody().getDataServiceId().toString(), basicToken);
		ResponseEntity<ExceptionResponseSO> exceptionResponse = getExceptionsResponse(EXCEPTIONS_END_POINT, eislToken,
				eventsResponse.getBody().getExceptionServiceId().toString(), basicToken);
		if (eventsResponse.getStatusCode() == HttpStatus.BAD_REQUEST
				|| dataResponse.getStatusCode() == HttpStatus.BAD_REQUEST
				|| exceptionResponse.getStatusCode() == HttpStatus.BAD_REQUEST) {
			throw new InvalidDataException();
		}
		RegistrationSO builtRegistry = buildRegistration(payload, eislToken);
		ResponseEntity<RegistrationSO> postResponse = postRegistryResponse(REGISTRY_ACCESS_END_POINT, builtRegistry);
		responseDTO.setRegistrationDto(postResponse.getBody());
		return null;
	}

	@Override
	public ResponseSO putRegistration(@NotBlank String basicToken, @NotBlank String eislToken, PayloadSO payload)
			throws InvalidDataException {

		ResponseSO responseDTO = new ResponseSO();
		ResponseEntity<RegistrationSO> getResponse = getRegistryResponse(EVENTS_END_POINT, basicToken, eislToken);
		if (getResponse.getStatusCode() == HttpStatus.OK) {
			responseDTO.setRegistrationDto(getResponse.getBody());
			return responseDTO;
		}
		ResponseEntity<EventResponseSO> eventsResponse = getEventsResponse(EVENTS_END_POINT, basicToken, eislToken);
		ResponseEntity<DataReferenceResponse> dataResponse = getDataResponse(DATA_END_POINT, eislToken,
				eventsResponse.getBody().getDataServiceId().toString(), basicToken);
		ResponseEntity<ExceptionResponseSO> exceptionResponse = getExceptionsResponse(EXCEPTIONS_END_POINT, eislToken,
				eventsResponse.getBody().getExceptionServiceId().toString(), basicToken);
		if (eventsResponse.getStatusCode() == HttpStatus.BAD_REQUEST
				|| dataResponse.getStatusCode() == HttpStatus.BAD_REQUEST
				|| exceptionResponse.getStatusCode() == HttpStatus.BAD_REQUEST) {
			throw new InvalidDataException();
		}
		RegistrationSO builtRegistry = buildRegistration(payload, eislToken);
		ResponseEntity<RegistrationSO> putResponse = putRegistryResponse(REGISTRY_ACCESS_END_POINT, builtRegistry);
		responseDTO.setRegistrationDto(putResponse.getBody());
		return null;
	}

	public RegistrationSO buildRegistration(PayloadSO payload, String eislToken) {
		// add library and extract token here
		Claims claims = tokenService.unwrapEislToken(eislToken);
		RegistrationSO builtRegistration = RegistrationSO.builder().userName(payload.getUserName())
				.company(payload.getCompany()).columnRef(claims.get("columnRef").toString()).eislToken(eislToken)
				.serviceId(claims.get("serviceId").toString()).userId(claims.get("columnRef").toString())
				.rowRef(claims.get("rowRef").toString()).build();
		builtRegistration.setDataEntitlement("Not Clear about the DATA yet");

		return builtRegistration;
	}

	@Override
	public ResponseSO getRegistration(@NotBlank String basicToken, @NotBlank String eislToken, PayloadSO payload)
			throws InvalidDataException {

		ResponseSO responseDTO = new ResponseSO();
		ResponseEntity<RegistrationSO> getResponse = getRegistryResponse(REGISTRY_ACCESS_END_POINT, basicToken, eislToken);
		if (getResponse.getStatusCode() == HttpStatus.OK) {
			responseDTO.setRegistrationDto(getResponse.getBody());
			return responseDTO;
		}
		ResponseEntity<EventResponseSO> eventsResponse = getEventsResponse(EVENTS_END_POINT, basicToken, eislToken);
		ResponseEntity<DataReferenceResponse> dataResponse = getDataResponse(DATA_END_POINT, eislToken,
				eventsResponse.getBody().getDataServiceId().toString(), basicToken);
//		ResponseEntity<DataReferenceResponse> dataResponse = getDataResponse(DATA_END_POINT, "eyJhbGciOiJSUzI1NiJ9.eyJlbnRpdGxlbWVudHMiOnsiUkVBRE9OTFlfUEVSTUlTU0lPTlMiOjMyMzMxMiwiRlVMTF9BQ0NFU1NfUEVSTUlTU0lPTlMiOjk4NzY1NCwiRURJVF9QRVJNSVNTSU9OUyI6MTQ1MzIyLCJBRE1JTl9QRVJNSVNTSU9OUyI6NjM2MzY2fSwicm9sZSI6ImFkbWluIiwiY29ycmVsYXRpb25JZCI6IjU3YzJkYjQyLTk1ZGMtNDRkZi1hZjUxLTRmNWY2OTY4NGIzNyIsInVzZXJOYW1lIjoiVXRrYXJzaCIsInNlcnZpY2VJZCI6ImdldF9hY2MiLCJleHAiOjE1NTc2MzMzODUsImp0aSI6ImQ4OTZlMzdkLTAyYzAtNDNkOC1hNTQ0LTBhODY1ZDc4MTk5YSJ9.PAS3x8devMLILDVAyK4EIpcmCMTAWCtuLnczUjb0zF0r_cTCPHs1cd-P-NaZ936SfdZX6u2qvvI7yDiOTQbhMawV5L8sXgZEeo0a_n6c9H68cvLfrI1Io-8sBUjdzmKAjHcfdEjFm7Ayo5CLGghYSB9Qbq28mVQlAlE_aQD5PJvoHOUqtFFqRaEHmspMUSp_RAyZkE4MelnaBM-_8eLtNI_QdHXtMXIkSm3vCa7sSI4VoEj9IvfCDhnvnO0Qb8acHj86P1zbdVxup9dpe0kETwIwndenamHH5HWXp1h1gvWnHuX45bcYxdS8Ui4vhfD7mnU3V0Hv0cAKEfNw1RLKbzNfcEUrmjMIIPewyOsBru5HPz9K9H3JhlaUGlIW7YOgrwYJTKSk57Ap9grehVdt6zG9NJlP25yJcz_f8JMUV-s5H8xZEiq8LvYWU45RKZ7UQebD8TRMfy45amSe2hN0M_iYvveF4Sy72B_tCX6Mw0lNfTfmAmCsSwWoLJBxkwxhNnTKMtDWc6QbmlaqXae0Udj0lC3osQ4kdPaZyxVTVVwTTqNeXN4CRPMt-GiUt2g7bhMo2dXNttlxbTaG7RqtKT2t1pgNWto5Xd_-GV3XTcql-SGz_Vglyd_7oi_tquODEKSe5-k3nGyLkpg2Uv5ICLS1DIt8U0XYfZdZ4XIg9Vs",
//				"1", basicToken);
		ResponseEntity<ExceptionResponseSO> exceptionResponse = getExceptionsResponse(EXCEPTIONS_END_POINT, eislToken,
				eventsResponse.getBody().getExceptionServiceId().toString(), basicToken);
//		String id = String.valueOf(dataResponse.getBody().getDataServiceId());
//		ResponseEntity<ExceptionResponseSO> exceptionResponse = getExceptionsResponse(EXCEPTIONS_END_POINT, "eyJhbGciOiJSUzI1NiJ9.eyJlbnRpdGxlbWVudHMiOnsiUkVBRE9OTFlfUEVSTUlTU0lPTlMiOjMyMzMxMiwiRlVMTF9BQ0NFU1NfUEVSTUlTU0lPTlMiOjk4NzY1NCwiRURJVF9QRVJNSVNTSU9OUyI6MTQ1MzIyLCJBRE1JTl9QRVJNSVNTSU9OUyI6NjM2MzY2fSwicm9sZSI6ImFkbWluIiwiY29ycmVsYXRpb25JZCI6IjU3YzJkYjQyLTk1ZGMtNDRkZi1hZjUxLTRmNWY2OTY4NGIzNyIsInVzZXJOYW1lIjoiVXRrYXJzaCIsInNlcnZpY2VJZCI6ImdldF9hY2MiLCJleHAiOjE1NTc2MzMzODUsImp0aSI6ImQ4OTZlMzdkLTAyYzAtNDNkOC1hNTQ0LTBhODY1ZDc4MTk5YSJ9.PAS3x8devMLILDVAyK4EIpcmCMTAWCtuLnczUjb0zF0r_cTCPHs1cd-P-NaZ936SfdZX6u2qvvI7yDiOTQbhMawV5L8sXgZEeo0a_n6c9H68cvLfrI1Io-8sBUjdzmKAjHcfdEjFm7Ayo5CLGghYSB9Qbq28mVQlAlE_aQD5PJvoHOUqtFFqRaEHmspMUSp_RAyZkE4MelnaBM-_8eLtNI_QdHXtMXIkSm3vCa7sSI4VoEj9IvfCDhnvnO0Qb8acHj86P1zbdVxup9dpe0kETwIwndenamHH5HWXp1h1gvWnHuX45bcYxdS8Ui4vhfD7mnU3V0Hv0cAKEfNw1RLKbzNfcEUrmjMIIPewyOsBru5HPz9K9H3JhlaUGlIW7YOgrwYJTKSk57Ap9grehVdt6zG9NJlP25yJcz_f8JMUV-s5H8xZEiq8LvYWU45RKZ7UQebD8TRMfy45amSe2hN0M_iYvveF4Sy72B_tCX6Mw0lNfTfmAmCsSwWoLJBxkwxhNnTKMtDWc6QbmlaqXae0Udj0lC3osQ4kdPaZyxVTVVwTTqNeXN4CRPMt-GiUt2g7bhMo2dXNttlxbTaG7RqtKT2t1pgNWto5Xd_-GV3XTcql-SGz_Vglyd_7oi_tquODEKSe5-k3nGyLkpg2Uv5ICLS1DIt8U0XYfZdZ4XIg9Vs",
//				id, basicToken);
		if (eventsResponse.getStatusCode() == HttpStatus.BAD_REQUEST
				|| dataResponse.getStatusCode() == HttpStatus.BAD_REQUEST
				|| exceptionResponse.getStatusCode() == HttpStatus.BAD_REQUEST) {
			throw new InvalidDataException();
		}
		responseDTO.setEventDto(eventsResponse.getBody());
		responseDTO.setDataDto(dataResponse.getBody());
		
		responseDTO.setExceptionDto(exceptionResponse.getBody());
		return responseDTO;
	}
}
