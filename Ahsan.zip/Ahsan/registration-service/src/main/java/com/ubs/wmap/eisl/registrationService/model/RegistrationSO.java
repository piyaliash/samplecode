package com.ubs.wmap.eisl.registrationService.model;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class RegistrationSO {
	private String userName;
	private String userId;
	private String company;
	private String eislToken;
	private String serviceId;
	private String columnRef;
	private String rowRef;
	private String dataEntitlement;
}
