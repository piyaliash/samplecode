package com.ubs.wmap.eisl.registrationService.model;

import lombok.Data;

@Data
public class PayloadSO {
    private String userName;
    private String company;
}
