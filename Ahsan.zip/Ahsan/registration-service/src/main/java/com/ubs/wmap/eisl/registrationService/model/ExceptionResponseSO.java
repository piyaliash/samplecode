package com.ubs.wmap.eisl.registrationService.model;

import lombok.Data;

import java.io.Serializable;
import java.sql.Timestamp;

@Data
public class ExceptionResponseSO implements Serializable {

	private static final long serialVersionUID = 7273465233846581680L;

	private Long exceptionRefId;
	private String category;
	private String exceptionTopic;
	private Integer exceptionServiceId;
	private String createdBy;
	private String lastUpdatedBy;
	private Timestamp createdDate;
	private Timestamp lastUpdatedDate;
	private ExceptionDataResponseSO exceptionDataResponseSO;



}
