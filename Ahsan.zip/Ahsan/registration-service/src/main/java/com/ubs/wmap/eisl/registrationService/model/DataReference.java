package com.ubs.wmap.eisl.registrationService.model;

import lombok.Data;

import java.io.Serializable;
import java.util.Set;

@Data
public class DataReference implements Serializable{

	private static final long serialVersionUID = 8682370259634234471L;
	

	private Integer dataReferenceId;
	

	private Integer dataServiceId;
	

	private String dataInTopic;
	

	private String dataOutReference;
	

	private Set<DataOutReference> dataOutReferences;

	
}
