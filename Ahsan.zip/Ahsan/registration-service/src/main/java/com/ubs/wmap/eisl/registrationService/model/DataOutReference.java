package com.ubs.wmap.eisl.registrationService.model;

import lombok.Data;

import java.io.Serializable;

@Data

public class DataOutReference implements Serializable{

	
	private static final long serialVersionUID = 6524059507619584069L;
	
	private Integer dataOutReferenceId;
	
	private DataReference dataOutReference;

	private DataFilterReference dataFilterReference;
	
	
	private String protocolName;
	
	
	private String dataType;
	

	private String topicName;
	

}
