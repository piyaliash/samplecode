package com.ubs.wmap.eisl.registrationService.model;

import lombok.Data;

import java.io.Serializable;

@Data
public class DataOutReferenceResponse implements Serializable {

	private static final long serialVersionUID = 8023385196692316336L;
	private Integer dataOutReferenceId;
	private String protocolName;
	private String dataType;
	private String topicName;
	private DataFilterResponse dataFilterReference;

}
