package com.ubs.wmap.eisl.registrationService.model;

import lombok.Data;

@Data
public class DataSO {

	private Integer dataServiceId;
	private Integer dataRefernceId;
	private String dataInTopic;
	private String dataOutTopic;
}
