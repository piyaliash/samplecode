package com.ubs.wmap.eisl.registrationService.model;

import lombok.Data;

import java.io.Serializable;
import java.util.Set;

@Data
public class DataReferenceResponse implements Serializable {

	private static final long serialVersionUID = -598494958569462261L;

	private Integer dataServiceId;
	
	private String dataInTopic;
	
	private Set<DataOutReferenceResponse> dataOutReferences;



	
}
