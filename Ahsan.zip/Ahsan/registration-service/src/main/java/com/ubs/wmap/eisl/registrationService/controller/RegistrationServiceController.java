package com.ubs.wmap.eisl.registrationService.controller;
import javax.validation.constraints.NotBlank;

import com.ubs.wmap.eisl.registrationService.exception.DataNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ubs.wmap.eisl.registrationService.constants.RegistrationConstants;
import com.ubs.wmap.eisl.registrationService.exception.EsilTokenNotValidException;
import com.ubs.wmap.eisl.registrationService.exception.InvalidDataException;
import com.ubs.wmap.eisl.registrationService.model.PayloadSO;
import com.ubs.wmap.eisl.registrationService.model.RegistrationSO;
import com.ubs.wmap.eisl.registrationService.model.ResponseSO;
import com.ubs.wmap.eisl.registrationService.service.RegistrationServiceImpl;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequestMapping(produces = "application/json")
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class RegistrationServiceController {


    private final RegistrationServiceImpl registrationService;

    @Value("${registration.service.registryAccessEndpoint}")
    private String registryAccessEndpoint;

    @Value("${app.custom.token_attribute_name}")
    private String eislObjectKey;


    @GetMapping(value = "/registrations")
    public ResponseEntity<ResponseSO> getRegistry(@NotBlank @RequestHeader(name = "Authorization") String authHeader,
                                                  @NotBlank @RequestParam("token") String eislToken) throws EsilTokenNotValidException, InvalidDataException, DataNotFoundException {
        String basicToken = trimAuthorizationSchema(authHeader);
        if (!registrationService.getEislClaims(eislToken).containsKey(eislObjectKey)) {
                log.error("Eisl Token not valid");
                throw new EsilTokenNotValidException(RegistrationConstants.INVALID_ESIL_TOKEN);
        }

        try {
            ResponseSO dto;
            dto = registrationService.getRegistration(eislToken);
            return ResponseEntity.ok()
                    .body(dto);
        } catch (DataNotFoundException | InvalidDataException ex) {
            log.error("Invalid Data to build registry {} ",ex.getMessage());
            throw new InvalidDataException(RegistrationConstants.DATA_NOT_FOUND);
        }
    }

    @PostMapping(value = "/registrations")
    public ResponseEntity<RegistrationSO> addRegistry(@NotBlank @RequestHeader(name = "Authorization") final String authHeader,
                                                      @NotBlank @RequestParam final String eislToken, @RequestBody PayloadSO payload) throws EsilTokenNotValidException, InvalidDataException, DataNotFoundException {
        String basicToken = trimAuthorizationSchema(authHeader);
        if (!registrationService.getEislClaims(eislToken).containsKey(eislObjectKey)) {
            log.error("Eisl Token not valid");
            throw new EsilTokenNotValidException(RegistrationConstants.INVALID_ESIL_TOKEN);
        }

            try {
                RegistrationSO dto;
                dto = registrationService.postRegistration(eislToken, payload);
                return ResponseEntity.ok()
                        .body(dto);
            } catch (DataNotFoundException | InvalidDataException ex) {
                log.error("Invalid Data to build registry {} ",ex.getMessage());
                throw new InvalidDataException(RegistrationConstants.DATA_NOT_FOUND);
            }

    }

    @PutMapping(value = "/registrations")
    public ResponseEntity<RegistrationSO> updateRegistry(@NotBlank @RequestHeader(name = "Authorization") final String authHeader,
                                                         @NotBlank @RequestParam final String eislToken, @RequestBody PayloadSO payload) throws EsilTokenNotValidException, InvalidDataException, DataNotFoundException {
        String basicToken = trimAuthorizationSchema(authHeader);
        if (!registrationService.getEislClaims(eislToken).containsKey(eislObjectKey)) {
            log.error("Eisl Token not valid");
            throw new EsilTokenNotValidException(RegistrationConstants.INVALID_ESIL_TOKEN);
        }
            try {
                RegistrationSO dto;
                dto = registrationService.putRegistration(eislToken, payload);
                return ResponseEntity.ok()
                        .body(dto);
            } catch (DataNotFoundException | InvalidDataException ex) {
                log.error("Invalid Data to build registry {} ",ex.getMessage());
                throw new InvalidDataException(RegistrationConstants.DATA_NOT_FOUND);
            }

    }


    @DeleteMapping(value = "/registrations")
    public ResponseEntity<Object> deleteRegistry(@NotBlank @RequestHeader(name = "Authorization") final String authHeader, @NotBlank @RequestParam final String eislToken) throws EsilTokenNotValidException {
        String basicToken = trimAuthorizationSchema(authHeader);
        if (!registrationService.getEislClaims(eislToken).containsKey(eislObjectKey)) {
            log.error("Eisl Token not valid");
            throw new EsilTokenNotValidException(RegistrationConstants.INVALID_ESIL_TOKEN);
        }
        return ResponseEntity.ok()
                .body(registrationService.deleteRegistration(registryAccessEndpoint, eislToken));
    }


    private String trimAuthorizationSchema(String authorizationHeader) {
        return authorizationHeader.replaceAll("^Bearer ", "");
    }
}
