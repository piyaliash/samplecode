package com.ubs.wmap.eisl.registrationService.model;

import lombok.Data;

import java.io.Serializable;

@Data
public class DataFilterResponse implements Serializable{

	private static final long serialVersionUID = 228694173931964139L;
	
	private Integer filterRefernceId;
	private String filterName;
	private String filterOption;

	
}
