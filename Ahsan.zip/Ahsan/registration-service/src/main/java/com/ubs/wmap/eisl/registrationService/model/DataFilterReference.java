package com.ubs.wmap.eisl.registrationService.model;

import lombok.Data;

import java.io.Serializable;

@Data
public class DataFilterReference implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -715389885855316908L;
	
	
	private Integer filterRefernceId;
	

	private DataOutReference dataOutReference;
	

	private String filterName;
	

	private String filterOption;


}
