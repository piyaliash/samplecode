package com.ubs.wmap.eisl.ms.eventregistry.controller.delegates;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ubs.wmap.eisl.ms.eventregistry.exception.EventException;
import com.ubs.wmap.eisl.ms.eventregistry.services.EventService;
import com.ubs.wmap.eisl.ms.eventregistry.services.sos.EventRequestSO;
import com.ubs.wmap.eisl.ms.eventregistry.services.sos.EventResponseSO;

@Component
public class EventDelegate {
	
	
	@Autowired
	private EventService eventService;
	
	public EventResponseSO getEventDetails(EventRequestSO eventRequestSO) throws EventException{
		 return eventService.getEventDetails(eventRequestSO);
	}
	
	
	public EventResponseSO saveEventDetails(EventRequestSO eventRequestSO) throws EventException{
		 return eventService.saveEventDetails(eventRequestSO);
	}

}
