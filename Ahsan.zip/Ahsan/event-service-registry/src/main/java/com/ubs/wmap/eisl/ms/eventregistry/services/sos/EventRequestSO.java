package com.ubs.wmap.eisl.ms.eventregistry.services.sos;

import java.io.Serializable;

import lombok.Data;

@Data
public class EventRequestSO implements Serializable{
	
	private static final long serialVersionUID = -998787659770475488L;
	
	private String serviceId;
	private String serviceName;
	private String eventTopic;
	private Integer dataServiceId;
	private Integer exceptionServiceId;
	private String createdBy;

	@Override
    public String toString() {
		 return new StringBuilder("serviceId:").append(serviceId)
		            .append(",serviceName:").append(serviceName)
		            .append(",eventTopic:").append(eventTopic)
		            .append(",dataServiceId:").append(dataServiceId)
		            .append(",exceptionServiceId:").append(exceptionServiceId)
		            .append(",createdBy:").append(createdBy).toString();
             
    }
	
}
