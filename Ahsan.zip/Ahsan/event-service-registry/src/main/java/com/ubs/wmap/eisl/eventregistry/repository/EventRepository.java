package com.ubs.wmap.eisl.eventregistry.repository;

import com.ubs.wmap.eisl.eventregistry.model.Events;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface  EventRepository extends JpaRepository<Events, Long> {
	
	Events findByServiceId(@Param("serviceId") String serviceId);

}
