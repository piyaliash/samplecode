package com.ubs.wmap.eisl.ms.eventregistry.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ubs.wmap.eisl.ms.eventregistry.model.Events;

@Repository
public interface  EventRepository extends JpaRepository<Events, Long> {
	
	Events findByServiceId(@Param("serviceId") String serviceId);

}
