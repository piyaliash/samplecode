package com.ubs.wmap.eisl.ms.eventregistry.controller;

import static com.ubs.wmap.eisl.ms.eventregistry.constants.EventConstants.EVENT_GET_ENDPOINT;
import static com.ubs.wmap.eisl.ms.eventregistry.constants.EventConstants.EVENT_NOT_FOUND_MSG;
import static com.ubs.wmap.eisl.ms.eventregistry.constants.EventConstants.EVENT_SAVE_ENDPOINT;
import static com.ubs.wmap.eisl.ms.eventregistry.constants.EventConstants.INTERNAL_SERVER_ERROR_MSG;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ubs.wmap.eisl.ms.eventregistry.controller.delegates.EventDelegate;
import com.ubs.wmap.eisl.ms.eventregistry.exception.EventBadRequestException;
import com.ubs.wmap.eisl.ms.eventregistry.exception.EventException;
import com.ubs.wmap.eisl.ms.eventregistry.exception.EventNotFoundException;
import com.ubs.wmap.eisl.ms.eventregistry.services.sos.EventRequestSO;
import com.ubs.wmap.eisl.ms.eventregistry.services.sos.EventResponseSO;
import com.ubs.wmap.eisl.ms.eventregistry.util.EislClaimsContextUtil;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class EventController extends BaseController {

	@Autowired
	private EventDelegate eventDelegate;
	
	@Autowired
	private EislClaimsContextUtil eislClaimsContextUtil;
	
	
	@RequestMapping(value = EVENT_GET_ENDPOINT, method = RequestMethod.GET)
	public ResponseEntity<EventResponseSO> getEventDetails(@RequestParam("eislToken") String token)
			throws EventException, EventBadRequestException {
		log.debug("token:{}",token);
		EventResponseSO eventResponseSO = null;
		
	
		//Get service id from the claims
		String serviceId=null;
		Object claim=eislClaimsContextUtil.getContextParam("serviceId");
		if(claim!=null) {
			serviceId=(String)eislClaimsContextUtil.getContextParam("serviceId");
		}
		log.debug("serviceId from claims:{}",serviceId);
		
		try {
			eventResponseSO = eventDelegate.getEventDetails(constructEvenRequestSO(serviceId));
			if (eventResponseSO == null) {
				throw new EventNotFoundException(EVENT_NOT_FOUND_MSG + serviceId);
			}

		} catch (EventException eventException) {
			log.error( eventException.getMessage(), eventException);
			throw new EventException(INTERNAL_SERVER_ERROR_MSG);
		}

		return ResponseEntity.ok(eventResponseSO);
	}

	/**
	 * This is just for testing and has to be remove
	 */
	/*@RequestMapping(value = "/event/{serviceId}", method = RequestMethod.GET)
	public ResponseEntity<EventResponseSO> getEventDetails1(@PathVariable("serviceId") String serviceId)
			throws EventException {
		EventResponseSO eventResponseSO = null;

		try {
			eventResponseSO = eventDelegate.getEventDetails(constructEvenRequestSO(serviceId));
			if (eventResponseSO == null) {
				throw new EventNotFoundException(EVENT_NOT_FOUND_MSG + serviceId);
			}

		} catch (EventException eventException) {
			log.error( eventException.getMessage(), eventException);
			throw new EventException(INTERNAL_SERVER_ERROR_MSG);
		}

		return ResponseEntity.ok(eventResponseSO);
	}*/
	
	
	@RequestMapping(value = EVENT_SAVE_ENDPOINT, method = RequestMethod.POST)
	public ResponseEntity<EventResponseSO> saveEventDetails(@RequestBody EventRequestSO eventRequestSO)
			throws EventException {
		EventResponseSO eventResponseSO = null;

		try {
			eventResponseSO = eventDelegate.saveEventDetails(eventRequestSO);

		} catch (EventException eventException) {
			log.error( eventException.getMessage(), eventException);
			throw new EventException(INTERNAL_SERVER_ERROR_MSG);
		}

		return ResponseEntity.ok(eventResponseSO);
	}

	private EventRequestSO constructEvenRequestSO(String serviceId) {
		EventRequestSO eventRequestSO = new EventRequestSO();
		eventRequestSO.setServiceId(serviceId);
		return eventRequestSO;
	}

}
