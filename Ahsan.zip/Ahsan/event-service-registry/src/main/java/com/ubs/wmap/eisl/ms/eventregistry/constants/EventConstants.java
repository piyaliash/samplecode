package com.ubs.wmap.eisl.ms.eventregistry.constants;

public final class EventConstants {
	
	private EventConstants() {
	}

	public static final String EVENT_NOT_FOUND_MSG="Event Not found for given ";
	
	public static final String INTERNAL_SERVER_ERROR_MSG="Internal server error occured ";
	
	public static final String EVENT_GET_ENDPOINT="/eisl/event/v1/events";
	
	public static final String EVENT_SAVE_ENDPOINT="/eisl/event/v1/event";
}
