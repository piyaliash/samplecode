package com.ubs.wmap.eisl.eventregistry.context;

import lombok.Data;

@Data
public final class EislClaimsContextHolder  {
	
	
	private EislClaimsContextHolder(){
	}
	
	private  static ThreadLocal<EislClaimsContext> threadLocal = new ThreadLocal<EislClaimsContext>();


	public static EislClaimsContext get() {
		EislClaimsContext  eislClaimsContext= threadLocal.get();
		return eislClaimsContext;
	}


	public static void set(EislClaimsContext eislClaimsContext) {
		threadLocal.set(eislClaimsContext);
	}
	
	public static void remove() {
		threadLocal.remove();
	}

}
