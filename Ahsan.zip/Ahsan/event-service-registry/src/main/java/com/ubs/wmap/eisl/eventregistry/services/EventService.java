package com.ubs.wmap.eisl.eventregistry.services;

import com.ubs.wmap.eisl.eventregistry.services.sos.EventRequestSO;
import com.ubs.wmap.eisl.eventregistry.exception.EventException;
import com.ubs.wmap.eisl.eventregistry.services.sos.EventResponseSO;
/**
 * Get event details 
 * @author SMAREDDY
 *
 */
public interface EventService {
	
	/**
	 * Get event details based on serviceId
	 * @param eventRequestSO
	 * @return EventResponseSO
	 * @throws EventException
	 */
	EventResponseSO getEventDetails(EventRequestSO eventRequestSO) throws EventException;
	
	/**
	 * Save/Update event details
	 * @param eventRequestSO
	 * @return EventResponseSO
	 * @throws EventException
	 */
	EventResponseSO saveEventDetails(EventRequestSO eventRequestSO)throws EventException;

}
