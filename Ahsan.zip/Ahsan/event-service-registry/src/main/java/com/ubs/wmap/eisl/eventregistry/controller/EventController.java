package com.ubs.wmap.eisl.eventregistry.controller;

import com.ubs.wmap.eisl.eventregistry.services.sos.EventRequestSO;
import com.ubs.wmap.eisl.eventregistry.util.EislClaimsContextUtil;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.ubs.wmap.eisl.eventregistry.controller.delegates.EventDelegate;
import com.ubs.wmap.eisl.eventregistry.exception.EventBadRequestException;
import com.ubs.wmap.eisl.eventregistry.exception.EventException;
import com.ubs.wmap.eisl.eventregistry.exception.EventNotFoundException;
import com.ubs.wmap.eisl.eventregistry.services.sos.EventResponseSO;

import lombok.extern.slf4j.Slf4j;

import javax.validation.constraints.NotBlank;

//@AllArgsConstructor(onConstructor = @__(@Autowired))
@RestController
@Slf4j
public class EventController {

	@Autowired
	private EventDelegate eventDelegate;

	@Autowired
	private EislClaimsContextUtil eislClaimsContextUtil;
	

	@Value("${app.message.INTERNAL_SERVER_ERROR_MSG}")
	private String INTERNAL_SERVER_ERROR_MSG;
	
	@Value("${app.message.EVENT_NOT_FOUND_MSG}")
	private String EVENT_NOT_FOUND_MSG;
	
	
	@RequestMapping(value = "/eisl/event/v1/events", method = RequestMethod.GET)
	public ResponseEntity<EventResponseSO> getEventDetails(@NotBlank @RequestHeader(name = "BasicToken")  String basicToken, @NotBlank @RequestParam("eislToken") String eislToken)
			throws EventException, EventBadRequestException {
		log.debug("token:{}",eislToken);
		EventResponseSO eventResponseSO = null;
		
	
		//Get service id from the claims
		String serviceId=null;
		Object claim=eislClaimsContextUtil.getContextParam("serviceId");
		if(claim!=null) {
			serviceId=(String)eislClaimsContextUtil.getContextParam("serviceId");
		}
		log.debug("serviceId from claims:{}",serviceId);
		
		try {
			eventResponseSO = eventDelegate.getEventDetails(constructEvenRequestSO(serviceId));
			if (eventResponseSO == null) {
				throw new EventNotFoundException(EVENT_NOT_FOUND_MSG + ":" +serviceId);
			}

		} catch (EventException eventException) {
			log.error( eventException.getMessage(), eventException);
			throw new EventException(INTERNAL_SERVER_ERROR_MSG);
		}

		return ResponseEntity.ok(eventResponseSO);
	}

	
	@RequestMapping(value = "/eisl/event/v1/event", method = RequestMethod.POST)
	public ResponseEntity<EventResponseSO> saveEventDetails(@RequestBody EventRequestSO eventRequestSO)
			throws EventException {
		EventResponseSO eventResponseSO = null;

		try {
			eventResponseSO = eventDelegate.saveEventDetails(eventRequestSO);

		} catch (EventException eventException) {
			log.error( eventException.getMessage(), eventException);
			throw new EventException(INTERNAL_SERVER_ERROR_MSG);
		}

		return ResponseEntity.ok(eventResponseSO);
	}

	private EventRequestSO constructEvenRequestSO(String serviceId) {
		EventRequestSO eventRequestSO = new EventRequestSO();
		eventRequestSO.setServiceId(serviceId);
		return eventRequestSO;
	}

}
