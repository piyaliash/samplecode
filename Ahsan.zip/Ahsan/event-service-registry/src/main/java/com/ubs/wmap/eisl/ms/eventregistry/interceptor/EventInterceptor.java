package com.ubs.wmap.eisl.ms.eventregistry.interceptor;

import java.io.IOException;
import java.time.LocalDateTime;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.servlet.HandlerInterceptor;

import com.ubs.wmap.eisl.housekeeping.TokenService;
import com.ubs.wmap.eisl.ms.eventregistry.context.EislClaimsContext;
import com.ubs.wmap.eisl.ms.eventregistry.context.EislClaimsContextHolder;

import io.jsonwebtoken.Claims;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class EventInterceptor implements HandlerInterceptor {

	public static final String TIMESTAMP="timestamp";
	public static final String STATUS="status";
	public static final String MESSAGE="message";
	
	@Autowired
	private TokenService tokenService;

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
	
		String eislToken=request.getParameter("eislToken");
		log.debug("eislToken from request param:{}",eislToken);
		
		if(StringUtils.isEmpty(eislToken)) {
			 constructErrorResponseObject(request,response,"Token is Empty. Please pass the Token parameter in the request",
						HttpServletResponse.SC_BAD_REQUEST);
			 return false;
		}
		
		/** This is just for testing and to be remove**/
		eislToken = tokenService.init("userid", "1", "Admin");

		log.debug("eislToken:{}", eislToken);

		boolean isValidToken = tokenService.isEISLTokenValid(eislToken);
		log.debug("isValidToken:{}", isValidToken);
		if (!isValidToken) {
			 constructErrorResponseObject(request,response,"Token is Invalid",
						HttpServletResponse.SC_UNAUTHORIZED);
			return false;
		}
		
		Claims claims = tokenService.unwrapEislToken(eislToken);
		createAndSetClaimsInContext(claims);
		
		return true;
	}
	
	private void createAndSetClaimsInContext(Claims claims) {
		EislClaimsContext eislClaimsContext = new EislClaimsContext();
		eislClaimsContext.setClaims(claims);
		EislClaimsContextHolder.set(eislClaimsContext);
	}
	
	private void constructErrorResponseObject(HttpServletRequest request, HttpServletResponse 
			response,String message, int status) {
		
		JSONObject jSONObject = createJsonErrorObject(message,status);
		setErrorInHttpRequestResponse(request, response, status,jSONObject);
		
	}

	private JSONObject createJsonErrorObject(String message, int status) {
		JSONObject json = new JSONObject();
		json.put(TIMESTAMP, LocalDateTime.now());
		json.put(STATUS, status);
		json.put(MESSAGE,message );
		return json;
	}

	private void setErrorInHttpRequestResponse(HttpServletRequest httpRequest, 
			HttpServletResponse httpResponse, int status, JSONObject json) {
		httpResponse.addHeader("Content-Type", "application/json");
		try {
			httpResponse.setStatus(status);
			httpResponse.getWriter().write(json.toString());
			httpResponse.getWriter().flush();
			httpResponse.getWriter().close();
		} catch (IOException e) {
			log.error(e.getMessage());
		}
	}
}
