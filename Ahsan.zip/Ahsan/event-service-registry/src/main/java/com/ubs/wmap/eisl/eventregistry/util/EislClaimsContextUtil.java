package com.ubs.wmap.eisl.eventregistry.util;

import org.springframework.stereotype.Component;

import com.ubs.wmap.eisl.eventregistry.context.EislClaimsContext;
import com.ubs.wmap.eisl.eventregistry.context.EislClaimsContextHolder;

import io.jsonwebtoken.Claims;

@Component
public class EislClaimsContextUtil {
	
	public Object getContextParam(String param) {
		EislClaimsContext eislClaimsContext=EislClaimsContextHolder.get();
		Claims claims=eislClaimsContext.getClaims();
		if(claims==null) return null;	
		
		return claims.get(param);
	}

}
