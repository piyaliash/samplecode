package com.ubs.wmap.eisl.ms.eventregistry.controller;

public abstract class BaseController {
	
}