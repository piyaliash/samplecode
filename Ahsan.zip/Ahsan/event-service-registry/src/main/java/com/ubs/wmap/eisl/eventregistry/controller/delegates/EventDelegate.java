package com.ubs.wmap.eisl.eventregistry.controller.delegates;

import com.ubs.wmap.eisl.eventregistry.services.EventService;
import com.ubs.wmap.eisl.eventregistry.services.sos.EventRequestSO;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ubs.wmap.eisl.eventregistry.exception.EventException;
import com.ubs.wmap.eisl.eventregistry.services.sos.EventResponseSO;

@AllArgsConstructor(onConstructor = @__(@Autowired))
@Component
public class EventDelegate {

	private  EventService eventService;
	
	public EventResponseSO getEventDetails(EventRequestSO eventRequestSO) throws EventException{
		 return eventService.getEventDetails(eventRequestSO);
	}
	
	
	public EventResponseSO saveEventDetails(EventRequestSO eventRequestSO) throws EventException{
		 return eventService.saveEventDetails(eventRequestSO);
	}

}
