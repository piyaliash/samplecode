package com.ubs.wmap.eisl.eventregistry.test.controller;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import com.ubs.wmap.eisl.eventregistry.controller.EventController;
import com.ubs.wmap.eisl.eventregistry.exception.EventNotFoundException;
import com.ubs.wmap.eisl.eventregistry.services.sos.EventResponseSO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Import;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.ubs.wmap.eisl.housekeeping.TokenServiceConfiguration;

@RunWith(SpringRunner.class)
@DataJpaTest
@EnableAutoConfiguration
@Import(TokenServiceConfiguration.class)
@EnableJpaAuditing
@ComponentScan(basePackages = { "com.ubs.wmap.eisl.ms.eventregistry" })
public class EventControllerTest {

	@Autowired
	private EventController eventController;

	@Test
	public void eventControllerDataTest() throws Exception {

		ResponseEntity<EventResponseSO> responseEntity = eventController.getEventDetails("abc","1");
		assertNotNull(responseEntity);
	}

	@Test
	public void eventControllerWithoutDataTest() throws Exception {
		try {
			ResponseEntity<EventResponseSO> responseEntity = eventController.getEventDetails("abc","3");
			assertNotNull(responseEntity);
		} catch (EventNotFoundException ex) {
			assertTrue(true);
		}
	}

}
