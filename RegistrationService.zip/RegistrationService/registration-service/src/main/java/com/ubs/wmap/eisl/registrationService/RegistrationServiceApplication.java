package com.ubs.wmap.eisl.registrationService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Import;

import com.ubs.wmap.eisl.housekeeping.TokenServiceConfiguration;

@SpringBootApplication
@Import(TokenServiceConfiguration.class)
public class RegistrationServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(RegistrationServiceApplication.class, args);
	}

}
