package com.ubs.wmap.eisl.registrationService.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ubs.wmap.eisl.housekeeping.TokenService;
import com.ubs.wmap.eisl.registrationService.exception.DataNotFoundException;
import com.ubs.wmap.eisl.registrationService.exception.InvalidDataException;
import com.ubs.wmap.eisl.registrationService.model.*;
import com.ubs.wmap.eisl.registrationService.service.RegistrationServiceImpl;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.*;

import static org.junit.Assert.*;
@Slf4j
@ActiveProfiles("test")
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.DEFINED_PORT)
public class RegistrationServiceControllerTest {

    @Mock
    private RegistrationServiceController registrationServiceController;

//    @Autowired
//    private ObjectMapper mapper;

    @Mock
    private TestRestTemplate restTemplate;

    @Mock
    private TokenService tokenService;

    @InjectMocks
    private RegistrationServiceImpl registrationService;

    @LocalServerPort
    private int port;

    @Value("${registration.service.registryAccessEndpoint}")
    private String registryAccessEndpoint;

    @Value("${registration.service.dataAccessEndpoint}")
    private String dataAccessEndpoint;

    @Value("${registration.service.eventAccessEndpoint}")
    private String eventAccessEndpoint;

    @Value("${registration.service.exceptionAccessEndpoint}")
    private String exceptionAccessEndpoint;

    @Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);


    }
    @Test
    public void getRegistry() throws InvalidDataException, DataNotFoundException {

        String basicToken = tokenService.init("user1","password","service1");
        String eislToken = tokenService.init("user1","service1","roles");



        RoleRequestVO roleRequestVO = new RoleRequestVO();
        roleRequestVO.setConsume("TestConsume");
        roleRequestVO.setPublish("publish");



        Set<ColumnReferenceRequestVO> columnReferences = new HashSet<>();

        Set<RowReferenceRequestVO> rowReferences = new HashSet<>();

        ColumnReferenceRequestVO columnReferenceRequestVO = new ColumnReferenceRequestVO();
        columnReferenceRequestVO.setName("name");
        columnReferenceRequestVO.setType("type");
        columnReferences.add(columnReferenceRequestVO);

        RowReferenceRequestVO rowReferenceRequestVO = new RowReferenceRequestVO();
        rowReferenceRequestVO.setName("rowName");
        rowReferenceRequestVO.setType("type");
        rowReferences.add(rowReferenceRequestVO);

//mock registrationSO
        RegistrationSO registrationSO = RegistrationSO.builder()
                .userId("testUser1")
                .serviceId("TestService3")
                .company("testComp1")
                .eislToken("eislTokentest")
                .dataEntitlement("dataSent")
                .userName("user1")
                .columnReferences(columnReferences)
                .rowReferences(rowReferences)
                .role(roleRequestVO)
                .build();

//        String eventResponse ="{"+"category"+":"+"string"+","+"createdBy"+":"+"string"+","+"createdDate"+":"+"2019-04-24T10:22:52.805Z"+","+"exceptionDataRefId"+":"+"string"+","+"exceptionDataResponseSO"+":"+"{"+"createdBy"+":"+"string"+","+"createdDate"+":"+"2019-04-24T10:22:52.805Z"+","+"exceptionDataId"+":"+0+","+"lastUpdatedBy"+":"+"string"+","+"lastUpdatedDate"+":"+"2019-04-24T10:22:52.805Z"+","+"metadata"+":"+"string"+","+"stackTrace"+":"+"string"+"}"+","+"exceptionRefId"+":"+0+","+"exceptionServiceId"+":"+0+","+"exceptionTopic"+":"+"string"+","+"lastUpdatedBy"+":"+"string"+","+"lastUpdatedDate"+":"+"2019-04-24T10:22:52.805Z"+"}";
//        String dataResponse ="{"+"category"+":"+"string"+","+"createdBy"+":"+"string"+","+"createdDate"+":"+"2019-04-24T10:22:52.805Z"+","+"exceptionDataRefId"+":"+"string"+","+"exceptionDataResponseSO"+":"+"{"+"createdBy"+":"+"string"+","+"createdDate"+":"+"2019-04-24T10:22:52.805Z"+","+"exceptionDataId"+":"+0+","+"lastUpdatedBy"+":"+"string"+","+"lastUpdatedDate"+":"+"2019-04-24T10:22:52.805Z"+","+"metadata"+":"+"string"+","+"stackTrace"+":"+"string"+"}"+","+"exceptionRefId"+":"+0+","+"exceptionServiceId"+":"+0+","+"exceptionTopic"+":"+"string"+","+"lastUpdatedBy"+":"+"string"+","+"lastUpdatedDate"+":"+"2019-04-24T10:22:52.805Z"+"}";
//        String s1 ="{"+"category"+":"+"string"+","+"createdBy"+":"+"string"+","+"createdDate"+":"+"2019-04-24T10:22:52.805Z"+","+"exceptionDataRefId"+":"+"string"+","+"exceptionDataResponseSO"+":"+"{"+"createdBy"+":"+"string"+","+"createdDate"+":"+"2019-04-24T10:22:52.805Z"+","+"exceptionDataId"+":"+0+","+"lastUpdatedBy"+":"+"string"+","+"lastUpdatedDate"+":"+"2019-04-24T10:22:52.805Z"+","+"metadata"+":"+"string"+","+"stackTrace"+":"+"string"+"}"+","+"exceptionRefId"+":"+0+","+"exceptionServiceId"+":"+0+","+"exceptionTopic"+":"+"string"+","+"lastUpdatedBy"+":"+"string"+","+"lastUpdatedDate"+":"+"2019-04-24T10:22:52.805Z"+"}";


        long nowMillis = (new Date()).getTime();
        long expMillis = nowMillis + 300000000;

        Map<String, Object> eislClaims = new HashMap();
        eislClaims.put("userName", "test");
        eislClaims.put("serviceId", "1");
        Date exp = new Date(expMillis);
        String jwt = Jwts.builder()
                .setClaims(eislClaims)
                .setExpiration(exp)
                .signWith(SignatureAlgorithm.HS512, "test")
                .compact();
        Claims claims = null;
        claims = (Claims) Jwts.parser().setSigningKey("test").parseClaimsJws(jwt).getBody();


        ResponseSO responseSO = new ResponseSO();
//        ResponseEntity<RegistrationSO> responseDto = new ResponseEntity<>(HttpStatus.OK);
        BeanUtils.copyProperties(registrationSO, responseSO);
//        BeanUtils.copyProperties(responseDto , responseSO);



        String url = String.format("https://localhost:8089/eisl/%s", "users/v1/registrations");
        HttpHeaders headers = new HttpHeaders();
        headers.add("basicToken", basicToken);
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url).queryParam("eislToken", eislToken);

        Mockito.when(tokenService.unwrapEislToken(eislToken)).thenReturn(claims);
        Mockito.when(restTemplate.getForEntity(builder.toUriString(), RegistrationServiceImpl.class)).thenReturn(new ResponseEntity(registrationSO, HttpStatus.OK));

        Mockito.when(registrationService.getRegistryResponse(registryAccessEndpoint, basicToken, eislToken)).thenReturn(registrationSO);

        Mockito.when(registrationService.getRegistration(basicToken,eislToken)).thenReturn(responseSO);

        HttpHeaders headers1 = new HttpHeaders();
        headers1.set("Authorization", "Bearer " + basicToken);
        HttpEntity<String> request = new HttpEntity<String>(headers1);

        String uri = UriComponentsBuilder.fromHttpUrl("http://localhost:" + port + "/eisl/registrations/v1/registration")
                .queryParam("eislToken", eislToken)
                .queryParam("companyName","companyName")
                .queryParam("userName","user1")
                .toUriString();
        ResponseEntity<String> response = this.restTemplate.exchange(uri, HttpMethod.GET, request, String.class);

        assertEquals(HttpStatus.OK.value(), response.getStatusCodeValue());
        assertNotNull(response);


    }



}