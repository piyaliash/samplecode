package com.ubs.wmap.eisl.dataserviceregistry;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.ubs.wmap.eisl.dataserviceregistry.model.DataReference;
import com.ubs.wmap.eisl.dataserviceregistry.repository.CustomRepository;

@ActiveProfiles("test")
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.DEFINED_PORT)
@ComponentScan(basePackages = {"com.ubs.wmap.eisl.dataserviceregistry"})
public class CustomRepositoryTest {

	@Autowired
	private CustomRepository repo;
	@Test(expected=Exception.class)
	public void testRefreshException() {
		DataReference dataReference = new DataReference();
		repo.refresh(dataReference);
	}
	
}
