package com.ubs.wmap.eisl.dataserviceregistry;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.util.NestedServletException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ubs.wmap.eisl.dataserviceregistry.controller.DataServiceRegistryController;
import com.ubs.wmap.eisl.dataserviceregistry.service.DataReferenceService;
import com.ubs.wmap.eisl.dataserviceregistry.vo.DataFilterReferenceRequest;
import com.ubs.wmap.eisl.dataserviceregistry.vo.DataOutReferenceRequest;
import com.ubs.wmap.eisl.dataserviceregistry.vo.DataOutReferenceResponse;
import com.ubs.wmap.eisl.dataserviceregistry.vo.DataReferenceRequest;
import com.ubs.wmap.eisl.dataserviceregistry.vo.DataReferenceResponse;


@ActiveProfiles("test")
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ComponentScan(basePackages = {"com.ubs.wmap.eisl.dataserviceregistry"})
public class DataServiceRegistryControllerTest {
	
	private MockMvc mockMvc;
	
	@Mock
	private DataReferenceService dataReferenceService;
	
	@InjectMocks
	private DataServiceRegistryController dataServiceRegistryController;
	
	@Autowired
	private WebApplicationContext webApplicationContext;
	
	@Autowired
	private DataServiceRegistryController controller;
	
	@Before
	public void setup() {
		/*mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();*/
		mockMvc= MockMvcBuilders.standaloneSetup(dataServiceRegistryController).build();
	}
	@Test
	public void testGetDataReference() throws Exception {
		Set<DataOutReferenceResponse> dataOutReferences = new HashSet<>();
		DataOutReferenceResponse dataOutReferenceResponse = new DataOutReferenceResponse();
		dataOutReferenceResponse.setDataType("dataType");
		dataOutReferenceResponse.setProtocolName("protocol");
		dataOutReferenceResponse.setTopic("topic");
		dataOutReferences.add(dataOutReferenceResponse);
		
		DataReferenceResponse dataReference = new DataReferenceResponse();
		dataReference.setDataOutReferences(dataOutReferences);
		dataReference.setDataInTopic("topic");
		dataReference.setDataReferenceId(1);
		dataReference.setDataServiceId("testService");
		
		DataReferenceRequest request = new DataReferenceRequest();
		request.setDataServiceId("testService");
		
		Mockito.when(dataReferenceService.getDataReference(request)).thenReturn(dataReference);
		
		mockMvc.perform(get("/eisl/data/v1/data").param("eislToken", "abcd-abc12-qwe").param("dataServiceId", "testService")).andDo(print()).andExpect(status().isOk())
				.andExpect(content().contentType("application/json;charset=UTF-8"))
				.andExpect(MockMvcResultMatchers.jsonPath("$.dataOutReferences").exists())
				.andExpect(MockMvcResultMatchers.jsonPath("$.dataReferenceId").value(1))
				.andExpect(MockMvcResultMatchers.jsonPath("$.dataServiceId").value("testService"))
				.andExpect(MockMvcResultMatchers.jsonPath("$.dataInTopic").value("topic"));
		
	}
	
	@Test
	public void tesPostDataReference() throws Exception {
		Set<DataOutReferenceResponse> dataOutReferences = new HashSet<>();
		DataOutReferenceResponse dataOutReferenceResponse = new DataOutReferenceResponse();
		dataOutReferenceResponse.setDataType("dataType");
		dataOutReferenceResponse.setProtocolName("protocol");
		dataOutReferenceResponse.setTopic("topic");
		dataOutReferences.add(dataOutReferenceResponse);
		
		DataReferenceResponse dataReference = new DataReferenceResponse();
		dataReference.setDataOutReferences(dataOutReferences);
		dataReference.setDataInTopic("TestTopic");
		dataReference.setDataReferenceId(1);
		dataReference.setDataServiceId("TestService1");
		
		Mockito.when(dataReferenceService.saveDataReference(getDataReferenceRequest())).thenReturn(dataReference);
		
		mockMvc.perform(post("/eisl/data/v1/data").contentType(MediaType.APPLICATION_JSON)
				.content(asJsonString(getDataReferenceRequest())).param("eislToken", "abcd-abc12-qwe")).andDo(print())
				.andExpect(status().isOk()).andExpect(content().contentType("application/json;charset=UTF-8"))
				.andExpect(MockMvcResultMatchers.jsonPath("$.dataOutReferences").exists())
				.andExpect(MockMvcResultMatchers.jsonPath("$.dataReferenceId").value(1))
				.andExpect(MockMvcResultMatchers.jsonPath("$.dataServiceId").value("TestService1"))
				.andExpect(MockMvcResultMatchers.jsonPath("$.dataInTopic").value("TestTopic"));
		
	}
	
	@Test(expected = NestedServletException.class)
	public void whenGetDataReferenceExceptionForEmptyServiceId() throws Exception {
		Set<DataOutReferenceResponse> dataOutReferences = new HashSet<>();
		DataOutReferenceResponse dataOutReferenceResponse = new DataOutReferenceResponse();
		dataOutReferenceResponse.setDataType("dataType");
		dataOutReferenceResponse.setProtocolName("protocol");
		dataOutReferenceResponse.setTopic("topic");
		dataOutReferences.add(dataOutReferenceResponse);
		
		DataReferenceResponse dataReference = new DataReferenceResponse();
		dataReference.setDataOutReferences(dataOutReferences);
		dataReference.setDataInTopic("topic");
		dataReference.setDataReferenceId(1);
		dataReference.setDataServiceId("testService");
		
		DataReferenceRequest request = new DataReferenceRequest();
		request.setDataServiceId("testService");
		
		Mockito.when(dataReferenceService.getDataReference(request)).thenReturn(dataReference);
		
		mockMvc.perform(get("/eisl/data/v1/data").param("eislToken", "abcd-abc12-qwe").param("dataServiceId", ""));
	}
	
	@Test(expected = NestedServletException.class)
	public void whenGetDataReferenceExceptionUnexpected() throws Exception {
		DataReferenceRequest request = new DataReferenceRequest();
		request.setDataServiceId("testService");
		
		Mockito.when(dataReferenceService.getDataReference(request)).thenReturn(null);
		
		mockMvc.perform(get("/eisl/data/v1/data").param("eislToken", "abcd-abc12-qwe").param("dataServiceId", "testService"));
	}
	
	@Test(expected = Exception.class)
	public void whenGetDataReferenceExceptionCaught() throws Exception {
		
		DataReferenceRequest request = new DataReferenceRequest();
		request.setDataServiceId("testService");
		controller.getDataReferenceDetails("fff-sss", "test");
	}
	
	private DataReferenceResponse getDataReference(boolean isExp) throws Exception {
		
		Set<DataOutReferenceResponse> dataOutReferences = new HashSet<>();
		DataOutReferenceResponse dataOutReferenceResponse = new DataOutReferenceResponse();
		dataOutReferenceResponse.setDataType("dataType");
		dataOutReferenceResponse.setProtocolName("protocol");
		dataOutReferenceResponse.setTopic("topic");
		dataOutReferences.add(dataOutReferenceResponse);
		
		DataReferenceResponse dataReference = new DataReferenceResponse();
		dataReference.setDataOutReferences(dataOutReferences);
		dataReference.setDataInTopic("topic");
		dataReference.setDataReferenceId(1);
		dataReference.setDataServiceId("testService");
		if(isExp) throw new Exception();
		return dataReference;
	}
	private DataReferenceRequest getDataReferenceRequest() {
		DataReferenceRequest dataReferenceRequest = new DataReferenceRequest();
		dataReferenceRequest.setDataInTopic("TestTopic");
		dataReferenceRequest.setDataServiceId("TestService1");
		dataReferenceRequest.setDataReferenceId(1);
		List<DataOutReferenceRequest> dataOutReferenceRequests = new ArrayList<>();
		DataOutReferenceRequest dataOutReferenceRequest = new DataOutReferenceRequest();
		dataOutReferenceRequest.setDataType("dataType");
		dataOutReferenceRequest.setProtocolName("protocolName");
		dataOutReferenceRequest.setTopic("topic");
		DataFilterReferenceRequest dataFilterReferenceRequest = new DataFilterReferenceRequest();
		dataFilterReferenceRequest.setName("filterName");
		dataFilterReferenceRequest.setOptions("filteroption");
		dataOutReferenceRequest.setDataFilterReferenceRequest(dataFilterReferenceRequest);
		dataReferenceRequest.setOutReferenceRequests(dataOutReferenceRequests);
		return dataReferenceRequest;
	}

	private String asJsonString(DataReferenceRequest request) {
		String asJson = null;
		try {
			asJson = new ObjectMapper().writeValueAsString(request);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		return asJson;
	}
}
