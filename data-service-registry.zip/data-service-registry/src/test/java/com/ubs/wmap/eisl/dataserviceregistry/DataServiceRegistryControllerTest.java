package com.ubs.wmap.eisl.dataserviceregistry;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.HashSet;

import java.util.Set;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.util.NestedServletException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ubs.wmap.eisl.dataserviceregistry.controller.DataServiceRegistryController;
import com.ubs.wmap.eisl.dataserviceregistry.service.DataReferenceService;
import com.ubs.wmap.eisl.dataserviceregistry.vo.DataAccessModelRequest;
import com.ubs.wmap.eisl.dataserviceregistry.vo.DataAccessModelResponse;
import com.ubs.wmap.eisl.dataserviceregistry.vo.DataFilterRequest;
import com.ubs.wmap.eisl.dataserviceregistry.vo.DataFilterResponse;
import com.ubs.wmap.eisl.dataserviceregistry.vo.DataReferenceRequest;
import com.ubs.wmap.eisl.dataserviceregistry.vo.DataReferenceResponse;
import com.ubs.wmap.eisl.dataserviceregistry.vo.ProtocolsRequest;
import com.ubs.wmap.eisl.dataserviceregistry.vo.ProtocolsResponse;


@ActiveProfiles("test")
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ComponentScan(basePackages = {"com.ubs.wmap.eisl.dataserviceregistry"})
public class DataServiceRegistryControllerTest {
	
	private MockMvc mockMvc;
	
	@Mock
	private DataReferenceService dataReferenceService;
	
	@InjectMocks
	private DataServiceRegistryController dataServiceRegistryController;
	
	@Autowired
	private WebApplicationContext webApplicationContext;
	
	@Autowired
	private DataServiceRegistryController controller;
	
	@Before
	public void setup() {
		mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
		mockMvc= MockMvcBuilders.standaloneSetup(dataServiceRegistryController).build();
	}
	@Test
	public void testGetDataReference() throws Exception {
		
		DataReferenceResponse dataReference = new DataReferenceResponse();
		dataReference.setDataReferenceId(1);
		dataReference.setDataServiceId("testService");
		
		DataFilterResponse dataFilter = new DataFilterResponse();
		dataFilter.setFilterId(1);
		dataFilter.setName("filter");
		dataFilter.setOptions("option");
		dataReference.setDataFilter(dataFilter );
		
		Set<DataAccessModelResponse> dataModelRes = new HashSet<>();
		
		DataAccessModelResponse dataAccessModelResponse = new DataAccessModelResponse();
		dataAccessModelResponse.setModelName("model");
		dataModelRes.add(dataAccessModelResponse);
		dataReference.setDataModel(dataModelRes);
		
		
		Set<ProtocolsResponse> protocolsRess =new HashSet<>();
		ProtocolsResponse protocolsRes = new ProtocolsResponse();
		protocolsRes.setName("Rest");
		protocolsRes.setDetails("restApi");
		protocolsRess.add(protocolsRes);
		dataReference.setProtocols(protocolsRess);
		
		
		DataReferenceRequest request = new DataReferenceRequest();
		request.setDataServiceId("testService");
		
		Mockito.when(dataReferenceService.getDataReference(request)).thenReturn(dataReference);
		
		mockMvc.perform(get("/eisl/data/v1/data").param("eislToken", "abcd-abc12-qwe").param("dataServiceId", "testService")).andDo(print()).andExpect(status().isOk())
				.andExpect(content().contentType("application/json;charset=UTF-8"))
				.andExpect(MockMvcResultMatchers.jsonPath("$.protocols").exists())
				.andExpect(MockMvcResultMatchers.jsonPath("$.dataModel").exists())
				.andExpect(MockMvcResultMatchers.jsonPath("$.dataFilter").exists())
				.andExpect(MockMvcResultMatchers.jsonPath("$.dataReferenceId").value(1))
				.andExpect(MockMvcResultMatchers.jsonPath("$.dataServiceId").value("testService"));
	}
	
	@Test
	public void tesPostDataReference() throws Exception {
		DataReferenceResponse dataReference = new DataReferenceResponse();
		dataReference.setDataReferenceId(1);
		dataReference.setDataServiceId("testService");
		
		DataFilterResponse dataFilter = new DataFilterResponse();
		dataFilter.setFilterId(1);
		dataFilter.setName("filter");
		dataFilter.setOptions("option");
		dataReference.setDataFilter(dataFilter );
		
		Set<DataAccessModelResponse> dataModelRes = new HashSet<>();
		
		DataAccessModelResponse dataAccessModelResponse = new DataAccessModelResponse();
		dataAccessModelResponse.setModelName("model");
		dataModelRes.add(dataAccessModelResponse);
		dataReference.setDataModel(dataModelRes);
		
		
		Set<ProtocolsResponse> protocolsRess =new HashSet<>();
		ProtocolsResponse protocolsRes = new ProtocolsResponse();
		protocolsRes.setName("Rest");
		protocolsRes.setDetails("restApi");
		protocolsRess.add(protocolsRes);
		dataReference.setProtocols(protocolsRess);
		
		Mockito.when(dataReferenceService.saveDataReference(getDataReferenceRequest())).thenReturn(dataReference);
		
		mockMvc.perform(post("/eisl/data/v1/data").contentType(MediaType.APPLICATION_JSON)
				.content(asJsonString(getDataReferenceRequest())).param("eislToken", "abcd-abc12-qwe")).andDo(print())
				.andExpect(status().isOk()).andExpect(content().contentType("application/json;charset=UTF-8"))
				.andExpect(MockMvcResultMatchers.jsonPath("$.protocols").exists())
				.andExpect(MockMvcResultMatchers.jsonPath("$.dataModel").exists())
				.andExpect(MockMvcResultMatchers.jsonPath("$.dataFilter").exists())
				.andExpect(MockMvcResultMatchers.jsonPath("$.dataReferenceId").value(1))
				.andExpect(MockMvcResultMatchers.jsonPath("$.dataServiceId").value("testService"));
		
	}
	
	@Test(expected = NestedServletException.class)
	public void whenGetDataReferenceExceptionForEmptyServiceId() throws Exception {
		DataReferenceResponse dataReference = new DataReferenceResponse();
		dataReference.setDataReferenceId(1);
		dataReference.setDataServiceId("testService");
		
		DataFilterResponse dataFilter = new DataFilterResponse();
		dataFilter.setFilterId(1);
		dataFilter.setName("filter");
		dataFilter.setOptions("option");
		dataReference.setDataFilter(dataFilter );
		
		Set<DataAccessModelResponse> dataModelRes = new HashSet<>();
		
		DataAccessModelResponse dataAccessModelResponse = new DataAccessModelResponse();
		dataAccessModelResponse.setModelName("model");
		dataModelRes.add(dataAccessModelResponse);
		dataReference.setDataModel(dataModelRes);
		
		
		Set<ProtocolsResponse> protocolsRess =new HashSet<>();
		ProtocolsResponse protocolsRes = new ProtocolsResponse();
		protocolsRes.setName("Rest");
		protocolsRes.setDetails("restApi");
		protocolsRess.add(protocolsRes);
		dataReference.setProtocols(protocolsRess);
		
		DataReferenceRequest request = new DataReferenceRequest();
		request.setDataServiceId("testService");
		
		Mockito.when(dataReferenceService.getDataReference(request)).thenReturn(dataReference);
		
		mockMvc.perform(get("/eisl/data/v1/data").param("eislToken", "abcd-abc12-qwe").param("dataServiceId", ""));
	}
	
	@Test(expected = NestedServletException.class)
	public void whenGetDataReferenceExceptionUnexpected() throws Exception {
		DataReferenceRequest request = new DataReferenceRequest();
		request.setDataServiceId("testService");
		
		Mockito.when(dataReferenceService.getDataReference(request)).thenReturn(null);
		
		mockMvc.perform(get("/eisl/data/v1/data").param("eislToken", "abcd-abc12-qwe").param("dataServiceId", "testService"));
	}
	
	@Test(expected = Exception.class)
	public void whenGetDataReferenceExceptionCaught() throws Exception {
		
		DataReferenceRequest request = new DataReferenceRequest();
		request.setDataServiceId("testService");
		controller.getDataReferenceDetails("fff-sss", "test");
	}

	private DataReferenceRequest getDataReferenceRequest() {
		DataReferenceRequest dataReferenceRequest = new DataReferenceRequest();
		dataReferenceRequest.setDataServiceId("TestService1");
		dataReferenceRequest.setDataReferenceId(1);
		
		DataFilterRequest dataFilterRequest = new DataFilterRequest();
		dataFilterRequest.setName("filter");
		dataFilterRequest.setOptions("option");
		dataReferenceRequest.setDataFilterRequest(dataFilterRequest );
		
		Set<DataAccessModelRequest> dataModelRequest = new HashSet<>();
		
		DataAccessModelRequest dataAccessModelRequest = new DataAccessModelRequest();
		dataAccessModelRequest.setModelName("model");
		dataModelRequest.add(dataAccessModelRequest);
		dataReferenceRequest.setDataModelRequest(dataModelRequest );
		
		Set<ProtocolsRequest> protocolsRequests =new HashSet<>();
		ProtocolsRequest protocolsRequest = new ProtocolsRequest();
		protocolsRequest.setName("Rest");
		protocolsRequest.setDetails("restApi");
		protocolsRequests.add(protocolsRequest);
		dataReferenceRequest.setProtocolsRequest(protocolsRequests);
		
		return dataReferenceRequest;
	}

	private String asJsonString(DataReferenceRequest request) {
		String asJson = null;
		try {
			asJson = new ObjectMapper().writeValueAsString(request);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		return asJson;
	}
}
