insert into DATA_REFERENCE (Data_reference_id, Data_service_id)
values (1, 'service1');

insert into FILTER (Filter_id, Name, Options, Data_reference_id)
values (1,'nameTest', 'optionTest', 1);

insert into DATA_ACCESS_MODEL (Data_access_model_id, Model_name, Data_reference_id)
values (1,'Banking', 1);

insert into PROTOCOLS (Protocols_id, Name, Details, Data_reference_id)
values (1,'Rest', 'Sample Details', 1);