package com.ubs.wmap.eisl.dataserviceregistry.exception;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

@Data
public class ErrorDetails {
	private String message;
	private String details;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy hh:mm:ss")
	private LocalDateTime timestamp;

	public ErrorDetails(String message, String details) {
		super();
		this.timestamp = LocalDateTime.now();
		this.message = message;
		this.details = details;
	}

}
