/**
 * Copyright (c) 2019, 2020, UBS and its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 */
package com.ubs.wmap.eisl.dataserviceregistry.service.impl;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import javax.transaction.Transactional;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.ubs.wmap.eisl.dataserviceregistry.exception.DataReferenceException;
import com.ubs.wmap.eisl.dataserviceregistry.exception.DataReferenceNotFoundException;
import com.ubs.wmap.eisl.dataserviceregistry.model.DataFilter;
import com.ubs.wmap.eisl.dataserviceregistry.model.DataAccessModel;
import com.ubs.wmap.eisl.dataserviceregistry.model.DataReference;
import com.ubs.wmap.eisl.dataserviceregistry.model.Protocols;
import com.ubs.wmap.eisl.dataserviceregistry.repository.DataFilterReferenceRepository;
import com.ubs.wmap.eisl.dataserviceregistry.repository.DataModelRepository;
import com.ubs.wmap.eisl.dataserviceregistry.repository.DataRefefrenceRepository;
import com.ubs.wmap.eisl.dataserviceregistry.repository.ProtocolsRepository;
import com.ubs.wmap.eisl.dataserviceregistry.service.DataReferenceService;
import com.ubs.wmap.eisl.dataserviceregistry.vo.DataFilterRequest;
import com.ubs.wmap.eisl.dataserviceregistry.vo.DataFilterResponse;
import com.ubs.wmap.eisl.dataserviceregistry.vo.DataAccessModelRequest;
import com.ubs.wmap.eisl.dataserviceregistry.vo.DataAccessModelResponse;
import com.ubs.wmap.eisl.dataserviceregistry.vo.DataReferenceRequest;
import com.ubs.wmap.eisl.dataserviceregistry.vo.DataReferenceResponse;
import com.ubs.wmap.eisl.dataserviceregistry.vo.ProtocolsRequest;
import com.ubs.wmap.eisl.dataserviceregistry.vo.ProtocolsResponse;

import lombok.extern.slf4j.Slf4j;

/**
 * The <code>DataReferenceServiceImpl</code> class includes 
 * methods to get and post data from and to db.
 * <p>getDataReference, fetch data based on serviceId.
 * <p>saveDataReference, persist parent and associated
 * child entities to database. 
 * <p>This class uses {@code BeanUtils.copyProperties} to
 * copy properties from dto to entity and vice versa.
 * @author UBS
 * @see com.ubs.wmap.eisl.dataserviceregistry.DataServiceRegistryController
 * @see com.ubs.wmap.eisl.dataserviceregistry.DataRefefrenceRepository
 * @see com.ubs.wmap.eisl.dataserviceregistry.DataModelRepository
 * @see com.ubs.wmap.eisl.dataserviceregistry.ProtocolsRepository
 * @see com.ubs.wmap.eisl.dataserviceregistry.CustomRepositoryImpl
 *
 */
@Service
@Slf4j
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DataReferenceServiceImpl implements DataReferenceService {
	
	private final DataRefefrenceRepository dataRefefrenceRepository;
	
	private final DataModelRepository dataModelRepository;
	
	private final ProtocolsRepository protocolsRepository;
	
	private final DataFilterReferenceRepository dataFilterReferenceRepository;
	
	@Value("${service.message.DATA_REFERENCE_NOT_FOUND_MSG}")
	private String DATA_REFERENCE_NOT_FOUND_MSG;
	
	/* (non-Javadoc)
	 * @see com.ubs.wmap.eisl.dataserviceregistry.service.DataReferenceService#getDataReference(com.ubs.wmap.eisl.dataserviceregistry.vo.DataReferenceRequest)
	 */
	@Override
	public DataReferenceResponse getDataReference(DataReferenceRequest dataReferenceRequest)
			throws DataReferenceException {
		log.debug("Service Enter:Inside getDataReference");
		log.debug("DataReferenceRequest : {}",dataReferenceRequest);
		DataReferenceResponse response = null;
		DataReference dataReference = dataRefefrenceRepository
				.findBydataServiceId(dataReferenceRequest.getDataServiceId());
		if (dataReference == null) {
			throw new DataReferenceNotFoundException(DATA_REFERENCE_NOT_FOUND_MSG);
		} else {
			response = constructDataReference(dataReference);
			if (dataReference.getDataFilter() != null) {
				response.setDataFilter(constructDataFilterResponse(dataReference.getDataFilter()));
			}
			if(dataReference.getDataModel() != null) {
				response.setDataModel(constructDataModelResponse(dataReference.getDataModel()));
			}
			if(dataReference.getProtocols() != null) {
				response.setProtocols(constructProtocolsResponse(dataReference.getProtocols()));
			}
		}
		log.debug("DataReferenceResponse : {}",response);
		log.debug("Service Exit:Exiting getDataReference");
		return response;
	}
	
	
	private Set<ProtocolsResponse> constructProtocolsResponse(Set<Protocols> protocolsSet) {
		Set<ProtocolsResponse> protocolsResponseSet = new HashSet<>();
		for (Protocols protocols : protocolsSet) {
			ProtocolsResponse protocolsResponse = constructProtocolsResponse(protocols);
			protocolsResponseSet.add(protocolsResponse);
		}
		return protocolsResponseSet;
	}


	private ProtocolsResponse constructProtocolsResponse(Protocols protocols) {
		ProtocolsResponse protocolsResponse = new ProtocolsResponse();
		BeanUtils.copyProperties(protocols, protocolsResponse);
		return protocolsResponse;
	}


	private Set<DataAccessModelResponse> constructDataModelResponse(Set<DataAccessModel> dataModels) {
		
		Set<DataAccessModelResponse> dataModelSet = new HashSet<>();
		for (DataAccessModel dataModel : dataModels) {
			DataAccessModelResponse dataModelRes = constructDataModelResult(dataModel);
			dataModelSet.add(dataModelRes);
		}
		return dataModelSet;
	}

	private DataAccessModelResponse constructDataModelResult(DataAccessModel dataModel) {
		DataAccessModelResponse dataModelres = new DataAccessModelResponse();
		BeanUtils.copyProperties(dataModel, dataModelres);
		return dataModelres;
	}


	private DataFilterResponse constructDataFilterResponse(DataFilter dataFilterReference) {
		DataFilterResponse dataFilterResponse = new DataFilterResponse();
		BeanUtils.copyProperties(dataFilterReference, dataFilterResponse);
		return dataFilterResponse;
	}
	
	private DataReferenceResponse constructDataReference (DataReference dataReference){
		DataReferenceResponse dataReferenceResponse = new DataReferenceResponse();
		BeanUtils.copyProperties(dataReference, dataReferenceResponse);
		return dataReferenceResponse;
	}
	
	/* (non-Javadoc)
	 * @see com.ubs.wmap.eisl.dataserviceregistry.service.DataReferenceService#saveDataReference(com.ubs.wmap.eisl.dataserviceregistry.vo.DataReferenceRequest)
	 */
	@Transactional
	@Override
	public DataReferenceResponse saveDataReference(DataReferenceRequest dataReferencerequest)
			throws DataReferenceException {
		//Save Parent
		DataReference dataReference=constructDataReferenceEntityFromSO(dataReferencerequest);
		dataRefefrenceRepository.save(dataReference);
		dataRefefrenceRepository.flush();
		//Save child 
		saveDataFilter(dataReferencerequest, dataReference);
		saveDataModel(dataReferencerequest, dataReference);
		saveProtocols(dataReferencerequest, dataReference);
		//get latest data
		dataRefefrenceRepository.refresh(dataReference);
		DataReferenceResponse response = null;
		Optional<DataReference> dataRef = dataRefefrenceRepository.findById(dataReference.getDataReferenceId());
		if(dataRef.isPresent()) {
			DataReference drLatest = dataRef.get();
			response = constructDataReference(drLatest);
			if (drLatest.getDataFilter() != null) {
				response.setDataFilter(constructDataFilterResponse(drLatest.getDataFilter()));
			}
			if(drLatest.getDataModel() != null) {
				response.setDataModel(constructDataModelResponse(drLatest.getDataModel()));
			}
			if(drLatest.getProtocols() != null) {
				response.setProtocols(constructProtocolsResponse(drLatest.getProtocols()));
			}
		}
		return response;
	}

	private void saveProtocols(DataReferenceRequest dataReferencerequest, DataReference dataReference) {
		Set<ProtocolsRequest> protocols = dataReferencerequest.getProtocolsRequest();
		if (!CollectionUtils.isEmpty(protocols)) {
			for (ProtocolsRequest protocolsRequest : protocols) {
				Protocols protocolsEnt = constructProtocolsEntFromSO(protocolsRequest);
				protocolsEnt.setDataReference(dataReference);
				protocolsRepository.save(protocolsEnt);
			}
		}
		
	}

	private Protocols constructProtocolsEntFromSO(ProtocolsRequest protocolsRequest) {
		Protocols protocols = new Protocols();
		BeanUtils.copyProperties(protocolsRequest, protocols);
		return protocols;
	}

	private void saveDataModel(DataReferenceRequest dataReferencerequest, DataReference dataReference) {
		Set<DataAccessModelRequest> dataModel = dataReferencerequest.getDataModelRequest();
		if (!CollectionUtils.isEmpty(dataModel)) {
			for (DataAccessModelRequest dataModelRequest : dataModel) {
				DataAccessModel dataModelEnt = ConstructDataModelFromSO(dataModelRequest);
				dataModelEnt.setDataReference(dataReference);
				dataModelRepository.save(dataModelEnt);
			}
		}
		
	}

	private DataAccessModel ConstructDataModelFromSO(DataAccessModelRequest dataModelRequest) {
		DataAccessModel dataModel = new DataAccessModel();
		BeanUtils.copyProperties(dataModelRequest, dataModel);
		return dataModel;
	}


	private void saveDataFilter(DataReferenceRequest dataReferencerequest, DataReference dataReference) {
		DataFilterRequest dataFilter = dataReferencerequest.getDataFilterRequest();
		DataFilter constructDataFilterRef = ConstructDataFilterRefFromSO(dataFilter);
		constructDataFilterRef.setDataReference(dataReference);
		dataFilterReferenceRepository.save(constructDataFilterRef);
		dataReference.setDataFilter(constructDataFilterRef);
	}

	private DataFilter ConstructDataFilterRefFromSO(DataFilterRequest dataFilterReferenceRequest) {
		DataFilter dataFilterReference = new DataFilter();
		BeanUtils.copyProperties(dataFilterReferenceRequest, dataFilterReference);
		return dataFilterReference;
	}

	private DataReference constructDataReferenceEntityFromSO(DataReferenceRequest dataReferencerequest){
		DataReference dataReference= new DataReference();
		BeanUtils.copyProperties(dataReferencerequest, dataReference);
		return dataReference;
		
	}
}
