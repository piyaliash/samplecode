package com.ubs.wmap.eisl.dataserviceregistry.vo;

import java.io.Serializable;
import java.util.Set;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
public class DataReferenceRequest implements Serializable {

	private static final long serialVersionUID = -83396507865626884L;
	private Integer dataReferenceId;
	
	private String dataServiceId;
	
	@EqualsAndHashCode.Exclude
	private Set<ProtocolsRequest> protocolsRequest;
	
	@EqualsAndHashCode.Exclude
	private Set<DataAccessModelRequest> dataModelRequest;
	
	@EqualsAndHashCode.Exclude
	private DataFilterRequest dataFilterRequest;
}
