package com.ubs.wmap.eisl.dataserviceregistry.repository;

import org.springframework.stereotype.Repository;

import com.ubs.wmap.eisl.dataserviceregistry.model.DataAccessModel;

@Repository
public interface DataModelRepository extends CustomRepository<DataAccessModel, Integer>{

}
