package com.ubs.wmap.eisl.dataserviceregistry.repository;

import org.springframework.stereotype.Repository;

import com.ubs.wmap.eisl.dataserviceregistry.model.Protocols;

@Repository
public interface ProtocolsRepository extends CustomRepository<Protocols, Integer>{

}
