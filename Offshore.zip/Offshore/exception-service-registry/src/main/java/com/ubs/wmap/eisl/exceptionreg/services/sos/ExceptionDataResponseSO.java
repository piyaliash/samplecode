package com.ubs.wmap.eisl.exceptionreg.services.sos;

import java.io.Serializable;
import java.util.Date;

import lombok.Data;

@Data
public class ExceptionDataResponseSO implements Serializable{
	
	private static final long serialVersionUID = -8626286941250840467L;

	private Long exceptionDataId;
	private String stackTrace;
	private String metadata;
	private String createdBy;
	private String lastUpdatedBy;
	private Date createdDate;
	private Date lastUpdatedDate;

	@Override
	public String toString() {
		return "exceptionDataId:" +exceptionDataId
				+" ,stackTrace:" + stackTrace
				+" ,metadata:"+metadata
				+" ,createdBy:"+createdBy
				+" ,lastUpdatedBy:"+lastUpdatedBy
				+" ,createdDate:"+createdDate
				+" ,lastUpdatedDate:"+lastUpdatedDate;

	}
	
}
