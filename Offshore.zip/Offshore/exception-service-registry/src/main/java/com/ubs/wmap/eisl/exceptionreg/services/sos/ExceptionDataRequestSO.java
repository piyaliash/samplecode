package com.ubs.wmap.eisl.exceptionreg.services.sos;

import java.io.Serializable;

import lombok.Data;

@Data
public class ExceptionDataRequestSO implements Serializable{

	private static final long serialVersionUID = 6476655618490475851L;
	
	private Long exceptionDataId;
	private String stackTrace;
	private String metadata;
	private String none;
	
	@Override
	public String toString() {
		return "exceptionDataId:"+exceptionDataId
				+",stackTrace:"+stackTrace
				+",metadata:"+metadata
				+"none:"+none;
	}

}
