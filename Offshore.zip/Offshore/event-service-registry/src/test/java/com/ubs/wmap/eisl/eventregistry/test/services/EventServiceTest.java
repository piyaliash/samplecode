package com.ubs.wmap.eisl.eventregistry.test.services;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.test.context.junit4.SpringRunner;

import com.ubs.wmap.eisl.eventregistry.services.EventService;
import com.ubs.wmap.eisl.eventregistry.services.sos.EventRequestSO;
import com.ubs.wmap.eisl.eventregistry.services.sos.EventResponseSO;

@RunWith(SpringRunner.class)
@DataJpaTest
@EnableAutoConfiguration
@EnableJpaAuditing
@ComponentScan(basePackages = { "com.ubs.wmap.eisl.ms.eventregistry" })
public class EventServiceTest {
	
	@Autowired
	private EventService eventService;
	
	@Test
	public void testGetEventDetailsWithData() throws Exception {
		EventRequestSO eventRequestSO=new EventRequestSO();
		eventRequestSO.setServiceId("1");
		EventResponseSO eventResponseSO = eventService.getEventDetails(eventRequestSO);
		assertNotNull(eventResponseSO);
	}
	
	@Test
	public void testGetEventDetailsWithOutData() throws Exception {
		EventRequestSO eventRequestSO=new EventRequestSO();
		eventRequestSO.setServiceId("3");
		EventResponseSO eventResponseSO = eventService.getEventDetails(eventRequestSO);
		assertNull(eventResponseSO);
	}
}
