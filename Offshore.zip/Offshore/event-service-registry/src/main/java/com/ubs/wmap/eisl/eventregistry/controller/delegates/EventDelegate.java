package com.ubs.wmap.eisl.eventregistry.controller.delegates;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ubs.wmap.eisl.eventregistry.exception.EventException;
import com.ubs.wmap.eisl.eventregistry.services.EventService;
import com.ubs.wmap.eisl.eventregistry.services.sos.EventRequestSO;
import com.ubs.wmap.eisl.eventregistry.services.sos.EventResponseSO;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@Component
public class EventDelegate {
	
	private final EventService eventService;
	
	public EventResponseSO getEventDetails(String serviceId ) throws EventException{
		 return eventService.getEventDetails(constructEvenRequestSO(serviceId));
	}
	
	
	public EventResponseSO saveEventDetails(EventRequestSO eventRequestSO) throws EventException{
		 return eventService.saveEventDetails(eventRequestSO);
	}
	
	private EventRequestSO constructEvenRequestSO(String serviceId) {
		EventRequestSO eventRequestSO = new EventRequestSO();
		eventRequestSO.setServiceId(serviceId);
		return eventRequestSO;
	}

}
