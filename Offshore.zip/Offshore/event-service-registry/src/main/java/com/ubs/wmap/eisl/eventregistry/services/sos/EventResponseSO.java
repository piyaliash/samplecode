package com.ubs.wmap.eisl.eventregistry.services.sos;

import java.io.Serializable;
import java.util.Date;

import lombok.Data;

@Data
public class EventResponseSO implements Serializable{
	
	private static final long serialVersionUID = 7273465233846581680L;
	
	private String serviceId;
	private String serviceName;
	private String eventTopic;
	private Integer dataServiceId;
	private Integer exceptionServiceId;
	private String createdBy;
	private String lastUpdatedBy;
	private Date createdDate;
	private Date lastUpdatedDate;
	private Long eventServiceId;

	
	@Override
    public String toString() {
        
        return "serviceId:" +serviceId 
        			+ " ,serviceName:" + serviceName
        		    + " ,eventTopic:"+ eventTopic
        	        + " ,dataServiceId:"+dataServiceId
        	        + " ,exceptionServiceId:"+exceptionServiceId
        	        + " ,createdBy:"+ createdBy
        	        + " ,createdDate:"+createdDate
        	        + " ,lastUpdatedBy:"+lastUpdatedBy
        	        + " ,lastUpdatedDate:"+lastUpdatedDate;
        
    }

}
