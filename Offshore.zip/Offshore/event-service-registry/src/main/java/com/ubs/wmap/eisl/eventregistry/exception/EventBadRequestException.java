package com.ubs.wmap.eisl.eventregistry.exception;

public class EventBadRequestException extends Exception{
	
	private static final long serialVersionUID = -2154287827168582345L;

	public EventBadRequestException(String message) {
		super(message);
	}

}
