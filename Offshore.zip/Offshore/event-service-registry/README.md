# event-service-registry

Create the jar for inHouseKeepingLibrary from the below git location
   https://github.ldn.swissbank.com/AA43979-ESL/house-keeping-library
   
Add lib folder in the root and add the jar inside it
Add the below dependency in pom file

<dependency>
   <groupId>com.ubs.wmap.eisl.housekeeping</groupId>
   <artifactId>housekeeping-api</artifactId>
   <version>0.0.1</version>
   <scope>system</scope>
   <systemPath>${basedir}/lib/housekeeping-api-0.0.1.jar</systemPath>
</dependency>

Add the below code in the SpringBoot Start Up application
  @SpringBootApplication
@Import(TokenServiceConfiguration.class)

Autowire TokenService and the corresponding methods can be used
