package com.ubs.wmap.eisl.registryaccessservice.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.ubs.wmap.eisl.registryaccessservice.service.RegistryReferenceService;
import com.ubs.wmap.eisl.registryaccessservice.util.EislClaimsContextUtil;
import com.ubs.wmap.eisl.registryaccessservice.vo.RegistrationRequestVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.RegistrationResponseVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.RegistryAccessRequestVO;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import com.ubs.wmap.eisl.registryaccessservice.exception.RegistryAccessBadRequestException;
import com.ubs.wmap.eisl.registryaccessservice.exception.RegistryAccessNotFoundException;
import com.ubs.wmap.eisl.registryaccessservice.exception.RegistryReferenceException;

@RestController
@Slf4j
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@CrossOrigin
public class RegistryAccessController{

	//@Autowired
	private RegistryReferenceService registryReferenceService;
	//@Autowired
	private EislClaimsContextUtil eislClaimsContextUtil;
	
	@Value("${service.message.REGISTRY_NOT_FOUND_MSG}")
	private String REGISTRY_NOT_FOUND_MSG;
	
	@Value("${service.message.INTERNAL_SERVER_ERROR_MSG}")
	private String INTERNAL_SERVER_ERROR_MSG;
	
	@GetMapping("/eisl/users/v1/registrations")
	public ResponseEntity<RegistrationResponseVO> getRegistryDetails(@RequestParam("eislToken") String eislToken)
			throws RegistryReferenceException, RegistryAccessBadRequestException {
		log.debug("Controller Enetr: Entering getDataReferenceDetails");
		log.debug("eislToken:{}",eislToken);
		String serviceId = null;
		Object claim = eislClaimsContextUtil.getContextParam("serviceId");
		if (claim != null) {
			serviceId = (String) eislClaimsContextUtil.getContextParam("serviceId");
		}
		log.debug("serviceId from claim:{}",serviceId);
		RegistrationResponseVO registrationResponse = null;
		try {
			RegistryAccessRequestVO request = new RegistryAccessRequestVO();
			request.setServiceId(serviceId);
			registrationResponse = registryReferenceService.getRegistryReference(request);
			if (null == registrationResponse) {
				log.debug("Controller Exit: Exiting getDataReferenceDetails");
				throw new RegistryAccessNotFoundException(REGISTRY_NOT_FOUND_MSG);
			}
		} catch (RegistryReferenceException ex) {
			log.debug("Controller Exit: Exiting getDataReferenceDetails");
			throw new RegistryReferenceException(INTERNAL_SERVER_ERROR_MSG);
		}
		log.debug("Controller Exit: Exiting getDataReferenceDetails");
		return ResponseEntity.ok(registrationResponse);
	}
	
	@PostMapping("/eisl/users/v1/registrations")
	public ResponseEntity<RegistrationResponseVO> postRegistry(@RequestBody RegistrationRequestVO registrationRequestVO,
			@RequestParam("eislToken") String eislToken) {
		log.debug("Controller : Entering postRegistry");
		RegistrationResponseVO registrationResponseVO = null;
		try {
			registrationResponseVO = registryReferenceService.persistRegistry(registrationRequestVO);
			if (null == registrationResponseVO) {
				log.debug("Controller : Exiting postRegistry");
				new ResponseEntity<RegistrationResponseVO>(registrationResponseVO, HttpStatus.NOT_FOUND);
			}
		} catch (RegistryReferenceException e) {
			log.error( e.getMessage(), e);
			log.debug("Controller : Exiting postRegistry");
			new ResponseEntity<RegistrationResponseVO>(registrationResponseVO, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		log.debug("Controller : Exiting postRegistry");
		return new ResponseEntity<RegistrationResponseVO>(registrationResponseVO, HttpStatus.OK);
	}
}
