package com.ubs.wmap.eisl.registryaccessservice.vo;

import java.io.Serializable;
import java.util.Set;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode
public class RegistrationRequestVO implements Serializable{

	private static final long serialVersionUID = 6349874774163306834L;
	private String userName;
	private String userId;
	private String company;
	private String eislToken;
	private String serviceId;
	private String dataEntitlement;
	@EqualsAndHashCode.Exclude
	private RoleRequestVO role;
	@EqualsAndHashCode.Exclude
	private Set<ColumnReferenceRequestVO> columnReferences;
	@EqualsAndHashCode.Exclude
	private Set<RowReferenceRequestVO> rowReferences;
}
