package com.ubs.wmap.eisl.registryaccessservice.vo;

import java.io.Serializable;
import java.util.Set;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode
public class RegistrationResponseVO implements Serializable {

	private static final long serialVersionUID = 2387423001946124578L;
	
	private Long registrationId;
	
	private String userName;
	
	private String userId;
	
	private String company;
	
	private String eislToken;
	
	private String serviceId;
	
	private String dataEntitlement;
	
	@EqualsAndHashCode.Exclude
	private RoleResponseVO role;
	
	@EqualsAndHashCode.Exclude
	private Set<ColumnReferenceResponseVO> columnReferences;
	
	@EqualsAndHashCode.Exclude
	private Set<RowReferenceResponseVO> rowReferences;
}
