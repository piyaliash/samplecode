package com.ubs.wmap.eisl.dataserviceregistry.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode
@Entity
@Table(name = "DATA_FILTER_REFERENCE")
public class DataFilterReference implements Serializable{

	private static final long serialVersionUID = -715389885855316908L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "Filter_reference_id")
	private Integer filterRefernceId;

	@Column(name = "name")
	private String name;
	
	@Column(name = "options")
	private String options;
	
	@EqualsAndHashCode.Exclude
	@OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "Data_out_reference_id", nullable=false)
	private DataOutReference dataOutReference;
}
