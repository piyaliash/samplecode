package com.ubs.wmap.eisl.registryaccessservice.exception;

public class InvalidEISLTokenException extends Exception{

	private static final long serialVersionUID = -2154287827168582345L;

	public InvalidEISLTokenException(String message) {
		super(message);
	}

}
