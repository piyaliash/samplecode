package com.ubs.wmap.eisl.registryaccessservice.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(name = "ROLES")
public class Roles implements Serializable{

	private static final long serialVersionUID = 7243390542455293742L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "ROLE_ID")
	private Long roleId;

	@Column(name = "PUBLISH")
	private String publish;
	
	@Column(name = "CONSUME")
	private String consume;
	
	@EqualsAndHashCode.Exclude
	@OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "REGISTRATION_ID", nullable=false)
	private Registration registration;
	
}
