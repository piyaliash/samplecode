/**
 * Copyright (c) 2019, 2020, UBS and its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 */
package com.ubs.wmap.eisl.registryaccessservice.service.impl;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import javax.transaction.Transactional;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.ubs.wmap.eisl.registryaccessservice.exception.RegistryAccessNotFoundException;
import com.ubs.wmap.eisl.registryaccessservice.exception.RegistryReferenceException;

import com.ubs.wmap.eisl.registryaccessservice.model.ColumnReference;
import com.ubs.wmap.eisl.registryaccessservice.model.Registration;
import com.ubs.wmap.eisl.registryaccessservice.model.Roles;
import com.ubs.wmap.eisl.registryaccessservice.model.RowReference;
import com.ubs.wmap.eisl.registryaccessservice.repository.ColumnReferenceRepository;
import com.ubs.wmap.eisl.registryaccessservice.repository.RegistrationRepository;
import com.ubs.wmap.eisl.registryaccessservice.repository.RoleRepository;
import com.ubs.wmap.eisl.registryaccessservice.repository.RowReferenceRepository;
import com.ubs.wmap.eisl.registryaccessservice.service.RegistryReferenceService;
import com.ubs.wmap.eisl.registryaccessservice.vo.ColumnReferenceRequestVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.ColumnReferenceResponseVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.RegistrationRequestVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.RegistrationResponseVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.RegistryAccessRequestVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.RoleRequestVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.RoleResponseVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.RowReferenceRequestVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.RowReferenceResponseVO;
import lombok.extern.slf4j.Slf4j;
/**
 * The <code>RegistryReferenceServiceImpl</code> class includes
 * methods to get and post data from and to db.
 * <p>getRegistryReference, fetch data based on serviceId.
 * <p>persistRegistry, persist parent and associated
 * child entities to database.
 * <p>This class uses {@code BeanUtils.copyProperties} to
 * copy properties from dto to entity and vice versa.
 * @author UBS
 *
 *
 */
@Service
@Slf4j
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class RegistryReferenceServiceImpl implements RegistryReferenceService {

	private final RegistrationRepository registrationRepository;

	private final ColumnReferenceRepository columnRefRepo;

	private final RowReferenceRepository rowRefRepo;

	private final RoleRepository roleRepo;

	@Value("${app.message.REGISTRY_NOT_FOUND_MSG}")
	private String REGISTRY_NOT_FOUND_MSG;
	@Override
	public RegistrationResponseVO getRegistryReference(RegistryAccessRequestVO registryAccessRequestVO)
			throws RegistryReferenceException {

		log.debug("Service Enter:Inside getDataReference");
		log.debug("DataReferenceRequest : {}", registryAccessRequestVO);

		RegistrationResponseVO response = null;
		Registration registration = registrationRepository.findByServiceId(registryAccessRequestVO.getServiceId());
		if (registration == null) {
			log.error("Can not find Registration");
			throw new RegistryAccessNotFoundException(REGISTRY_NOT_FOUND_MSG);
		} else {
			response = constructDataReference(registration);
			if (registration.getColumnReferences() != null)
				response.setColumnReferences(constructColumnReferences(registration.getColumnReferences()));
			if (registration.getRowReferences() != null)
				response.setRowReferences(constructRowReferences(registration.getRowReferences()));
			if (registration.getRole() != null)
				response.setRole(constructRoleReferences(registration.getRole()));
		}
		log.debug("DataReferenceResponse : {}", response);
		log.debug("Service Exit:Exiting getDataReference");
		return response;

	}

	private RoleResponseVO constructRoleReferences(Roles roles) {
		RoleResponseVO roleResponseVO = constructRole(roles);
		return roleResponseVO;
	}

	private RoleResponseVO constructRole(Roles roles) {
		RoleResponseVO roleResponseVO = new RoleResponseVO();
		BeanUtils.copyProperties(roles, roleResponseVO);
		return roleResponseVO;
	}


	private Set<ColumnReferenceResponseVO> constructColumnReferences(Set<ColumnReference> columnReferences) {
		Set<ColumnReferenceResponseVO> columnRefSet = new HashSet<>();
		for (ColumnReference columnReference : columnReferences) {
			ColumnReferenceResponseVO constructColumnReference = constructColumnReference(columnReference);

			columnRefSet.add(constructColumnReference);
		}
		return columnRefSet;
	}


	private ColumnReferenceResponseVO constructColumnReference(ColumnReference columnReference) {
		ColumnReferenceResponseVO columnReferenceResponseVO = new ColumnReferenceResponseVO();
		BeanUtils.copyProperties(columnReference, columnReferenceResponseVO);
		return columnReferenceResponseVO;
	}

	private Set<RowReferenceResponseVO> constructRowReferences(Set<RowReference> rowReferences) {
		Set<RowReferenceResponseVO> rowRefSet = new HashSet<>();
		for (RowReference rowReference : rowReferences) {
			RowReferenceResponseVO constructRowReference = constructRowReference(rowReference);
			rowRefSet.add(constructRowReference);
		}
		return rowRefSet;
	}

	private RowReferenceResponseVO constructRowReference(RowReference rowReference) {
		RowReferenceResponseVO rowReferenceResponseVO = new RowReferenceResponseVO();
		BeanUtils.copyProperties(rowReference, rowReferenceResponseVO);
		return rowReferenceResponseVO;
	}

	private RegistrationResponseVO constructDataReference(Registration registration) {
		RegistrationResponseVO registrationResponseVO = new RegistrationResponseVO();
		BeanUtils.copyProperties(registration, registrationResponseVO);
		return registrationResponseVO;
	}

	@Transactional
	@Override
	public RegistrationResponseVO persistRegistry(RegistrationRequestVO registrationRequestVO)
			throws RegistryReferenceException {
		Registration registration = constructDataRegistrationEntityFromVO(registrationRequestVO);
		registration.setColumnReferences(null);
		registration.setRowReferences(null);
		registrationRepository.save(registration);
		registrationRepository.flush();
		//Save Child
		saveRoles(registrationRequestVO, registration);
		saveColumnReference(registrationRequestVO, registration);
		saveRowReference(registrationRequestVO, registration);
		registrationRepository.refresh(registration);
		RegistrationResponseVO regResponse = null;
		Optional<Registration> regLatest = registrationRepository.findById(registration.getRegistrationId());
		if(regLatest.isPresent()) {
			Registration reg = regLatest.get();
			regResponse = constructDataReference(reg);
			if(null != reg.getRole()) {
				regResponse.setRole(constructRoleReferences(reg.getRole()));
			}
			if (null != reg.getColumnReferences()) {
				regResponse.setColumnReferences(constructColumnReferences(reg.getColumnReferences()));
			}
			if(null != reg.getRowReferences()) {
				regResponse.setRowReferences(constructRowReferences(reg.getRowReferences()));
			}
		}
		return regResponse;
	}

	private void saveRoles(RegistrationRequestVO registrationRequestVO, Registration registration) {
		RoleRequestVO roleRequestVO = registrationRequestVO.getRole();
		if (null != roleRequestVO) {
			Roles roles = constructRoleEntityFromVO(roleRequestVO);
			roles.setRegistration(registration);
			roleRepo.save(roles);
			registration.setRole(roles);
		}
	}

	private void saveColumnReference(RegistrationRequestVO registrationRequestVO, Registration registration) {
		Set<ColumnReferenceRequestVO> columnReferenceRequestVOs = registrationRequestVO.getColumnReferences();
		if (!CollectionUtils.isEmpty(columnReferenceRequestVOs)) {
			for (ColumnReferenceRequestVO columnReferenceRequestVO : columnReferenceRequestVOs) {
				ColumnReference columnReference = constructColumnReferenceEntityFromVO(columnReferenceRequestVO);
				columnReference.setRegistration(registration);
				columnRefRepo.save(columnReference);
			}
		}
	}

	private void saveRowReference(RegistrationRequestVO registrationRequestVO, Registration registration) {
		Set<RowReferenceRequestVO> rowReferenceRequestVOs = registrationRequestVO.getRowReferences();
		if (!CollectionUtils.isEmpty(rowReferenceRequestVOs)) {
			for (RowReferenceRequestVO rowReferenceRequestVO : rowReferenceRequestVOs) {
				RowReference rowReference = constructRowReferenceEntityFromVO(rowReferenceRequestVO);
				rowReference.setRegistration(registration);
				rowRefRepo.save(rowReference);
			}
		}
	}

	private RowReference constructRowReferenceEntityFromVO(RowReferenceRequestVO rowReferenceRequestVO) {
		RowReference rowReference = new RowReference();
		BeanUtils.copyProperties(rowReferenceRequestVO, rowReference);
		return rowReference;
	}

	private ColumnReference constructColumnReferenceEntityFromVO(ColumnReferenceRequestVO columnReferenceRequestVO) {
		ColumnReference columnReference = new ColumnReference();
		BeanUtils.copyProperties(columnReferenceRequestVO, columnReference);
		return columnReference;
	}

	private Roles constructRoleEntityFromVO(RoleRequestVO roleRequestVO) {
		Roles roles = new Roles();
		BeanUtils.copyProperties(roleRequestVO, roles);
		return roles;
	}

	private Registration constructDataRegistrationEntityFromVO(RegistrationRequestVO registrationRequestVO) {
		Registration registration = new Registration();
		BeanUtils.copyProperties(registrationRequestVO, registration);
		return registration;
	}
}
