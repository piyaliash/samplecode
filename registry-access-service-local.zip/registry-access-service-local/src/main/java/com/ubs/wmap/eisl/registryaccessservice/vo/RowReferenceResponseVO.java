package com.ubs.wmap.eisl.registryaccessservice.vo;

import java.io.Serializable;

import lombok.Data;

@Data
public class RowReferenceResponseVO implements Serializable {

	private static final long serialVersionUID = -5757508586634635377L;

	private Integer rowReferenceId;
	private String name;
	private String range;
}
