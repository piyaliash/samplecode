package com.ubs.eisl.notification.eventnotificationint.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ubs.eisl.notifcation.core.EventNotificationTemplate;
import com.ubs.eisl.notifcation.core.vos.EventInfo;
import com.ubs.eisl.notifcation.core.vos.EventResult;


@RestController
@RequestMapping(value = "/web-test/")
public class KafkaWebController {

	@Autowired
	private EventNotificationTemplate eventNotificationTemplate;

	@GetMapping(value = "/producer")
	public String producer(@RequestParam("message") String message) {
		EventInfo eventInfo=new EventInfo();
		eventInfo.setEislToken("testing kafka sending message:"+message);
		eventInfo.setTopicName("test-topic");
		EventResult eventResult=eventNotificationTemplate.postEvent(eventInfo);
		Boolean isSuccess=eventResult.IsSuccessfulEvent();
		System.out.println(isSuccess);

		return "Message sent to the Kafka Topic java_in_use_topic Successfully";
	}

	
	@GetMapping(value = "/hello")
	public String hello() {
		return "hello world";
	}

}