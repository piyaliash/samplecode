package com.ubs.eisl.notification.eventnotificationint.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import com.ubs.eisl.notifcation.core.integration.consumer.EventMessageListener;

@Service
public class Receiver {

    private static final Logger LOG = LoggerFactory.getLogger(Receiver.class);

    @EventMessageListener(topics = "test-topic" , groupId = "group_id")
    public void listen(@Payload String message) {
        LOG.info("received message='{}'", message);
    }

}