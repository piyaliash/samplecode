package com.ubs.eisl.notifcation.core.integration.consumer;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import org.springframework.core.annotation.AliasFor;
import org.springframework.kafka.annotation.KafkaListener;

@Target({ElementType.ANNOTATION_TYPE,ElementType.TYPE, ElementType.FIELD, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@KafkaListener
public @interface EventMessageListener {
  
	@AliasFor(annotation = KafkaListener.class, attribute = "topics") String[] topics() default {};
	@AliasFor(annotation = KafkaListener.class, attribute = "groupId") String groupId() default "";

}