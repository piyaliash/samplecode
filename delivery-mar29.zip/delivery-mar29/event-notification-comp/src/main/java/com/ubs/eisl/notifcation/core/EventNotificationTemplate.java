package com.ubs.eisl.notifcation.core;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ubs.eisl.notifcation.core.integration.producer.Sender;
import com.ubs.eisl.notifcation.core.vos.EventInfo;
import com.ubs.eisl.notifcation.core.vos.EventResult;

/**
 * 
 *  
 * Notification Template is helper class for sending/posting messages to messaging system
 *
 */
@Component
public class EventNotificationTemplate {
	
	private static final Logger LOG = LoggerFactory.getLogger(EventNotificationTemplate.class);
	
	@Autowired
	private Sender sender;
	
	
	/**
	 * Post Event Details
	 * @param eventInfo
	 * @return eventResult
	 */
	public EventResult postEvent(EventInfo eventInfo) {
		LOG.debug("eventInfo {}",eventInfo);
		
		EventResult eventResult=new EventResult();
		sender.send(eventInfo.getEislToken(),eventInfo.getTopicName());
		eventResult.setIsSuccessfulEvent(true);
		
		LOG.debug("eventResult: {}",eventResult);
		
		return eventResult;
	}
	
	
	/**
	 * Clear Event Details
	 * @param eventInfo
	 * @return eventResultSO
	 */
	public EventResult clearEvent(EventInfo eventInfo) {
		return null;
	}
}
