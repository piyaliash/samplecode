package com.ubs.eisl.notifcation.core.vos;

import java.io.Serializable;

public class EventInfo implements Serializable{


	private static final long serialVersionUID = 1L;
	
	private String topicName;
	
	private String eislToken;

	public String getTopicName() {
		return topicName;
	}

	public void setTopicName(String topicName) {
		this.topicName = topicName;
	}

	public String getEislToken() {
		return eislToken;
	}

	public void setEislToken(String eislToken) {
		this.eislToken = eislToken;
	}

  	@Override
    public String toString() {
        return new StringBuilder("topicName:").append(topicName)
         .append(",eislToken:").append(eislToken).toString();
    }
	
}
