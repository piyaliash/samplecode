package com.ubs.eisl.notifcation.core.vos;

import java.io.Serializable;

public class EventResult implements Serializable {

	private static final long serialVersionUID = 2L;
	
	private Long eventId;
	private String eventName;
	private Boolean isSuccessfulEvent;
	
	public Long getEventId() {
		return eventId;
	}

	public void setEventId(Long eventId) {
		this.eventId = eventId;
	}
	
	public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}


	
	public Boolean IsSuccessfulEvent() {
		return isSuccessfulEvent;
	}

	public void setIsSuccessfulEvent(Boolean isSuccessfulEvent) {
		this.isSuccessfulEvent = isSuccessfulEvent;
	}

	

    @Override
    public String toString() {
        return new StringBuilder("eventId:").append(eventId)
        		.append(",eventName:").append(eventName)
                .append(",isSuccssfulEvent:").append(isSuccessfulEvent).toString();
    }
	
	


}
