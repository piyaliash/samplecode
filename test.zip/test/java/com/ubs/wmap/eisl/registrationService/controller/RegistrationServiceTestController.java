/*
package com.ubs.wmap.eisl.registrationService.controller;


import com.ubs.wmap.eisl.housekeeping.TokenService;
import com.ubs.wmap.eisl.registrationService.RegistrationServiceApplicationTests;
import com.ubs.wmap.eisl.registrationService.exception.EsilTokenNotValidException;
import com.ubs.wmap.eisl.registrationService.exception.InvalidDataException;
import com.ubs.wmap.eisl.registrationService.model.PayloadSO;
import com.ubs.wmap.eisl.registrationService.model.ResponseSO;
import com.ubs.wmap.eisl.registrationService.service.RegistrationServiceImpl;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;


public class RegistrationServiceTestController{

    @Mock
    RestTemplate restTemplate;

    @Mock
    TokenService tokenService;

    @Mock
    RegistrationServiceImpl registrationService;


    @InjectMocks
    RegistrationServiceController registrationServiceController;



    @Before
    public void setUp() throws Exception {

        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void getRegistry() throws EsilTokenNotValidException, InvalidDataException {
        String eislToken="Testeisl";
        String basicToken="Testbasic";
        String companyName="Testcompany";
        String userName="Testuser";
        PayloadSO payloadSO = new PayloadSO();
        payloadSO.setUserName("abd");
        payloadSO.setCompany("abd");
        ResponseSO responseSO = new ResponseSO();
        boolean testdata=true;
       //String token= tokenService.init("test","1","testRole");
        //Mockito.when(registrationService.getRegistration(basicToken,eislToken,payloadSO)).thenReturn(responseSO);
        Mockito.when(registrationService.validateToken(basicToken,eislToken)).thenReturn(testdata);
        ResponseEntity responseEntity= registrationServiceController.getRegistry(eislToken,basicToken,companyName,userName);


        responseEntity.getStatusCodeValue();

    }
}
*/
