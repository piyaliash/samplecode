# security-entitlement-service

# Application startup

Application properties file should be provided
In case of usage application-local.yml properties file (based on application-local.yml.sample file) local runtime profile should be enabled: java -Dspring.profiles.active=local ...

# Genreate Private public key

openssl genrsa -out private_key.pem 4096
openssl rsa -pubout -in private_key.pem -out public_key.pem

# convert private key to pkcs8 format in order to import it from Java
openssl pkcs8 -topk8 -in private_key.pem -inform pem -out private_key_pkcs8.pem -outform pem -nocrypt
