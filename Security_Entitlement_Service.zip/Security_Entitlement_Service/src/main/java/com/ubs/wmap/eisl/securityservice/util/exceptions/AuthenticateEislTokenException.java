package com.ubs.wmap.eisl.securityservice.util.exceptions;

public class AuthenticateEislTokenException  extends RuntimeException {

}