package com.ubs.wmap.eisl.inhousekeepinglibrary.util.exceptions;

public class AuthenticateEislTokenException  extends RuntimeException {

}