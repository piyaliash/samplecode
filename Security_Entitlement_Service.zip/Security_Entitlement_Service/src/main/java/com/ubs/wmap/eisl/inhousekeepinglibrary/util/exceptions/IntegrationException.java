package com.ubs.wmap.eisl.inhousekeepinglibrary.util.exceptions;

public class IntegrationException extends RuntimeException {
    public IntegrationException(String message) {
        super(message);
    }
}