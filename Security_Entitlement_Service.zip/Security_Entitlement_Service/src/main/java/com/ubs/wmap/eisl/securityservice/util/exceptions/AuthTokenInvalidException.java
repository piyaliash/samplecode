package com.ubs.wmap.eisl.securityservice.util.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(code = HttpStatus.FORBIDDEN, reason = "Invalid authorization token.")
public class AuthTokenInvalidException extends RuntimeException {


}