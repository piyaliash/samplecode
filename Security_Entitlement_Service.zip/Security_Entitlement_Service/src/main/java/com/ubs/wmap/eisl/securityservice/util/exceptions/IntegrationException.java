package com.ubs.wmap.eisl.securityservice.util.exceptions;

public class IntegrationException extends RuntimeException {
    public IntegrationException(String message) {
        super(message);
    }
}