package com.ubs.wmap.eisl.securityservice.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.io.Serializable;
import java.util.Map;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class EislTokenModel implements Serializable {

    private Map<String, Object> claims;
    private String validationStatus;

}
