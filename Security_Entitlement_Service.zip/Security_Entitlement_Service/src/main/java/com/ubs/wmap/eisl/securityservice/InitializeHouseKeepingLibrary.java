package com.ubs.wmap.eisl.securityservice;

import com.ubs.wmap.eisl.securityservice.controller.exceptions.AuthTokenInvalidException;
import com.ubs.wmap.eisl.securityservice.controller.exceptions.IntegrationException;
import com.ubs.wmap.eisl.securityservice.service.TokenService;
import io.jsonwebtoken.Claims;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.util.Map;

@Component
@Slf4j
public class InitializeHouseKeepingLibrary {



    @Autowired
    TokenService tokenService;
    @Value("${service.jwt.eisl.userNameClaim}")
    private String userNameClaim;
    @Value("${service.jwt.eisl.serviceIdClaim}")
    private String serviceIdClaim;

    public String init(String basicToken, String eislToken, Map<String, String> claims){
        try {
            if (tokenService.isBasicTokenValid(basicToken)) {
                if (tokenService.isEislTokenNotValid(eislToken)) {
                    if (!StringUtils.isEmpty(claims.get("serviceIdClaim")) && !StringUtils.isEmpty(claims.get("userNameClaim"))) {
                        eislToken = tokenService.buildEislToken(claims.get("userNameClaim"), claims.get("serviceIdClaim"));
                    } else if (StringUtils.isEmpty(claims.get("serviceIdClaim")) || StringUtils.isEmpty(claims.get("userNameClaim"))) {
                        throw new AuthTokenInvalidException();
                    }
                }
            } else {
                throw new AuthTokenInvalidException();
            }


        }catch (Exception ex){
            throw new AuthTokenInvalidException();
        }
        return eislToken;
    }

    /*public void init(String basicToken, Map<String, String> claims,boolean callRegistry){

    }

    public void init(String basicToken, String eislToken, boolean callRegistry){

    }*/

}
