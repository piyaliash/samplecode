/*
package com.ubs.wmap.eisl.securityservice.controller;

import com.ubs.wmap.eisl.securityservice.controller.exceptions.AuthTokenInvalidException;
import com.ubs.wmap.eisl.securityservice.service.TokenService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.NotBlank;
import java.util.HashMap;

@Slf4j
@AllArgsConstructor(onConstructor = @__(@Autowired))
@Validated
@RestController
@RequestMapping(value = "/security", produces = "application/json")
public class ValidationController {

    private final TokenService tokenService;

    @GetMapping("/validate")
    public ResponseEntity<Object> generate(@NotBlank @RequestHeader(name = "Authorization") final String authHeader,
                                           @NotBlank @RequestParam final String token) {

        String basicToken = trimAuthorizationSchema(authHeader);
        basicTokenPreconditions(basicToken);
        return ResponseEntity.ok()
                .body(new HashMap<>(tokenService.unwrapEislToken(token)));
    }

    public void basicTokenPreconditions(String basicToken) {
        if (tokenService.isBasicTokenNotValid(basicToken)) {
            log.warn("Invalid authorization token: {}", basicToken);
            throw new AuthTokenInvalidException();
        }
    }

    private String trimAuthorizationSchema(String authorizationHeader) {
        return authorizationHeader.replaceAll("^Bearer ", "");
    }
}



*/
