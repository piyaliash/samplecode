/*
package com.ubs.wmap.eisl.securityservice.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableConfigurationProperties
@ConfigurationProperties("eisl")
public class EislConfig {

    private long tokenExpireDuration;

    public EislConfig() {
    }

    @Override
    public java.lang.String toString() {
        return "EislConfig{" +
                "tokenExpireDuration=" + tokenExpireDuration +
                '}';
    }


    public long getTokenExpireDuration() {
        return tokenExpireDuration;
    }

    public void setTokenExpireDuration(long tokenExpireDuration) {
        this.tokenExpireDuration = tokenExpireDuration;
    }
}
*/
