package com.ubs.wmap.eisl.securityservice.component;

import com.ubs.wmap.eisl.securityservice.util.exceptions.AuthTokenInvalidException;
import com.ubs.wmap.eisl.securityservice.util.exceptions.AuthenticateEislTokenException;
import com.ubs.wmap.eisl.securityservice.service.TokenService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.util.Map;

@Component
public class InitializeHouseKeepingLibrary {



    @Autowired
    TokenService tokenService;
    @Value("${service.jwt.eisl.userNameClaim}")
    private String userNameClaim;
    @Value("${service.jwt.eisl.serviceIdClaim}")
    private String serviceIdClaim;

    public String init(String basicToken, String eislToken, Map<String, String> claims){
        try {
           if(tokenService.isBasicTokenValid(basicToken)){
               if(tokenService.isEislTokenValid(eislToken)){
                   return eislToken;
               }
           }

        }catch (AuthenticateEislTokenException ex){
            if(!StringUtils.isEmpty(claims.get("userNameClaim"))||!StringUtils.isEmpty(claims.get("serviceIdClaim"))){
                eislToken=tokenService.buildEislToken(claims.get("userNameClaim"),claims.get("serviceIdClaim"));
            }else{
                throw new AuthTokenInvalidException();
            }
        }
        return eislToken;
    }


}
