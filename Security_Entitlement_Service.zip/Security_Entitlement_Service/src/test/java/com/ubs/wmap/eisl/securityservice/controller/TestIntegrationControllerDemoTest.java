/*
package com.ubs.wmap.eisl.securityservice.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ubs.wmap.eisl.securityservice.util.exceptions.TokenUnwrapException;
import com.ubs.wmap.eisl.securityservice.model.EislTokenModel;
import com.ubs.wmap.eisl.securityservice.service.TokenServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.*;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.util.UriComponentsBuilder;

import java.io.IOException;

import static org.junit.Assert.*;

@Slf4j
@ActiveProfiles("test")
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.DEFINED_PORT)
public class TestIntegrationControllerDemoTest {

    @Autowired
    TokenServiceImpl tokenService;



    @Autowired
    private ObjectMapper mapper;

    @LocalServerPort
    private int port;

    @Autowired
    private TestRestTemplate restTemplate;

    @Test
    public void shouldValidateClaims() throws Exception {
        String userName = "john";
        String password = "superPassword";
        String serviceId = "create_account";

        String uri = UriComponentsBuilder.fromHttpUrl("http://localhost:" + port + "/demo/security")
                .queryParam("userName", userName)
                .queryParam("password", password)
                .queryParam("serviceId", serviceId)
                .toUriString();

        ResponseEntity<String> response = this.restTemplate.getForEntity(uri, String.class);

        log.info(response.getBody());

        assertEquals(HttpStatus.OK.value(), response.getStatusCodeValue());

        EislTokenModel model = mapper.readValue(response.getBody(), EislTokenModel.class);

        assertNotNull(model);
        assertNotNull(model.getClaims());
        assertNotNull(model.getValidationStatus());
        assertFalse(model.getClaims().isEmpty());
        assertFalse(model.getValidationStatus().isEmpty());
        assertEquals("success", model.getValidationStatus());
    }

    @Test
    public void shouldReturnUnwrappingEception() throws IOException {

        String basicToken = tokenService.buildBasicToken("utkarsh", "password");
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer " + basicToken);
        HttpEntity<String> request = new HttpEntity<String>(headers);

        String uri = UriComponentsBuilder.fromHttpUrl("http://localhost:" + port + "/security/validate")
                .queryParam("token", "some.dummy.value")
                .toUriString();

        ResponseEntity<String> response = this.restTemplate.exchange(uri, HttpMethod.GET, request, String.class);

        log.info("Server response on Error : {}", response.getBody());

        assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatusCodeValue());

        EislTokenModel model = mapper.readValue(response.getBody(), EislTokenModel.class);
        assertTrue(response.getBody().indexOf("Exception during JWT token unwrapping") >=0);
}

    @Test (expected = TokenUnwrapException.class)
    public void checkTokenPreCondition() throws IOException {


        validationController.basicTokenPreconditions("I am rubbish");
        log.info("Pass - Invalid basic token - TokenUnwrapException must be thrown");

    }

}
*/
