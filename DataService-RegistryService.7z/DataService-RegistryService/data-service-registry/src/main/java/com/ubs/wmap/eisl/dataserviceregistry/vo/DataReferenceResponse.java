package com.ubs.wmap.eisl.dataserviceregistry.vo;

import java.io.Serializable;
import java.util.Set;
import lombok.Data;
import lombok.EqualsAndHashCode;
@Data
public class DataReferenceResponse implements Serializable {

	private static final long serialVersionUID = -598494958569462261L;
	
	private Integer dataReferenceId;
	private String dataServiceId;
	private String dataInTopic;
	@EqualsAndHashCode.Exclude
	private Set<DataOutReferenceResponse> dataOutReferences;
}
