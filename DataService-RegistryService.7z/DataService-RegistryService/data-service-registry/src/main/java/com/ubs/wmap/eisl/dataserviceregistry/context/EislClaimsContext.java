package com.ubs.wmap.eisl.dataserviceregistry.context;

import java.io.Serializable;
import io.jsonwebtoken.Claims;
import lombok.Data;

@Data
public class EislClaimsContext implements Serializable{
	
	private static final long serialVersionUID = 272397852480094863L;
	
	private Claims claims;
}
