package com.ubs.wmap.eisl.dataserviceregistry.model;

import java.io.Serializable;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(name = "DATA_OUT_REFERENCE")
public class DataOutReference implements Serializable{

	private static final long serialVersionUID = 6524059507619584069L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "Data_out_reference_id")
	private Integer dataOutReferenceId;
	
	@Column(name = "Protocol_name")
	private String protocolName;
	
	@Column(name = "Data_type")
	private String dataType;
	
	@Column(name = "topic")
	private String topic;
	
	@EqualsAndHashCode.Exclude
	@ManyToOne
	@JoinColumn(name="Data_reference_id", nullable=false)
	private DataReference dataOutReference;
	
	@EqualsAndHashCode.Exclude
	@OneToOne(mappedBy = "dataOutReference", cascade = CascadeType.ALL,
            fetch = FetchType.LAZY, optional = false)
	private DataFilterReference dataFilterReference;
}
