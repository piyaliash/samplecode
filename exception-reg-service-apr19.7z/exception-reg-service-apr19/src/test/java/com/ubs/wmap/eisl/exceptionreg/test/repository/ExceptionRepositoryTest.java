package com.ubs.wmap.eisl.exceptionreg.test.repository;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.test.context.junit4.SpringRunner;

import com.ubs.wmap.eisl.exceptionreg.model.ExceptionData;
import com.ubs.wmap.eisl.exceptionreg.model.ExceptionReference;
import com.ubs.wmap.eisl.exceptionreg.repository.ExceptionDataRepository;
import com.ubs.wmap.eisl.exceptionreg.repository.ExceptionRefRepository;


@RunWith(SpringRunner.class)
@DataJpaTest
@EnableAutoConfiguration
@ComponentScan(basePackages = { "com.ubs.wmap.eisl.exceptionreg" })
public class ExceptionRepositoryTest {

	@Autowired
	private ExceptionRefRepository exceptionRefRepository;
	
	@Autowired
	private ExceptionDataRepository exceptionDataRepository;

	@Test
	public void testfindByExceptionServiceIdWithData() throws Exception {
		ExceptionReference values = exceptionRefRepository.findByExceptionServiceId(Integer.valueOf(1));
		assertNotNull(values);
	}
	
	
	@Test
	public void testfindByExceptionServiceIdWithOutData() throws Exception {
		ExceptionReference values = exceptionRefRepository.findByExceptionServiceId(Integer.valueOf(13));
		assertNull(values);
	}
	
	
	@Test
	public void testSaveExceptionReference() throws Exception {
		ExceptionReference entity=new ExceptionReference();
		entity.setCategory("category");
		entity.setSeverity("severity");
		entity.setExceptionTopic("topic");
		ExceptionData exceptionData =exceptionDataRepository.getOne(Long.valueOf("1"));
		entity.setExceptionData(exceptionData);
		ExceptionReference values = exceptionRefRepository.save(entity);
		assertNotNull(values);
	}

}
