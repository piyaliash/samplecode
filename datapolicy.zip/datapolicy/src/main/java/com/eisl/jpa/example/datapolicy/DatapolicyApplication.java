package com.eisl.jpa.example.datapolicy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DatapolicyApplication {

	public static void main(String[] args) {
		SpringApplication.run(DatapolicyApplication.class, args);
	}

}
