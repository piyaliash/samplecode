
package com.eisl.jpa.example.datapolicy.exception;

public class EislTokenInvalidException extends Exception{
    
    public EislTokenInvalidException(String message) {
        super(message);
    }
    
}
