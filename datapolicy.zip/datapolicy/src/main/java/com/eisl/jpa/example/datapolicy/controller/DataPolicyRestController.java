
package com.eisl.jpa.example.datapolicy.controller;

import com.eisl.jpa.example.datapolicy.exception.EislTokenInvalidException;
import com.eisl.jpa.example.datapolicy.model.DataPolicy;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import com.eisl.jpa.example.datapolicy.service.DataPolicyService;
import javax.validation.constraints.NotBlank;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;


@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@RestController
@RequestMapping(value = "/eisl/datapolicy/v1/", produces = "application/json")
public class DataPolicyRestController {
    
 private final DataPolicyService employeeService;

 
 @Value("${app.message.INTERNAL_SERVER_ERROR_MSG}")
	private String INTERNAL_SERVER_ERROR_MSG;
 
 @Value("${app.message.EISL_INVALID_TOKEN_MSG}")
	private String EISL_INVALID_TOKEN_MSG;
 
 @GetMapping("/datapolicies/fetchall")
 public List<DataPolicy> getEmployees(@NotBlank @RequestParam("token") final String eislToken) {
  List<DataPolicy> employees = employeeService.loadAll();
  return employees;
 }
  
 @GetMapping("/datapolicies/{policyId}")
 public DataPolicy getEmployee(@NotBlank @RequestParam("token") final String eislToken,
         @PathVariable(name="policyId") Long policyId) {
  return employeeService.getDataPolicy(policyId);
 }
 
  @GetMapping("/datapolicies")
 public DataPolicy getEmployee(@NotBlank @RequestParam("token") final String eislToken,
         @RequestParam(value="modelname", required = false) final String modelName,
         @RequestParam(value="applicationid", required = false) final String applicationId) {
  return employeeService.getDataPolicy(Long.valueOf("2234"));
 }
 
   
 }
    
