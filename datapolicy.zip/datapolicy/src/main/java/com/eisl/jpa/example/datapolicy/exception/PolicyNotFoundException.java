
package com.eisl.jpa.example.datapolicy.exception;

public class PolicyNotFoundException extends Exception{
    
    public PolicyNotFoundException(String message) {
        super(message);
    }
    
}
