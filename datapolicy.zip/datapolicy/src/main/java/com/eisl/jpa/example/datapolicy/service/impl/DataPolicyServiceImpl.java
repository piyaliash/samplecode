/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.eisl.jpa.example.datapolicy.service.impl;

import com.eisl.jpa.example.datapolicy.model.DataPolicy;
import com.eisl.jpa.example.datapolicy.repository.EmployeeRepository;
import com.eisl.jpa.example.datapolicy.service.DataPolicyService;
import java.util.List;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author utkar
 */
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@Service
public class DataPolicyServiceImpl implements DataPolicyService{
    
    private final EmployeeRepository employeeRepository;
  
 public List<DataPolicy> loadAll() {
  List<DataPolicy> employees = employeeRepository.findAll();
  return employees;
 }
  
 public DataPolicy getDataPolicy(Long employeeId) {
  Optional<DataPolicy> optEmp = employeeRepository.findById(employeeId);
  return optEmp.get();
 }
    
}
