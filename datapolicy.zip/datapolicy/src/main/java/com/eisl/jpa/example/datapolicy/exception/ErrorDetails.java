package com.eisl.jpa.example.datapolicy.exception;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.time.LocalDateTime;
import lombok.Data;

@Data
public class ErrorDetails {
    private String message;
    private String details;
    
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy hh:mm:ss")
    private LocalDateTime timeStamp;
    
    public ErrorDetails(String message, String details) {
        super();
        this.timeStamp = LocalDateTime.now();
        this.message = message;
        this.details = details;
    }
}
