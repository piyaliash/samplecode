package com.eisl.jpa.example.datapolicy.model;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

@Data
@Entity
@Table(name = "DATAPOLICY")
public class DataPolicy {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "DATA_POLICY_ID")
    private Long policyId;

    @Column(name = "POLICY_TYPE_NAME")
    private String policyName;

    @Column(name = "POLICY_TYPE_ID")
    private Long policyTypeId;

    @Column(name = "MODEL_NAME")
    private String modelName;

    @Column(name = "APPLICATION_ID")
    private Long applicationId;

    @Column(name = "TIME_TO_KEEP_IN_MONTHS")
    private String timeToKeepInMonths;

    @Column(name = "CREATED_BY", nullable = false, updatable = false)
    private String createdBy;

    @Column(name = "LAST_UPDATED_BY")
    private String lastUpdatedBy;

    @Column(name = "CREATION_DATE", nullable = false, updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createdDate;

    @Column(name = "LAST_UPDATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    @LastModifiedDate
    private Date lastUpdatedDate;

}
