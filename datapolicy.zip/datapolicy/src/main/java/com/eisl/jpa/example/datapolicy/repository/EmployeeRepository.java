/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.eisl.jpa.example.datapolicy.repository;

import com.eisl.jpa.example.datapolicy.model.DataPolicy;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 *
 * @author utkar
 */
@Repository
public interface EmployeeRepository extends JpaRepository<DataPolicy,Long>{
    
}
