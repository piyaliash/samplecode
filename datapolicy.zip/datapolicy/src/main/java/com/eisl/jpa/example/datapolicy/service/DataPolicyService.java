/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.eisl.jpa.example.datapolicy.service;

import com.eisl.jpa.example.datapolicy.model.DataPolicy;
import java.util.List;

/**
 *
 * @author utkar
 */
public interface DataPolicyService {
    public List<DataPolicy> loadAll();
  
 public DataPolicy getDataPolicy(Long employeeId);
 
}
