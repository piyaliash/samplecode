package com.ubs.eisl.ms.event.test.controller;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.ubs.eisl.ms.event.controller.EventController;
import com.ubs.eisl.ms.event.exception.EventNotFoundException;
import com.ubs.eisl.ms.event.services.sos.EventResponseSO;

@RunWith(SpringRunner.class)
@DataJpaTest
@EnableAutoConfiguration
@ComponentScan(basePackages = { "com.ubs.eisl.ms.event" })
public class EventControllerTest {

	@Autowired
	private EventController eventController;

	@Test
	public void eventControllerDataTest() throws Exception {

		ResponseEntity<EventResponseSO> responseEntity = eventController.getEventDetails("1");
		assertNotNull(responseEntity);
	}

	@Test
	public void eventControllerWithoutDataTest() throws Exception {
		try {
			ResponseEntity<EventResponseSO> responseEntity = eventController.getEventDetails("3");
			assertNotNull(responseEntity);
		} catch (EventNotFoundException ex) {
			assertTrue(true);
		}
	}

}
