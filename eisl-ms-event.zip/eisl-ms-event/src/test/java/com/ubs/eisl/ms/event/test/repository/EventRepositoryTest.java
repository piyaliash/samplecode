package com.ubs.eisl.ms.event.test.repository;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.test.context.junit4.SpringRunner;

import com.ubs.eisl.ms.event.domain.Events;
import com.ubs.eisl.ms.event.repository.EventRepository;

@RunWith(SpringRunner.class)
@DataJpaTest
@EnableAutoConfiguration
@ComponentScan(basePackages = { "com.ubs.eisl.ms.event" })
public class EventRepositoryTest {

	@Autowired
	private EventRepository eventRepository;

	@Test
	public void testfindByServiceIdWithData() throws Exception {
		Events values = eventRepository.findByServiceId("1");
		assertNotNull(values);
	}
	
	
	@Test
	public void testfindByServiceIdWithOutData() throws Exception {
		Events values = eventRepository.findByServiceId("3");
		assertNull(values);
	}

}
