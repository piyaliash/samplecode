package com.ubs.eisl.ms.event.exception;

public class EventNotFoundException extends RuntimeException{
	
	private static final long serialVersionUID = -7408420202454263359L;

	public EventNotFoundException(String message) {
		super(message);
	}

}
