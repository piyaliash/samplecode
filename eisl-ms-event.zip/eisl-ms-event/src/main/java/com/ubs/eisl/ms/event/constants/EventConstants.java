package com.ubs.eisl.ms.event.constants;

public final class EventConstants {
	
	private EventConstants() {
	}

	public static final String EVENT_NOT_FOUND_MSG="Event Not found for given ";
	
	public static final String INTERNAL_SERVER_ERROR_MSG="Internal server error occured ";
	
	public static final String EVENT_GET_ENDPOINT="/eisl/data/v1/data";
}
