package com.ubs.eisl.ms.event.controller;

import static com.ubs.eisl.ms.event.constants.EventConstants.EVENT_NOT_FOUND_MSG;
import static com.ubs.eisl.ms.event.constants.EventConstants.INTERNAL_SERVER_ERROR_MSG;
import static com.ubs.eisl.ms.event.constants.EventConstants.EVENT_GET_ENDPOINT;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ubs.eisl.ms.event.controller.delegates.EventDelegate;
import com.ubs.eisl.ms.event.exception.EventException;
import com.ubs.eisl.ms.event.exception.EventNotFoundException;
import com.ubs.eisl.ms.event.services.sos.EventRequestSO;
import com.ubs.eisl.ms.event.services.sos.EventResponseSO;

@RestController
public class EventController extends BaseController {

	private static final Logger LOG = LoggerFactory.getLogger(EventController.class);
	
	@Autowired
	private EventDelegate eventDelegate;
	
	
	@RequestMapping(value = EVENT_GET_ENDPOINT, method = RequestMethod.GET)
	public ResponseEntity<EventResponseSO> getEventDetails(@RequestParam("token") String token)
			throws EventException {
		LOG.debug("token:{}",token);
		EventResponseSO eventResponseSO = null;

		try {
			/** TO DO Get service id from **/
			String serviceId="1";
			eventResponseSO = eventDelegate.getEventDetails(constructEvenRequestSO(serviceId));
			if (eventResponseSO == null) {
				throw new EventNotFoundException(EVENT_NOT_FOUND_MSG + serviceId);
			}

		} catch (EventException eventException) {
			LOG.error( eventException.getMessage(), eventException);
			throw new EventException(INTERNAL_SERVER_ERROR_MSG);
		}

		return ResponseEntity.ok(eventResponseSO);
	}

	/**
	 * This is just for testing and has to be remove
	 */
	@RequestMapping(value = "/event/{serviceId}", method = RequestMethod.GET)
	public ResponseEntity<EventResponseSO> getEventDetails1(@PathVariable("serviceId") String serviceId)
			throws EventException {
		EventResponseSO eventResponseSO = null;

		try {
			eventResponseSO = eventDelegate.getEventDetails(constructEvenRequestSO(serviceId));
			if (eventResponseSO == null) {
				throw new EventNotFoundException(EVENT_NOT_FOUND_MSG + serviceId);
			}

		} catch (EventException eventException) {
			LOG.error( eventException.getMessage(), eventException);
			throw new EventException(INTERNAL_SERVER_ERROR_MSG);
		}

		return ResponseEntity.ok(eventResponseSO);
	}

	private EventRequestSO constructEvenRequestSO(String serviceId) {
		EventRequestSO eventRequestSO = new EventRequestSO();
		eventRequestSO.setServiceId(serviceId);
		return eventRequestSO;
	}

}
