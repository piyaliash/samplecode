package com.ubs.wmap.eisl.registrationService.DTO;

import lombok.Data;

@Data
public class ResponseDTO {
	
	private String userName;
	private String userId;
	private String company;
	private String eislToken;
	private long serviceId;
	private String columnRef;
	private String rowRef;
	private String dataEntitlement;

	private String respString;

	
	
	
	
}

