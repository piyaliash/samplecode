package com.ubs.wmap.eisl.registrationService.controller;


import org.springframework.beans.factory.annotation.Autowired;
import static com.ubs.wmap.eisl.registrationService.constants.RegistrationConstants.REGISTRATION_END_POINT;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.ubs.wmap.eisl.registrationService.DTO.ResponseDTO;
import com.ubs.wmap.eisl.registrationService.service.RegistrationServiceImpl;

import javax.validation.constraints.NotBlank;


@RestController
@RequestMapping(value = "/eisl/registration/v1", produces = "application/json")
public class RegistrationServiceController {
	
	
	@Autowired
	private RegistrationServiceImpl registrationService;
	
	@RequestMapping(value = REGISTRATION_END_POINT, method= RequestMethod.GET)
    public ResponseEntity<ResponseDTO> getRegistry(@NotBlank @RequestHeader(name = "BasicToken") final String basicToken,
                                           @NotBlank @RequestParam final String eislToken,@NotBlank @RequestParam final String userId, @NotBlank @RequestParam final String serviceId) {
		boolean valid = registrationService.validateToken(basicToken, eislToken, null);	
    	if(!valid)
    	{
    		return ResponseEntity.badRequest().body(null);
    	}
    	ResponseDTO dto=registrationService.getRegistration(basicToken, eislToken);    	
        return ResponseEntity.ok()
                .body(dto);
    }

    @RequestMapping(value = REGISTRATION_END_POINT, method= RequestMethod.POST)
    public ResponseEntity<ResponseDTO> addRegistry(@NotBlank @RequestHeader(name = "BasicToken") final String basicToken,
                                              @NotBlank @RequestParam final String eislToken,@NotBlank @RequestParam final String userId, @NotBlank @RequestParam final String serviceId) {
    	boolean valid = registrationService.validateToken(basicToken, eislToken, null);	
    	if(!valid)
    	{
    		return ResponseEntity.badRequest().body(null);
    	}  	
    	ResponseDTO dto=registrationService.getRegistration(basicToken, eislToken);    	
        return ResponseEntity.ok()
                .body(dto);
    }
    
    @RequestMapping(value = REGISTRATION_END_POINT, method= RequestMethod.PUT)
    public ResponseEntity<Object> updateRegistry(@NotBlank @RequestHeader(name = "BasicToken") final String basicToken,
                                              @NotBlank @RequestParam final String eislToken,@NotBlank @RequestParam final String userId, @NotBlank @RequestParam final String serviceId) {
    	boolean valid = registrationService.validateToken(basicToken, eislToken, null);	
    	if(!valid)
    	{
    		return ResponseEntity.badRequest().body(null);
    	}  	
    	ResponseDTO dto=registrationService.getRegistration(basicToken, eislToken);    	
        return ResponseEntity.ok()
                .body(dto);
    }

    
    
    @RequestMapping(value = REGISTRATION_END_POINT, method= RequestMethod.DELETE)
    public ResponseEntity<Object> deleteRegistry(@NotBlank @RequestHeader(name = "BasicToken") final String basicToken, @NotBlank @RequestParam final String eislToken) {
    	boolean valid = registrationService.validateToken(basicToken, eislToken, null);	
    	if(!valid)
    	{
    		return ResponseEntity.badRequest().body(null);
    	}
        return ResponseEntity.ok()
                .body(registrationService.deleteRegistration("user/v1/registrations", basicToken, eislToken));
    }
}
