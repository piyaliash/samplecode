package com.ubs.wmap.eisl.registryaccessservice.util;

import org.springframework.stereotype.Component;

import com.ubs.wmap.eisl.registryaccessservice.context.EislClaimsContext;
import com.ubs.wmap.eisl.registryaccessservice.context.EislClaimsContextHolder;

import io.jsonwebtoken.Claims;

@Component
public class EislClaimsContextUtil {
	
	public Object getContextParam(String param) {
		EislClaimsContext eislClaimsContext=EislClaimsContextHolder.get();
		Claims claims=eislClaimsContext.getClaims();
		if(claims==null) return null;	
		
		return claims.get(param);
	}
	
	public Claims getClaims() {
		EislClaimsContext eislClaimsContext=EislClaimsContextHolder.get();
		if(eislClaimsContext==null) return null;
		
		Claims claims=eislClaimsContext.getClaims();
		if(claims==null) return null;	
		
		return claims;
	}

}
