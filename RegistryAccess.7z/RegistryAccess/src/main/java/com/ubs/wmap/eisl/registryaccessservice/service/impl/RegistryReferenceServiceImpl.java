package com.ubs.wmap.eisl.registryaccessservice.service.impl;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import javax.transaction.Transactional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.ubs.wmap.eisl.registryaccessservice.exception.RegistryReferenceException;

import com.ubs.wmap.eisl.registryaccessservice.model.ColumnReference;
import com.ubs.wmap.eisl.registryaccessservice.model.Registration;
import com.ubs.wmap.eisl.registryaccessservice.model.Roles;
import com.ubs.wmap.eisl.registryaccessservice.model.RowReference;
import com.ubs.wmap.eisl.registryaccessservice.repository.ColumnReferenceRepository;
import com.ubs.wmap.eisl.registryaccessservice.repository.RegistrationRepository;
import com.ubs.wmap.eisl.registryaccessservice.repository.RoleRepository;
import com.ubs.wmap.eisl.registryaccessservice.repository.RowReferenceRepository;
import com.ubs.wmap.eisl.registryaccessservice.service.RegistryReferenceService;
import com.ubs.wmap.eisl.registryaccessservice.vo.ColumnReferenceRequestVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.ColumnReferenceResponseVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.RegistrationRequestVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.RegistrationResponseVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.RegistryAccessRequestVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.RoleRequestVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.RoleResponseVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.RowReferenceRequestVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.RowReferenceResponseVO;
import lombok.extern.slf4j.Slf4j;

/**
 * @author Gananath
 *
 */
@Service
@Slf4j
//@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class RegistryReferenceServiceImpl implements RegistryReferenceService {
	@Autowired
	private RegistrationRepository registrationRepository;
	@Autowired
	private ColumnReferenceRepository columnRefRepo;
	@Autowired
	private RowReferenceRepository rowRefRepo;
	@Autowired
	private RoleRepository roleRepo;
	
	@Override
	public RegistrationResponseVO getRegistryReference(RegistryAccessRequestVO registryAccessRequestVO)
			throws RegistryReferenceException {

		log.debug("Service Enter:Inside getDataReference");
		log.debug("DataReferenceRequest : {}", registryAccessRequestVO);

		RegistrationResponseVO response = null;
		Registration registration = registrationRepository.findByServiceId(registryAccessRequestVO.getServiceId());
		if (registration != null) {
			response = constructDataReference(registration);
			if(registration.getColumnReferences()!=null)
			response.setColumnReferences(constructColumnReferences(registration.getColumnReferences()));
			if(registration.getRowReferences()!=null)
			response.setRowReferences(constructRowReferences(registration.getRowReferences()));
			if(registration.getRole()!=null)
			response.setRole(constructRoleReferences(registration.getRole()));
			
		}
		log.debug("DataReferenceResponse : {}", response);
		log.debug("Service Exit:Exiting getDataReference");
		return response;

	}
	
	private RoleResponseVO constructRoleReferences(Roles roles) {
		RoleResponseVO roleResponseVO = constructRole(roles);		
		return roleResponseVO;
	}
	
	private RoleResponseVO constructRole(Roles roles) {
		RoleResponseVO roleResponseVO = new RoleResponseVO();
		BeanUtils.copyProperties(roles, roleResponseVO);
		return roleResponseVO;
	}
	

	private Set<ColumnReferenceResponseVO> constructColumnReferences(Set<ColumnReference> columnReferences) {
		Set<ColumnReferenceResponseVO> columnRefSet = new HashSet<>();
		for (ColumnReference columnReference : columnReferences) {
			ColumnReferenceResponseVO constructColumnReference = constructColumnReference(columnReference);
			
			columnRefSet.add(constructColumnReference);
		}
		return columnRefSet;
	}
	
	
	private ColumnReferenceResponseVO constructColumnReference(ColumnReference columnReference) {
		ColumnReferenceResponseVO columnReferenceResponseVO = new ColumnReferenceResponseVO();
		BeanUtils.copyProperties(columnReference, columnReferenceResponseVO);
		return columnReferenceResponseVO;
	}
	
	private Set<RowReferenceResponseVO> constructRowReferences(Set<RowReference> rowReferences) {
		Set<RowReferenceResponseVO> rowRefSet = new HashSet<>();
		for (RowReference rowReference : rowReferences) {
			RowReferenceResponseVO constructRowReference = constructRowReference(rowReference);
			rowRefSet.add(constructRowReference);
		}
		return rowRefSet;
	}
	
	private RowReferenceResponseVO constructRowReference(RowReference rowReference) {
		RowReferenceResponseVO rowReferenceResponseVO = new RowReferenceResponseVO();
		BeanUtils.copyProperties(rowReference, rowReferenceResponseVO);
		return rowReferenceResponseVO;
	}	

	private RegistrationResponseVO constructDataReference(Registration registration) {
		RegistrationResponseVO registrationResponseVO = new RegistrationResponseVO();
		BeanUtils.copyProperties(registration, registrationResponseVO);
		return registrationResponseVO;
	}

	@Transactional
	@Override
	public RegistrationResponseVO persistRegistry(RegistrationRequestVO registrationRequestVO)
			throws RegistryReferenceException {
		Registration registration = constructDataRegistrationEntityFromVO(registrationRequestVO);
		registration.setColumnReferences(null);
		registration.setRowReferences(null);
		registrationRepository.save(registration);
		registrationRepository.flush();
		//Save Child
		RoleRequestVO roleRequestVO = registrationRequestVO.getRole();
		if (null != roleRequestVO) {
			Roles roles = constructRoleEntityFromVO(roleRequestVO);
			roles.setRegistration(registration);
			roleRepo.save(roles);
			registration.setRole(roles);
		}
		Set<ColumnReferenceRequestVO> columnReferenceRequestVOs = registrationRequestVO.getColumnReferences();
		if (!CollectionUtils.isEmpty(columnReferenceRequestVOs)) {
			for (ColumnReferenceRequestVO columnReferenceRequestVO : columnReferenceRequestVOs) {
				ColumnReference columnReference = constructColumnReferenceEntityFromVO(columnReferenceRequestVO);
				columnReference.setRegistration(registration);
				columnRefRepo.save(columnReference);
			}
		}
		Set<RowReferenceRequestVO> rowReferenceRequestVOs = registrationRequestVO.getRowReferences();
		if (!CollectionUtils.isEmpty(rowReferenceRequestVOs)) {
			for (RowReferenceRequestVO rowReferenceRequestVO : rowReferenceRequestVOs) {
				RowReference rowReference = constructRowReferenceEntityFromVO(rowReferenceRequestVO);
				rowReference.setRegistration(registration);
				rowRefRepo.save(rowReference);
			}
		}
		registrationRepository.refresh(registration);
		RegistrationResponseVO regResponse = null;
		Optional<Registration> regLatest = registrationRepository.findById(registration.getRegistrationId());
		if(regLatest.isPresent()) {
			Registration reg = regLatest.get();
			regResponse = constructDataReference(reg);
			if(null != reg.getRole()) {
				regResponse.setRole(constructRoleReferences(reg.getRole()));
			}
			if (null != reg.getColumnReferences()) {
				regResponse.setColumnReferences(constructColumnReferences(reg.getColumnReferences()));
			}
			if(null != reg.getRowReferences()) {
				regResponse.setRowReferences(constructRowReferences(reg.getRowReferences()));
			}
		}
		return regResponse;
	}

	private RowReference constructRowReferenceEntityFromVO(RowReferenceRequestVO rowReferenceRequestVO) {
		RowReference rowReference = new RowReference();
		BeanUtils.copyProperties(rowReferenceRequestVO, rowReference);
		return rowReference;
	}

	private ColumnReference constructColumnReferenceEntityFromVO(ColumnReferenceRequestVO columnReferenceRequestVO) {
		ColumnReference columnReference = new ColumnReference();
		BeanUtils.copyProperties(columnReferenceRequestVO, columnReference);
		return columnReference;
	}

	private Roles constructRoleEntityFromVO(RoleRequestVO roleRequestVO) {
		Roles roles = new Roles();
		BeanUtils.copyProperties(roleRequestVO, roles);
		return roles;
	}

	private Registration constructDataRegistrationEntityFromVO(RegistrationRequestVO registrationRequestVO) {
		Registration registration = new Registration();
		BeanUtils.copyProperties(registrationRequestVO, registration);
		return registration;
	}
}
