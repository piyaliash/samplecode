package com.ubs.wmap.eisl.registryaccessservice.exception;

public class RegistryAccessBadRequestException extends Exception {

	private static final long serialVersionUID = 6583675662971902101L;
	public RegistryAccessBadRequestException(String message) {
		super(message);
	}
	public RegistryAccessBadRequestException(Throwable cause) {
		super(cause);
	}
	public RegistryAccessBadRequestException(String message, Throwable cause) {
		super(message, cause);
	}
	@Override
	public String getMessage() {
		return super.getMessage();
	}
}
