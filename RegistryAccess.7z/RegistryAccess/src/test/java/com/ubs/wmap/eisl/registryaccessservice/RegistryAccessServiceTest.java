package com.ubs.wmap.eisl.registryaccessservice;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.util.HashSet;
import java.util.Set;

import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;

import com.ubs.wmap.eisl.registryaccessservice.exception.RegistryReferenceException;
import com.ubs.wmap.eisl.registryaccessservice.model.ColumnReference;
import com.ubs.wmap.eisl.registryaccessservice.model.Registration;
import com.ubs.wmap.eisl.registryaccessservice.model.Roles;
import com.ubs.wmap.eisl.registryaccessservice.model.RowReference;
import com.ubs.wmap.eisl.registryaccessservice.repository.RegistrationRepository;
import com.ubs.wmap.eisl.registryaccessservice.service.impl.RegistryReferenceServiceImpl;
import com.ubs.wmap.eisl.registryaccessservice.vo.ColumnReferenceResponseVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.RegistrationResponseVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.RegistryAccessRequestVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.RoleResponseVO;
import com.ubs.wmap.eisl.registryaccessservice.vo.RowReferenceResponseVO;

public class RegistryAccessServiceTest extends RegistryAccessServiceApplicationTests{
	
	@Mock
	private RegistrationRepository repo;
	
	@InjectMocks
	private RegistryReferenceServiceImpl registry;
	
	@Test
    public void getRegistryData() throws RegistryReferenceException {
		Registration reg = new Registration();
		reg.setRegistrationId(1L);
		reg.setServiceId("TestService1");
		reg.setEislToken("abcd");
		reg.setUserId("123");
		reg.setCompany("UBS");
		reg.setDataEntitlement("test");
		
		Roles roles = new Roles();
		roles.setRoleId(1L);
		roles.setConsume("TestConsume");
		roles.setPublish("publish");
		
		reg.setRole(roles);
		
		Set<ColumnReference> columnRef= new HashSet<>();
		
		ColumnReference colRef = new ColumnReference();
		colRef.setColumnReferenceId(1);
		colRef.setName("name");
		colRef.setType("type");
		columnRef.add(colRef);
		
		Set<RowReference> rowRefs= new HashSet<>();
		
		RowReference rowRef = new RowReference();
		rowRef.setRowReferenceId(1);
		rowRef.setName("reowName");
		rowRef.setType("rowType");
		
		rowRefs.add(rowRef);
		
		reg.setColumnReferences(columnRef);
		reg.setRowReferences(rowRefs);
		
		//Mock repo data
        Mockito.when(repo.findByServiceId("TestService1")).thenReturn(reg);
 
        //Request object
        RegistryAccessRequestVO request = new RegistryAccessRequestVO();
        request.setServiceId("TestService1");
        
        RegistrationResponseVO registryReference = registry.getRegistryReference(request);
       
        assertNotNull(registryReference);
        assertEquals("TestService1", registryReference.getServiceId());
        assertEquals("123", registryReference.getUserId());
        assertEquals("abcd", registryReference.getEislToken());
        assertEquals("UBS", registryReference.getCompany());
        assertEquals("test", registryReference.getDataEntitlement());
        
        RoleResponseVO role = registryReference.getRole();
        assertNotNull(role);
        
        assertEquals("TestConsume", role.getConsume());
        assertEquals("publish", role.getPublish());
        
        Set<ColumnReferenceResponseVO> columnReferences = registryReference.getColumnReferences();
        assertNotNull(columnReferences);
        assertEquals(1, columnReferences.size());
        for (ColumnReferenceResponseVO columnReferenceResponseVO : columnReferences) {
			assertNotNull(columnReferenceResponseVO);
			assertEquals("name", columnReferenceResponseVO.getName());
			assertEquals("type", columnReferenceResponseVO.getType());
		}
        
        Set<RowReferenceResponseVO> rowReferences = registryReference.getRowReferences();
        assertNotNull(rowReferences);
        assertEquals(1, rowReferences.size());
        for (RowReferenceResponseVO rowReferenceResponseVO : rowReferences) {
        	assertNotNull(rowReferenceResponseVO);
			assertEquals("reowName", rowReferenceResponseVO.getName());
			assertEquals("rowType", rowReferenceResponseVO.getType());
		}
        
        verify(repo, times(1)).findByServiceId("TestService1");
    }
}
