package com.ubs.wmap.eisl.inhousekeepinglibrary.util.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(code = HttpStatus.FORBIDDEN, reason = "Exception during Registry Access Service")
public class RegistryAccessException extends RuntimeException {

    public RegistryAccessException() {
        super();
    }

    public RegistryAccessException(Throwable cause) {
        super();
    }

    public RegistryAccessException(String message, Throwable cause) {
        super();
    }

}
