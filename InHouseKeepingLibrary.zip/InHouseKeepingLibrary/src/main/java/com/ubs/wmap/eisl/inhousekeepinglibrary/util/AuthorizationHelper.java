package com.ubs.wmap.eisl.inhousekeepinglibrary.util;


import com.ubs.wmap.eisl.inhousekeepinglibrary.util.exceptions.TokenUnwrapException;
import io.jsonwebtoken.*;
import org.springframework.stereotype.Component;

import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import java.util.Date;
import java.util.Map;
import java.util.UUID;

@Component
public class AuthorizationHelper {
    private static SignatureAlgorithm signatureAlgorithm = SignatureAlgorithm.RS256;

    // Public Key Encrypt but JWT Privat key to encrypt

    public String encryptJwtToken(Map input, String keyName, long expirationDelay) {

        PrivateKey privatekey = loadPrivateKey(keyName);

        long nowMillis = new Date().getTime();
        long expMillis = nowMillis + expirationDelay;

        Date exp = new Date(expMillis);
        JwtBuilder builder = Jwts.builder()
                .setClaims(input)
                .setId(UUID.randomUUID().toString())
                .signWith(signatureAlgorithm, privatekey)
                .setExpiration(exp);

        return builder.compact();
    }

    // Private Key Decrypt

    public Claims decryptJwtToken(String jwt, String keyName) {

        RSAPublicKey publicKey = (RSAPublicKey) loadPublicKey(keyName);
        Claims claims = null;
        try {

            claims = Jwts.parser()
                    .setSigningKey(publicKey)
                    .parseClaimsJws(jwt).getBody();
        } catch(ExpiredJwtException e) {
            throw new TokenUnwrapException("Token is expired", e);
        } catch (UnsupportedJwtException | MalformedJwtException | SignatureException | IllegalArgumentException e) {
            throw new TokenUnwrapException(e);
        }
        return claims;
    }

    public boolean isValidToken(String message, String keyName) {
        Claims claims = decryptJwtToken(message, keyName);
        return new Date().compareTo(claims.getExpiration()) < 0;
    }



    public PublicKey loadPublicKey(String keyName) {

        //File resource = null;
        String publicKeyContent = null;
        KeyFactory kf = null;
        RSAPublicKey pub = null;
        /*try {
            resource = new ClassPathResource(keyName).getFile();
        } catch (IOException e) {
            e.printStackTrace();
        }*/
        try {
            publicKeyContent = new String(keyName);
        } catch (Exception e) {
            e.printStackTrace();
        }

        publicKeyContent = publicKeyContent
                .replaceAll("\\r", "")
                .replaceAll("\\n", "")
                .replace("\\s+","")
                .replace("-----BEGIN PUBLIC KEY-----", "")
                .replace("-----END PUBLIC KEY-----", "");

        X509EncodedKeySpec ks = new X509EncodedKeySpec(Base64.getDecoder().decode(publicKeyContent));

        try {
            kf = KeyFactory.getInstance("RSA");
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }

        try {
            pub = (RSAPublicKey) kf.generatePublic(ks);
        } catch (InvalidKeySpecException e) {
            e.printStackTrace();
        }

        return pub;

    }

    public PrivateKey loadPrivateKey(String keyName) {

        //File resource = null;
        KeyFactory kf = null;
        String privateKeyContent = null;
        PrivateKey priv = null;

       /* try {
            resource = new ClassPathResource(keyName).getFile();
        } catch (IOException e) {
            e.printStackTrace();
        }*/
        try {
            privateKeyContent = new String(keyName);
        } catch (Exception e) {
            e.printStackTrace();
        }

        privateKeyContent = privateKeyContent
                .replaceAll("\\n", "")
                .replaceAll("\\r", "")
                .replace("\\s+","")
                .replace("-----BEGIN PRIVATE KEY-----", "")
                .replace("-----BEGIN RSA PRIVATE KEY-----", "")
                .replace("-----END PRIVATE KEY-----", "")
                .replace("-----END RSA PRIVATE KEY-----", "");

        PKCS8EncodedKeySpec ks = new PKCS8EncodedKeySpec(Base64.getDecoder().decode(privateKeyContent));

        try {
            kf = KeyFactory.getInstance("RSA");
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }

        try {
            priv = kf.generatePrivate(ks);
        } catch (InvalidKeySpecException e) {
            e.printStackTrace();
        }

        return priv;

    }
}