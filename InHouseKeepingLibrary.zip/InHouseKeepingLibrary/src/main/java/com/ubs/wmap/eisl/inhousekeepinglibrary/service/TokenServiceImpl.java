package com.ubs.wmap.eisl.inhousekeepinglibrary.service;

import java.util.HashMap;
import java.util.Map;

import javax.validation.constraints.NotBlank;

import com.ubs.wmap.eisl.inhousekeepinglibrary.component.EislTokenGenerator;
import com.ubs.wmap.eisl.inhousekeepinglibrary.util.exceptions.AuthenticateEislTokenException;
import com.ubs.wmap.eisl.inhousekeepinglibrary.util.exceptions.TokenUnwrapException;
import com.ubs.wmap.eisl.inhousekeepinglibrary.util.AuthorizationHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import io.jsonwebtoken.Claims;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@Validated
@Service
public class TokenServiceImpl implements TokenService {
    @Value("${service.jwt.tokenLifeTimeMls}")
    private long tokenLifeTimeMls;
    @Value("${service.jwt.eisl.userNameClaim}")
    private String userNameClaim;
    @Value("${service.jwt.eisl.serviceIdClaim}")
    private String serviceIdClaim;
    @Value("${service.jwt.basic.publicKeyName}")
    private String basicTokenPublicKeyName;
    @Value("${service.jwt.basic.privateKeyName}")
    private String basicTokenPrivateKeyName;
    @Value("${service.jwt.eisl.publicKeyName}")
    private String eislTokenPublicKeyName;
    @Value("${service.jwt.eisl.privateKeyName}")
    private String eislTokenPrivateKeyName;

    private final EislTokenGenerator eislTokenGenerator;
    private final AuthorizationHelper authorizationHelper;

    @Override
    public boolean isBasicTokenNotValid(@NotBlank String basicToken) {
        return !isBasicTokenValid(basicToken);
    }

    @Override
    public boolean isBasicTokenValid(@NotBlank String basicToken) {
        return authorizationHelper.isValidToken(basicToken, basicTokenPublicKeyName);
    }

    @Override
    public boolean isEislTokenNotValid(@NotBlank String eislToken) {
        return !isEislTokenValid(eislToken);
    }

    @Override
    public boolean isEislTokenValid(@NotBlank String eislToken) {
        try {
            return authorizationHelper.isValidToken(eislToken, eislTokenPublicKeyName);
        }catch(TokenUnwrapException ex){
            throw new AuthenticateEislTokenException();
        }
    }

    @Override
    public String buildBasicToken(@NotBlank String userName, @NotBlank String password) {
        Map<String, Object> inputParams = new HashMap<>();
        inputParams.put(userNameClaim, userName);
        return authorizationHelper.encryptJwtToken(inputParams, basicTokenPrivateKeyName, tokenLifeTimeMls);
    }

    @Override
    public Claims unwrapBasicToken(@NotBlank String token) {
        return authorizationHelper.decryptJwtToken(token, basicTokenPublicKeyName);
    }

    @Override
    public String buildEislToken(@NotBlank String userName, @NotBlank String serviceId) {

        Map<String, Object> eislClaims = new HashMap<>();
        eislClaims.put(userNameClaim, userName);
        eislClaims.put(serviceIdClaim, serviceId);

        Map<String, Object> eislClaim = eislTokenGenerator.getEislClaims(eislClaims);
        return authorizationHelper.encryptJwtToken(eislClaim, eislTokenPrivateKeyName, tokenLifeTimeMls);
    }

    @Override
    public Claims unwrapEislToken(@NotBlank String token) {
        return authorizationHelper.decryptJwtToken(token, eislTokenPublicKeyName);
    }
}