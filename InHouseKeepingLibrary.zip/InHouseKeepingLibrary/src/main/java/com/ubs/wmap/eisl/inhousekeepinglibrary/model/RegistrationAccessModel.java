package com.ubs.wmap.eisl.inhousekeepinglibrary.model;

import lombok.Data;

import java.io.Serializable;

@Data
public class RegistrationAccessModel implements Serializable {
    private String eislToken;
    private long serviceId;
    private String userId;
}
