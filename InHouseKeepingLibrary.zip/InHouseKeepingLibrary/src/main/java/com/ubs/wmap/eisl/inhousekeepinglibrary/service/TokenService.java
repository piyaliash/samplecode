package com.ubs.wmap.eisl.inhousekeepinglibrary.service;

import javax.validation.constraints.NotBlank;

import io.jsonwebtoken.Claims;

public interface TokenService {
    boolean isBasicTokenValid(@NotBlank String basicToken);
    boolean isBasicTokenNotValid(@NotBlank String basicToken);
    boolean isEislTokenNotValid(@NotBlank String eislToken);
    boolean isEislTokenValid(@NotBlank String eislToken);
    String buildBasicToken(@NotBlank String userName, @NotBlank String password);
    Claims unwrapBasicToken(@NotBlank String token);
    String buildEislToken(@NotBlank String userName, @NotBlank String serviceId);
    Claims unwrapEislToken(@NotBlank String token);
}