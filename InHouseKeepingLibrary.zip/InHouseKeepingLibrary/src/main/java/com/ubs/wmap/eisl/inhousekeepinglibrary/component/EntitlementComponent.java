package com.ubs.wmap.eisl.inhousekeepinglibrary.component;

import lombok.Data;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component
@Data
public class EntitlementComponent {
    private static Map entitlements = new HashMap();

    static {
        entitlements.put("ADMIN_PERMISSIONS", 636366);
        entitlements.put("READONLY_PERMISSIONS", 323312);
        entitlements.put("EDIT_PERMISSIONS", 145322);
        entitlements.put("FULL_ACCESS_PERMISSIONS", 987654);
    }


    public Map getEntitlementRoles(String uuname, String serviceName) {

        return entitlements;
    }

}
