package com.ubs.wmap.eisl.inhousekeepinglibrary.component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ubs.wmap.eisl.inhousekeepinglibrary.model.RegistrationAccessModel;
import com.ubs.wmap.eisl.inhousekeepinglibrary.util.exceptions.AuthTokenInvalidException;
import com.ubs.wmap.eisl.inhousekeepinglibrary.util.exceptions.AuthenticateEislTokenException;
import com.ubs.wmap.eisl.inhousekeepinglibrary.service.TokenService;
import com.ubs.wmap.eisl.inhousekeepinglibrary.util.exceptions.RegistryAccessException;
import com.ubs.wmap.eisl.inhousekeepinglibrary.util.exceptions.TokenUnwrapException;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

@Component
@Data
@Slf4j
public class InitializeHouseKeepingLibrary {



    @Autowired
    TokenService tokenService;


    @Value("${service.jwt.eisl.userNameClaim}")
    private String userNameClaim;
    @Value("${service.jwt.eisl.serviceIdClaim}")
    private String serviceIdClaim;
    @Value("${service.jwt.registryEndpointUrl}")
    private String registryEndpointUrl;

    public String init(String basicToken, String eislToken, Map<String, String> claims){
        try {
           if(tokenService.isBasicTokenValid(basicToken)){
               if(tokenService.isEislTokenValid(eislToken)){
                   return eislToken;
               }
           }

        }catch (AuthenticateEislTokenException authex){
            if(!StringUtils.isEmpty(claims.get("userNameClaim"))||!StringUtils.isEmpty(claims.get("serviceIdClaim"))){
                eislToken=tokenService.buildEislToken(claims.get("userNameClaim"),claims.get("serviceIdClaim"));
                    try {
                        RegistrationAccessModel registrationAccessModel = new RegistrationAccessModel();
                        registrationAccessModel.setEislToken(eislToken);
                        registrationAccessModel.setServiceId(Long.parseLong(claims.get("serviceIdClaim")));
                        registrationAccessModel.setUserId(claims.get("userNameClaim"));
                        int statusCode = updateRegistry(basicToken,registrationAccessModel);
                            if(statusCode==200){
                                log.info("EislToken: {eislToken} updated",eislToken);
                            }else{
                                log.error("Exception occured while updating data to Registry Access Service");
                                throw new RegistryAccessException();

                            }
                    }catch(Exception ex){
                        log.error("Exception occured while updating data to Registry Access Service",ex);
                        throw new RegistryAccessException("Exception occured while updating data to Registry Access Service",ex);

                    }
            }else{
                log.error("Exception occured while validating Token");
                throw new AuthTokenInvalidException();
            }
        }
        return eislToken;
    }

    public int updateRegistry(String basicToken, RegistrationAccessModel registrationAccessModel) {
        int statusCode=0;
        try {
            RestTemplate restTemplate = new RestTemplate() ;
            ObjectMapper mapper = new ObjectMapper();
            String requestJson = mapper.writeValueAsString(registrationAccessModel);
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.add("Authorization",basicToken);
            HttpEntity<String> entity = new HttpEntity<String>(requestJson, headers);
            ResponseEntity<String> responseEntity  = restTemplate.exchange(registryEndpointUrl, HttpMethod.PUT, entity, String.class);
            statusCode=responseEntity.getStatusCodeValue();
        } catch (Exception ex) {
            throw new RegistryAccessException("Exception occured while updating data to Registry Access Service",ex);
        }

        return statusCode;

    }


}
