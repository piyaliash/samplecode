package com.ubs.wmap.eisl.inhousekeepinglibrary.component;

import com.ubs.wmap.eisl.inhousekeepinglibrary.util.AuthorizationHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Component
public class EislTokenGenerator {
    @Value("${service.jwt.eisl.entitlementsClaim}")
    private String entitlementsClaim;
    @Value("${service.jwt.eisl.correlationIdClaim}")
    private String correlationIdClaim;
    @Value("${service.jwt.eisl.userNameClaim}")
    private String userNameClaim;
    @Value("${service.jwt.eisl.serviceIdClaim}")
    private String serviceIdClaim;

    @Autowired
    AuthorizationHelper authorizationHelper;

    @Autowired
    EntitlementComponent entitlementComponent;



    public Map<String, Object> getEislClaims(Map inputQuery) {

        Map<String, Object> eislMap = new HashMap<>(inputQuery);

        // Create Coorelation ID
        String corrID = UUID.randomUUID().toString();

        // Check Entitlement System
        Map entitlements = entitlementComponent.getEntitlementRoles(
                inputQuery.get(userNameClaim).toString(),
                inputQuery.get(serviceIdClaim).toString());

        // Build EISL Token
        if (!eislMap.containsKey(correlationIdClaim)) {
            eislMap.put(correlationIdClaim, corrID);
        }

        eislMap.put(entitlementsClaim, entitlements);

        return eislMap;
    }
}