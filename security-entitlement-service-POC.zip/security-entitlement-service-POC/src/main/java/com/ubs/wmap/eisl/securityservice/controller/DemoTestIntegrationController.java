package com.ubs.wmap.eisl.securityservice.controller;

import com.ubs.wmap.eisl.securityservice.controller.exceptions.IntegrationException;
import com.ubs.wmap.eisl.securityservice.model.EislTokenModel;
import com.ubs.wmap.eisl.securityservice.service.TokenService;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.Map;

import static org.springframework.http.HttpMethod.GET;

@Slf4j
//@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@Validated
@RestController
@RequestMapping("/demo")
public class DemoTestIntegrationController {

    @Value("${service.validation.endpointUrl}")
    private String validationEndpointUrl;

    @Value("${service.jwt.eisl.correlationIdClaim}")
    private String correlationIdClaim;

    @Autowired
    TokenService tokenService;


    @RequestMapping("/security")
    @GetMapping
    public EislTokenModel generate(@RequestParam(name = "userName") String userName,
                                   @RequestParam(name = "password") String password,
                                   @RequestParam(name = "serviceId") String serviceId) {


        String basicToken = tokenService.buildBasicToken(userName, password);
        log.info("Basic Token: {}", basicToken);


        String eislToken = tokenService.buildEislToken(userName, serviceId);
        log.info("EISL Token: {}", eislToken);

        return runSecurityValidation(basicToken, eislToken);
    }



    public EislTokenModel runSecurityValidation(String basicToken, String eislToken) {

        HttpEntity<String> request = buildRegistrationRequest(basicToken);
        String uri = buildRegistrationUri(eislToken);
        ResponseEntity<Map> response = new RestTemplate().exchange(uri, GET, request, Map.class);
        Map claims = response.getBody();

        claimsPreconditions(claims);

        EislTokenModel model = new EislTokenModel();
        model.setValidationStatus(
                checkResponseValidity(claims, eislToken)
                        ? "success"
                        : "fail");
        model.setClaims(claims);

        return model;
    }

    public boolean checkResponseValidity(Map responseClaims, String eislToken) {
        String originalcorrelationIdClaim = (String) tokenService.unwrapEislToken(eislToken).get(correlationIdClaim);
        return originalcorrelationIdClaim.equals(responseClaims.get(correlationIdClaim));
    }

    private HttpEntity<String> buildRegistrationRequest(String basicToken) {
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer " + basicToken);

        return  new HttpEntity<>(headers);
    }

    private String buildRegistrationUri(String eislToken) {
        return UriComponentsBuilder.fromHttpUrl(validationEndpointUrl)
                .queryParam("token", eislToken)
                .toUriString();
    }

    private void claimsPreconditions(Map claims) {
        if (null == claims) {
            throw new IntegrationException("Empty claims list received from remote endpoint.");
        }
        if (!claims.containsKey(correlationIdClaim)) {
            throw new IntegrationException("Topic name claim doesn't presented in the claims.");
        }
    }
}
