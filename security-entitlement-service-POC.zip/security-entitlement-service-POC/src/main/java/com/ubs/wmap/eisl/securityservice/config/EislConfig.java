package com.ubs.wmap.eisl.securityservice.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableConfigurationProperties
@ConfigurationProperties("eisl")
public class EislConfig {

    private String validationEndPoint;
    private long tokenExpireDuration;

    public EislConfig() {
    }

    @Override
    public java.lang.String toString() {
        return "EislConfig{" +
                "validationEndPoint='" + validationEndPoint + '\'' +
                ", tokenExpireDuration=" + tokenExpireDuration +
                '}';
    }

    public String getValidationEndPoint() {
        return validationEndPoint;
    }

    public void setValidationEndPoint(String validationEndPoint) {
        this.validationEndPoint = validationEndPoint;
    }

    public long getTokenExpireDuration() {
        return tokenExpireDuration;
    }

    public void setTokenExpireDuration(long tokenExpireDuration) {
        this.tokenExpireDuration = tokenExpireDuration;
    }
}
