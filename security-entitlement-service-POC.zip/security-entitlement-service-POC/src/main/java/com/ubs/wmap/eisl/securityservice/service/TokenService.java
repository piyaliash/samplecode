package com.ubs.wmap.eisl.securityservice.service;

import javax.validation.constraints.NotBlank;

import io.jsonwebtoken.Claims;

public interface TokenService {
    boolean isBasicTokenValid(@NotBlank String basicToken);
    boolean isBasicTokenNotValid(@NotBlank String basicToken);
    String buildBasicToken(@NotBlank String userName, @NotBlank String password);
    Claims unwrapBasicToken(@NotBlank String token);
    String buildEislToken(@NotBlank String basicToken, @NotBlank String serviceId);
    Claims unwrapEislToken(@NotBlank String token);
}