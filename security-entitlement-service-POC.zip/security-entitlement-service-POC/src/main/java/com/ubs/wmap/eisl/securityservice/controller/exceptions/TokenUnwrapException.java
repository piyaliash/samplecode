package com.ubs.wmap.eisl.securityservice.controller.exceptions;


import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.FORBIDDEN)
public class TokenUnwrapException extends RuntimeException {

    private static final String MESSAGE_PREFIX = "Exception during JWT token unwrapping";

    public TokenUnwrapException(Throwable cause) {
        super(MESSAGE_PREFIX + ".");
    }

    public TokenUnwrapException(String message, Throwable cause) {
        super(MESSAGE_PREFIX + ": " + message + ".");
    }
}
