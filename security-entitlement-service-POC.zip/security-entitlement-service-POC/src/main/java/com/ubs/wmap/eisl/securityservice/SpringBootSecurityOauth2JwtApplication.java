package com.ubs.wmap.eisl.securityservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootSecurityOauth2JwtApplication {


    public static void main(String[] args) {
        SpringApplication.run(SpringBootSecurityOauth2JwtApplication.class, args);
    }

}
