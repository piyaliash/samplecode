package com.ubs.wmap.eisl.exceptionreg.test.services;

import com.ubs.wmap.eisl.exceptionreg.services.ExceptionService;
import com.ubs.wmap.eisl.exceptionreg.services.sos.ExceptionPostRequestSO;
import com.ubs.wmap.eisl.exceptionreg.services.sos.ExceptionRequestSO;
import com.ubs.wmap.eisl.exceptionreg.services.sos.ExceptionResponseSO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

@RunWith(SpringRunner.class)
@DataJpaTest
@EnableAutoConfiguration
@ComponentScan(basePackages = { "com.ubs.wmap.eisl.exceptionreg" })
@ActiveProfiles("test")
public class ExceptionServiceTest {
	
	@Autowired
	private ExceptionService exceptionService;
	
	/**
	 * Get exception details for given exception service id
	 * 
	 */
	@Test
	public void testGetExceptionDetailsWithData() throws Exception {
		ExceptionRequestSO eventRequestSO=new ExceptionRequestSO();
		eventRequestSO.setExceptionServiceId(Integer.valueOf(1));
		ExceptionResponseSO eventResponseSO = exceptionService.getExceptionDetails(eventRequestSO);
		assertNotNull(eventResponseSO.getExceptionRefId());
	}
	
	/**
	 * No exception data found for given exception service id
	 * 
	 */
	@Test
	public void testGetExceptionDetailsWithOutData() throws Exception {
		ExceptionRequestSO eventRequestSO=new ExceptionRequestSO();
		eventRequestSO.setExceptionServiceId(Integer.valueOf(13));
		ExceptionResponseSO eventResponseSO = exceptionService.getExceptionDetails(eventRequestSO);
		assertNull("No data found for given input",eventResponseSO);
	}
	
	
	/**
	 * Save exception details		
	 * 
	 */
	@Test
	public void testSaveExceptionDetails() throws Exception {
	
		ExceptionPostRequestSO exceptionPostRequestSO = new ExceptionPostRequestSO();
		exceptionPostRequestSO.setCategory("category");
		exceptionPostRequestSO.setSeverity("severity");
		exceptionPostRequestSO.setExceptionTopic("topic");
		exceptionPostRequestSO.setExceptionDataRefId(Long.valueOf("1"));
		ExceptionResponseSO responseSO= exceptionService.saveExceptionDetails(exceptionPostRequestSO);
		assertNotNull("inserted exception data. Primary Key :",responseSO.getExceptionRefId());

	}
}
