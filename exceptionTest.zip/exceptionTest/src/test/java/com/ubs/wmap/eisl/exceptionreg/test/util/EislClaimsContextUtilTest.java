package com.ubs.wmap.eisl.exceptionreg.test.util;

import com.ubs.wmap.eisl.exceptionreg.context.EislClaimsContext;
import com.ubs.wmap.eisl.exceptionreg.context.EislClaimsContextHolder;
import com.ubs.wmap.eisl.exceptionreg.util.EislClaimsContextUtil;
import com.ubs.wmap.eisl.housekeeping.TokenService;
import com.ubs.wmap.eisl.housekeeping.TokenServiceConfiguration;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Map;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

@RunWith(SpringRunner.class)
@DataJpaTest
@EnableAutoConfiguration
@Import(TokenServiceConfiguration.class)
@ComponentScan(basePackages = {"com.ubs.wmap.eisl.exceptionreg"})
@ActiveProfiles("test")
public class EislClaimsContextUtilTest {
    @Autowired
    private TokenService tokenService;
    @Autowired
    private EislClaimsContextUtil eislClaimsContextUtil;

    @Test
    public void testContextParam() {
        createEislContext();
        Object obj = eislClaimsContextUtil.getContextParam("serviceId");
        String serviceId = (String) obj;
        assertNotNull(serviceId);

    }

    @Test
    public void testContextParamNull() {
        createEislContext();
        Object obj = eislClaimsContextUtil.getContextParam(null);
        assertNull(obj);

    }


    public void createEislContext() {
        /** This is just for testing and to be remove**/
        String eislToken = tokenService.createEILSToken("utk", "12", "admin");
        Map<String, Object> claims = tokenService.init(eislToken);
        createAndSetClaimsInContext(claims);
    }


    private void createAndSetClaimsInContext(Map<String, Object> claims) {
        EislClaimsContext eislClaimsContext = new EislClaimsContext();
        eislClaimsContext.setClaims(claims);
        EislClaimsContextHolder.set(eislClaimsContext);
    }
}
