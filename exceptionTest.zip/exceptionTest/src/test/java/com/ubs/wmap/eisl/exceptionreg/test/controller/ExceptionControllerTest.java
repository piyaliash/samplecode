package com.ubs.wmap.eisl.exceptionreg.test.controller;

import com.ubs.wmap.eisl.exceptionreg.context.EislClaimsContext;
import com.ubs.wmap.eisl.exceptionreg.context.EislClaimsContextHolder;
import com.ubs.wmap.eisl.exceptionreg.controller.ExceptionRegController;
import com.ubs.wmap.eisl.exceptionreg.exception.ExceptionRefNotFoundException;
import com.ubs.wmap.eisl.exceptionreg.exception.ExceptionRegBadRequestException;
import com.ubs.wmap.eisl.exceptionreg.exception.InvalidEISLTokenException;
import com.ubs.wmap.eisl.exceptionreg.services.sos.ExceptionPostRequestSO;
import com.ubs.wmap.eisl.exceptionreg.services.sos.ExceptionResponseSO;
import com.ubs.wmap.eisl.housekeeping.TokenService;
import com.ubs.wmap.eisl.housekeeping.TokenServiceConfiguration;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Import;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Map;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

@RunWith(SpringRunner.class)
@DataJpaTest
@EnableAutoConfiguration
@Import(TokenServiceConfiguration.class)
@ComponentScan(basePackages = {"com.ubs.wmap.eisl.exceptionreg"})
@ActiveProfiles("test")
public class ExceptionControllerTest {

    @Autowired
    private ExceptionRegController exceptionRegController;

    @Autowired
    private TokenService tokenService;

    /**
     * Get exception details for given exception service id
     *
     * @throws Exception
     */
    @Test
    public void testExceptionControllerData() throws Exception {
       // createEislContext();
        String eislToken=tokenService.createEILSToken("utk", "1", "admin");
        ResponseEntity<ExceptionResponseSO> responseEntity = exceptionRegController.getExceptionDetails("2",eislToken );
        assertNotNull(responseEntity);
    }

    /**
     * No exception data found for given exception service id
     */
    @Test
    public void testExceptionControllerWithoutData() throws Exception {
        createEislContext();
        try {
            exceptionRegController.getExceptionDetails("22", tokenService.createEILSToken("utk", "1", "admin"));
        } catch (ExceptionRefNotFoundException ex) {
            assertTrue("No exception data foundfor given exception serviceId", true);
        }
    }

    @Test(expected = ExceptionRegBadRequestException.class)
    public void testExceptionControllerEmptyServiceId() throws Exception {
        try {
            exceptionRegController.getExceptionDetails("", tokenService.createEILSToken("utk", "1", "admin"));
        } catch (ExceptionRefNotFoundException ex) {
            assertTrue("No exception data foundfor given exception serviceId", true);
        }
    }

    @Test(expected = InvalidEISLTokenException.class)
    public void testExceptionControllerInvalidToken() throws Exception {
        try {
            exceptionRegController.getExceptionDetails("12", "");
        } catch (ExceptionRefNotFoundException ex) {
            assertTrue("No exception data foundfor given exception serviceId", true);
        }
    }


    /**
     * Save exception details
     */
    @Test
    public void testPostExceptionDetails() throws Exception {
        createEislContext();

        ExceptionPostRequestSO exceptionPostRequestSO = new ExceptionPostRequestSO();
        exceptionPostRequestSO.setCategory("category");
        exceptionPostRequestSO.setSeverity("severity");
        exceptionPostRequestSO.setExceptionTopic("topic");
        exceptionPostRequestSO.setExceptionDataRefId(Long.valueOf("1"));
        ResponseEntity<ExceptionResponseSO> responseEntity = exceptionRegController.saveExceptionDetails(tokenService.createEILSToken("utk", "12", "admin"), exceptionPostRequestSO);
        assertNotNull(responseEntity.getBody().getExceptionRefId());

    }


    public void createEislContext() {
        /** This is just for testing and to be remove**/
        String eislToken = tokenService.createEILSToken("userid", "1", "Admin");
        Map<String, Object> claims = tokenService.init(eislToken);
        createAndSetClaimsInContext(claims);
    }


    private void createAndSetClaimsInContext(Map<String, Object> claims) {
        EislClaimsContext eislClaimsContext = new EislClaimsContext();
        eislClaimsContext.setClaims(claims);
        EislClaimsContextHolder.set(eislClaimsContext);
    }

}
