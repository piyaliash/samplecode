package com.ubs.wmap.eisl.exceptionreg.test.repository;

import com.ubs.wmap.eisl.exceptionreg.model.ExceptionData;
import com.ubs.wmap.eisl.exceptionreg.model.ExceptionReference;
import com.ubs.wmap.eisl.exceptionreg.repository.ExceptionDataRepository;
import com.ubs.wmap.eisl.exceptionreg.repository.ExceptionRefRepository;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;


@RunWith(SpringRunner.class)
@DataJpaTest
@EnableAutoConfiguration
@ComponentScan(basePackages = { "com.ubs.wmap.eisl.exceptionreg" })
@ActiveProfiles("test")
public class ExceptionRepositoryTest {

	@Autowired
	private ExceptionRefRepository exceptionRefRepository;
	
	@Autowired
	private ExceptionDataRepository exceptionDataRepository;

	@Test
	/**
	 * Get Exception details for given exception service id
	 */
	public void testfindByExceptionServiceIdWithData() throws Exception {
		ExceptionReference exceptionReference = exceptionRefRepository.findByExceptionServiceId(Integer.valueOf(1));
		assertNotNull(exceptionReference.getExceptionRefId());
	}
	
	
	@Test
	/**
	 * No exception data found for given exception service id
	 * @throws Exception
	 */
	public void testfindByExceptionServiceIdWithOutData() throws Exception {
		ExceptionReference exceptionReference = exceptionRefRepository.findByExceptionServiceId(Integer.valueOf(13));
		assertNull("No data found for given input",exceptionReference);
	}
	
	
	@Test
	/**
	 * Save Exception Details
	 * 
	 */
	public void testSaveExceptionReference() throws Exception {
		ExceptionReference entity=new ExceptionReference();
		entity.setCategory("category");
		entity.setSeverity("severity");
		entity.setExceptionTopic("topic");
		ExceptionData exceptionData =exceptionDataRepository.getOne(Long.valueOf("1"));
		entity.setExceptionData(exceptionData);
		ExceptionReference exceptionReference = exceptionRefRepository.save(entity);
		assertNotNull(exceptionReference.getExceptionRefId());
	}

}
