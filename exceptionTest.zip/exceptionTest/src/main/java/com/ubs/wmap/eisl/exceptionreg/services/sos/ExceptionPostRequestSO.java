package com.ubs.wmap.eisl.exceptionreg.services.sos;

import java.io.Serializable;

import lombok.Data;

@Data
public class ExceptionPostRequestSO implements Serializable {

	private static final long serialVersionUID = -998787659770475488L;

	private Long exceptionRefId;
	private Integer exceptionServiceId;
	private Long exceptionDataRefId;
	private String category;
	private String severity;
	private String exceptionTopic;
}
