package com.ubs.wmap.eisl.exceptionreg.controller.delegates;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ubs.wmap.eisl.exceptionreg.exception.ExceptionRegException;
import com.ubs.wmap.eisl.exceptionreg.services.ExceptionService;
import com.ubs.wmap.eisl.exceptionreg.services.sos.ExceptionPostRequestSO;
import com.ubs.wmap.eisl.exceptionreg.services.sos.ExceptionRequestSO;
import com.ubs.wmap.eisl.exceptionreg.services.sos.ExceptionResponseSO;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@Component
public class ExceptionDelegate {
	
	private final ExceptionService exceptionService;
	
	public ExceptionResponseSO getExceptionDetails(String  exceptionServiceId) throws ExceptionRegException{
		
		 return exceptionService.getExceptionDetails(constructExceptionRequestSO(exceptionServiceId));
	}
	
	
	public ExceptionResponseSO saveExceptionDetails(ExceptionPostRequestSO exceptionPostRequestSO) throws ExceptionRegException{
		 return exceptionService.saveExceptionDetails(exceptionPostRequestSO);
	}

	
	private ExceptionRequestSO constructExceptionRequestSO(String exceptionServiceId) {
		ExceptionRequestSO exceptionRequestSO = new ExceptionRequestSO();
		exceptionRequestSO.setExceptionServiceId(Integer.valueOf(exceptionServiceId));
		return exceptionRequestSO;
	}
}
