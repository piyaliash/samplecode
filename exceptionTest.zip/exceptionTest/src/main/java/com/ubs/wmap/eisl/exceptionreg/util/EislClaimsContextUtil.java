package com.ubs.wmap.eisl.exceptionreg.util;


import com.ubs.wmap.eisl.exceptionreg.context.EislClaimsContext;
import com.ubs.wmap.eisl.exceptionreg.context.EislClaimsContextHolder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
@Slf4j
public class EislClaimsContextUtil {

	@Value("${app.custom.eisl_attribute_name}")
	private String claimsAttribute;
	
	public Object getContextParam(String param) {
		log.debug("getContextParam-param:",param);

		EislClaimsContext eislClaimsContext= EislClaimsContextHolder.get();
		if(eislClaimsContext==null) {
			log.debug("eislClaimsContext object is null");
			return null;
		}

		Map<String, Object> claims = (Map<String, Object>) eislClaimsContext.getClaims().get(claimsAttribute);

		if(claims==null) {
			log.debug("claims object is null");
			return null;	
		}


		return claims.get(param);
	}

	@Deprecated
	public Map<String, Object> getClaims() {
		EislClaimsContext eislClaimsContext=EislClaimsContextHolder.get();
		if(eislClaimsContext==null) {
			log.debug("eislClaimsContext object is null");
			return null;
		}

        Map<String, Object> claims = (Map<String, Object>) eislClaimsContext.getClaims().get(claimsAttribute);
		if(claims==null) {
			log.debug("claims object is null");
			return null;	
		}
		
		return claims;
	}

}
