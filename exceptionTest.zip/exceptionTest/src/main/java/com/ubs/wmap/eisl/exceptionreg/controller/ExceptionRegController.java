package com.ubs.wmap.eisl.exceptionreg.controller;

import com.ubs.wmap.eisl.exceptionreg.context.EislClaimsContext;
import com.ubs.wmap.eisl.exceptionreg.context.EislClaimsContextHolder;
import com.ubs.wmap.eisl.exceptionreg.exception.InvalidEISLTokenException;
import com.ubs.wmap.eisl.housekeeping.TokenService;
import com.ubs.wmap.eisl.housekeeping.component.exceptions.TokenExpireException;
import com.ubs.wmap.eisl.housekeeping.component.exceptions.TokenUnwrapException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import com.ubs.wmap.eisl.exceptionreg.controller.delegates.ExceptionDelegate;
import com.ubs.wmap.eisl.exceptionreg.exception.ExceptionRefNotFoundException;
import com.ubs.wmap.eisl.exceptionreg.exception.ExceptionRegBadRequestException;
import com.ubs.wmap.eisl.exceptionreg.exception.ExceptionRegException;
import com.ubs.wmap.eisl.exceptionreg.services.sos.ExceptionPostRequestSO;
import com.ubs.wmap.eisl.exceptionreg.services.sos.ExceptionResponseSO;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import javax.validation.constraints.NotBlank;
import java.util.Map;


@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@RestController
@Slf4j
public class ExceptionRegController {


	private final ExceptionDelegate exceptionDelegate;

    private final TokenService tokenService;
	
	@Value("${app.message.INTERNAL_SERVER_ERROR_MSG}")
	private String INTERNAL_SERVER_ERROR_MSG;
	
	@Value("${app.message.EXCEPTIONREF_NOT_FOUND_MSG}")
	private String EXCEPTIONREF_NOT_FOUND_MSG;
	
	@Value("${app.message.EXCEPTION_SERVICEID_EMPTY_MSG}")
	private String EXCEPTION_SERVICEID_EMPTY_MSG;

	@Value("${app.message.EISL_INVALID_TOKEN_MSG}")
	private String EISL_INVALID_TOKEN_MSG;

	@Value("${app.custom.eisl_attribute_name}")
	private String eislClaimsAttribute;
	
	
	@GetMapping(value = "/exceptions/{exceptionServiceId}")
	public ResponseEntity<ExceptionResponseSO> getExceptionDetails(@PathVariable String exceptionServiceId ,
                                                                   @NotBlank @RequestParam("token") String token)
            throws ExceptionRegException, ExceptionRegBadRequestException, ExceptionRefNotFoundException, InvalidEISLTokenException {
		log.debug("exceptionServiceId:{}",exceptionServiceId);
		ExceptionResponseSO exceptionResponseSO = null;
		
		if(StringUtils.isEmpty(exceptionServiceId)) {
			throw new ExceptionRegBadRequestException(EXCEPTION_SERVICEID_EMPTY_MSG);
		}

        if (!servicePreconditions(token).containsKey(eislClaimsAttribute)) {
			throw new InvalidEISLTokenException(EISL_INVALID_TOKEN_MSG);
        }

		try {
			exceptionResponseSO = exceptionDelegate.getExceptionDetails(exceptionServiceId);
			if (exceptionResponseSO == null) {
				throw new ExceptionRefNotFoundException(EXCEPTIONREF_NOT_FOUND_MSG + ": " +exceptionServiceId);
			}

		} catch (ExceptionRegException exceptionRefException) {
			log.error( exceptionRefException.getMessage(), exceptionRefException);
			throw new ExceptionRegException(INTERNAL_SERVER_ERROR_MSG);
		}

		return ResponseEntity.ok(exceptionResponseSO);
	}
	
	
	@PostMapping(value = "/exceptions")
	public ResponseEntity<ExceptionResponseSO> saveExceptionDetails(@RequestParam("token") String token,
			@RequestBody ExceptionPostRequestSO exceptionPostRequestSO)
            throws ExceptionRegException, ExceptionRegBadRequestException, InvalidEISLTokenException {
		log.debug("exceptionPostRequestSO:{}",exceptionPostRequestSO);
		ExceptionResponseSO exceptionResponseSO = null;

        if (!servicePreconditions(token).containsKey(eislClaimsAttribute)) {
			throw new InvalidEISLTokenException(EISL_INVALID_TOKEN_MSG);
        }
		
		try {
			exceptionResponseSO = exceptionDelegate.saveExceptionDetails(exceptionPostRequestSO);

		} catch (ExceptionRegException exceptionRefException) {
			log.error( exceptionRefException.getMessage(), exceptionRefException);
			throw new ExceptionRegException(INTERNAL_SERVER_ERROR_MSG);
		}
		log.debug("exceptionResponseSO:{}",exceptionResponseSO);
		return ResponseEntity.ok(exceptionResponseSO);
	}


    public Map<String, Object> servicePreconditions(String eislToken) throws InvalidEISLTokenException {
        Map<String, Object> eislClaims;
        try {
            eislClaims = tokenService.init(eislToken);
            createAndSetClaimsInContext(eislClaims);
        } catch (TokenExpireException | TokenUnwrapException  ex) {
            throw new InvalidEISLTokenException(EISL_INVALID_TOKEN_MSG);
        } catch (RuntimeException rx) {
        	log.error(rx.getMessage());
			throw new ExceptionRegException(INTERNAL_SERVER_ERROR_MSG);
		}

        return  eislClaims;
    }

    private void createAndSetClaimsInContext(Map<String, Object> claims) {
        EislClaimsContext eislClaimsContext = new EislClaimsContext();
        eislClaimsContext.setClaims(claims);
        EislClaimsContextHolder.set(eislClaimsContext);
    }
}
