package com.ubs.wmap.eisl.exceptionreg.exception;

public class InvalidEISLTokenException extends Exception{

	private static final long serialVersionUID = -2154287827168582345L;

	public InvalidEISLTokenException(String message) {
		super(message);
	}

}
