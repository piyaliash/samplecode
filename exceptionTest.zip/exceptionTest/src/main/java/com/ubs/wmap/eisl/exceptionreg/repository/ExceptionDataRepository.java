package com.ubs.wmap.eisl.exceptionreg.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ubs.wmap.eisl.exceptionreg.model.ExceptionData;

@Repository
public interface ExceptionDataRepository extends JpaRepository<ExceptionData, Long> {

}
